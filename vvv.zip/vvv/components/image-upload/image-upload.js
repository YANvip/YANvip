// components/image-upload/image-upload.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // 已选择的图片列表
    imageList: {
      type: Array,
      value: [],
      observer: function(newVal) {
        // 当图片列表变化时，触发事件
        this.triggerEvent('change', { value: newVal });
      }
    },
    // 最大上传数量
    maxCount: {
      type: Number,
      value: 9
    },
    // 是否显示添加文字
    showAddText: {
      type: Boolean,
      value: true
    },
    // 是否显示数量
    showCount: {
      type: Boolean,
      value: true
    },
    // 提示文字
    tip: {
      type: String,
      value: ''
    },
    // 上传类型：image/video/all
    uploadType: {
      type: String,
      value: 'image'
    },
    // 是否允许多选
    multiple: {
      type: Boolean,
      value: true
    },
    // 是否压缩
    compress: {
      type: Boolean,
      value: true
    },
    // 压缩质量 (0-100)
    quality: {
      type: Number,
      value: 80
    },
    // 是否显示上传进度
    showProgress: {
      type: Boolean,
      value: true
    },
    // 是否自动上传
    autoUpload: {
      type: Boolean,
      value: true
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    uploading: false,
    error: ''
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 选择图片
    onChooseImage() {
      const { imageList, maxCount, multiple, uploadType, compress, quality } = this.data;
      
      // 计算还可以选择的数量
      const count = multiple ? maxCount - imageList.length : 1;
      
      if (count <= 0) {
        wx.showToast({
          title: `最多只能选择${maxCount}张图片`,
          icon: 'none'
        });
        return;
      }
      
      const sourceType = ['album', 'camera'];
      const sizeType = compress ? ['compressed'] : ['original'];
      
      wx.chooseMedia({
        count: count,
        mediaType: uploadType === 'video' ? ['video'] : ['image'],
        sourceType: sourceType,
        sizeType: sizeType,
        maxDuration: 30,
        camera: 'back',
        success: (res) => {
          const tempFiles = res.tempFiles || [];
          const newImages = [];
          
          tempFiles.forEach(file => {
            newImages.push({
              url: file.tempFilePath,
              type: file.fileType,
              size: file.size,
              name: file.tempFilePath.split('/').pop(),
              progress: 0
            });
          });
          
          // 合并图片列表
          const updatedList = [...imageList, ...newImages];
          
          this.setData({
            imageList: updatedList,
            error: ''
          });
          
          // 如果需要自动上传
          if (this.properties.autoUpload) {
            this.uploadImages(newImages);
          }
        },
        fail: (err) => {
          console.error('选择图片失败:', err);
          this.setData({
            error: '选择图片失败，请重试'
          });
        }
      });
    },

    // 上传图片
    uploadImages(images) {
      if (!images || images.length === 0) return;
      
      this.setData({ uploading: true });
      
      const uploadTasks = images.map((image, index) => {
        return new Promise((resolve, reject) => {
          // 模拟上传进度（实际项目中应该调用真实的上传接口）
          let progress = 0;
          const interval = setInterval(() => {
            progress += 10;
            if (progress > 100) progress = 100;
            
            // 更新进度
            const imageKey = `imageList[${this.data.imageList.indexOf(image)}].progress`;
            this.setData({
              [imageKey]: progress
            });
            
            if (progress >= 100) {
              clearInterval(interval);
              // 模拟上传成功
              setTimeout(() => {
                resolve({
                  success: true,
                  url: image.url,
                  fileId: `mock_file_${Date.now()}_${index}`
                });
              }, 500);
            }
          }, 100);
        });
      });
      
      Promise.all(uploadTasks)
        .then(results => {
          this.setData({ uploading: false });
          
          // 触发上传完成事件
          this.triggerEvent('uploadcomplete', {
            success: true,
            results: results
          });
        })
        .catch(error => {
          this.setData({ 
            uploading: false,
            error: '上传失败，请重试'
          });
          
          this.triggerEvent('uploadcomplete', {
            success: false,
            error: error
          });
        });
    },

    // 删除图片
    onDeleteImage(e) {
      const index = e.currentTarget.dataset.index;
      const { imageList } = this.data;
      
      wx.showModal({
        title: '提示',
        content: '确定要删除这张图片吗？',
        success: (res) => {
          if (res.confirm) {
            imageList.splice(index, 1);
            
            this.setData({
              imageList: [...imageList]
            });
            
            // 触发删除事件
            this.triggerEvent('delete', {
              index: index
            });
          }
        }
      });
    },

    // 预览图片
    onPreviewImage(e) {
      const index = e.currentTarget.dataset.index;
      const { imageList } = this.data;
      
      const urls = imageList.map(item => item.url || item);
      
      wx.previewImage({
        current: urls[index],
        urls: urls
      });
    },

    // 手动触发上传（当 autoUpload 为 false 时使用）
    upload() {
      const imagesToUpload = this.data.imageList.filter(item => !item.fileId);
      if (imagesToUpload.length > 0) {
        this.uploadImages(imagesToUpload);
      }
    },

    // 清空所有图片
    clear() {
      wx.showModal({
        title: '提示',
        content: '确定要清空所有图片吗？',
        success: (res) => {
          if (res.confirm) {
            this.setData({
              imageList: []
            });
            
            this.triggerEvent('clear');
          }
        }
      });
    },

    // 获取已上传的文件列表
    getUploadedFiles() {
      return this.data.imageList.filter(item => item.fileId);
    }
  },

  /**
   * 组件生命周期
   */
  lifetimes: {
    attached: function() {
      // 在组件实例进入页面节点树时执行
    },
    detached: function() {
      // 在组件实例被从页面节点树移除时执行
    }
  }
});