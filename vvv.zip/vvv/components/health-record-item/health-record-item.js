// components/health-record-item/health-record-item.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // 健康记录对象
    record: {
      type: Object,
      value: {}
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    typeMap: {
      'vaccine': '疫苗',
      'deworm': '驱虫',
      'checkup': '体检',
      'medical': '看病',
      'medication': '用药'
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 获取类型文本
    getTypeText(type) {
      return this.data.typeMap[type] || '其他';
    },

    // 点击记录项
    onItemTap() {
      this.triggerEvent('itemtap', {
        recordId: this.properties.record.id
      });
    }
  }
})