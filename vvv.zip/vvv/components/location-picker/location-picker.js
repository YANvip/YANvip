// components/location-picker/location-picker.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // 位置信息对象
    location: {
      type: Object,
      value: {},
      observer: function(newVal) {
        this.processLocationData(newVal);
      }
    },
    // 占位符文本
    placeholder: {
      type: String,
      value: ''
    },
    // 是否显示搜索框
    showSearch: {
      type: Boolean,
      value: false
    },
    // 是否显示附近地点
    showNearby: {
      type: Boolean,
      value: false
    },
    // 是否显示最近使用
    showRecent: {
      type: Boolean,
      value: true
    },
    // 是否显示坐标
    showCoordinates: {
      type: Boolean,
      value: false
    },
    // 列表高度
    listHeight: {
      type: Number,
      value: 400
    },
    // 是否自动获取当前位置
    autoGetLocation: {
      type: Boolean,
      value: false
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    searchKeyword: '',
    nearbyLocations: [],
    recentLocations: [],
    error: '',
    showPermissionTip: false,
    isLoading: false
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 处理位置数据
    processLocationData(location) {
      if (!location || !location.name) {
        return;
      }
      
      // 保存到最近使用
      this.saveToRecent(location);
    },

    // 保存到最近使用
    saveToRecent(location) {
      try {
        const recent = wx.getStorageSync('recentLocations') || [];
        
        // 检查是否已存在
        const existingIndex = recent.findIndex(item => 
          item.name === location.name && 
          item.latitude === location.latitude && 
          item.longitude === location.longitude
        );
        
        if (existingIndex > -1) {
          // 移到最前面
          const [existing] = recent.splice(existingIndex, 1);
          recent.unshift(existing);
        } else {
          // 添加到最前面
          recent.unshift({
            id: Date.now().toString(),
            name: location.name,
            address: location.address || '',
            latitude: location.latitude,
            longitude: location.longitude
          });
          
          // 限制数量
          if (recent.length > 10) {
            recent.pop();
          }
        }
        
        wx.setStorageSync('recentLocations', recent);
        this.setData({ recentLocations: recent });
      } catch (error) {
        console.error('保存最近位置失败:', error);
      }
    },

    // 加载最近使用的位置
    loadRecentLocations() {
      try {
        const recent = wx.getStorageSync('recentLocations') || [];
        this.setData({ recentLocations: recent });
      } catch (error) {
        console.error('加载最近位置失败:', error);
      }
    },

    // 搜索输入
    onSearchInput(e) {
      this.setData({
        searchKeyword: e.detail.value
      });
    },

    // 搜索确认
    onSearchConfirm(e) {
      this.searchLocations(e.detail.value);
    },

    // 搜索地点
    async searchLocations(keyword) {
      if (!keyword || keyword.trim() === '') {
        this.setData({ nearbyLocations: [] });
        return;
      }

      try {
        this.setData({ isLoading: true, error: '' });
        
        const res = await new Promise((resolve, reject) => {
          wx.request({
            url: 'https://apis.map.qq.com/ws/place/v1/suggestion',
            method: 'GET',
            data: {
              keyword: keyword,
              region: '全国',
              key: '您的地图API密钥', // 需要申请腾讯地图API密钥
              location: this.data.location.latitude && this.data.location.longitude 
                ? `${this.data.location.latitude},${this.data.location.longitude}`
                : ''
            },
            success: resolve,
            fail: reject
          });
        });

        if (res.statusCode === 200 && res.data.status === 0) {
          const locations = res.data.data.map(item => ({
            id: item.id,
            name: item.title,
            address: item.address,
            latitude: item.location.lat,
            longitude: item.location.lng
          }));
          
          this.setData({ nearbyLocations: locations });
        } else {
          throw new Error(res.data.message || '搜索失败');
        }
      } catch (error) {
        console.error('搜索地点失败:', error);
        this.setData({ 
          error: '搜索失败，请检查网络连接'
        });
      } finally {
        this.setData({ isLoading: false });
      }
    },

    // 选择位置
    onSelectLocation() {
      this.checkLocationPermission()
        .then(hasPermission => {
          if (hasPermission) {
            this.chooseLocation();
          }
        })
        .catch(error => {
          console.error('检查权限失败:', error);
          this.setData({
            error: '获取位置权限失败'
          });
        });
    },

    // 检查位置权限
    checkLocationPermission() {
      return new Promise((resolve, reject) => {
        wx.getSetting({
          success: (res) => {
            if (res.authSetting['scope.userLocation'] === undefined) {
              // 未请求过权限
              wx.authorize({
                scope: 'scope.userLocation',
                success: () => resolve(true),
                fail: () => {
                  this.setData({ showPermissionTip: true });
                  resolve(false);
                }
              });
            } else if (res.authSetting['scope.userLocation'] === false) {
              // 已拒绝权限
              this.setData({ showPermissionTip: true });
              resolve(false);
            } else {
              // 已授权
              resolve(true);
            }
          },
          fail: reject
        });
      });
    },

    // 选择位置
    chooseLocation() {
      wx.chooseLocation({
        success: (res) => {
          const location = {
            name: res.name,
            address: res.address,
            latitude: res.latitude,
            longitude: res.longitude
          };
          
          this.setData({ 
            location: location,
            error: '',
            showPermissionTip: false
          });
          
          this.saveToRecent(location);
          
          this.triggerEvent('change', { location });
        },
        fail: (error) => {
          console.error('选择位置失败:', error);
          
          let errorMsg = '选择位置失败';
          if (error.errMsg.includes('auth deny')) {
            errorMsg = '需要位置权限，请在设置中开启';
            this.setData({ showPermissionTip: true });
          } else if (error.errMsg.includes('cancel')) {
            return; // 用户取消，不显示错误
          }
          
          this.setData({ error: errorMsg });
        }
      });
    },

    // 更改位置
    onChangeLocation() {
      this.chooseLocation();
    },

    // 清除位置
    onClearLocation() {
      wx.showModal({
        title: '提示',
        content: '确定要清除位置信息吗？',
        success: (res) => {
          if (res.confirm) {
            this.setData({ 
              location: {},
              error: ''
            });
            
            this.triggerEvent('change', { location: {} });
            this.triggerEvent('clear');
          }
        }
      });
    },

    // 选择附近地点
    onSelectNearby(e) {
      const location = e.currentTarget.dataset.location;
      this.setData({ 
        location: location,
        error: ''
      });
      
      this.saveToRecent(location);
      this.triggerEvent('change', { location });
    },

    // 选择最近使用
    onSelectRecent(e) {
      const location = e.currentTarget.dataset.location;
      this.setData({ 
        location: location,
        error: ''
      });
      
      this.saveToRecent(location);
      this.triggerEvent('change', { location });
    },

    // 重试
    onRetry() {
      this.setData({ error: '' });
      this.onSelectLocation();
    },

    // 打开设置
    onOpenSetting() {
      wx.openSetting({
        success: (res) => {
          if (res.authSetting['scope.userLocation'] === true) {
            this.setData({ showPermissionTip: false });
            this.onSelectLocation();
          }
        }
      });
    },

    // 获取当前位置
    getCurrentLocation() {
      return new Promise((resolve, reject) => {
        wx.getLocation({
          type: 'gcj02',
          success: resolve,
          fail: reject
        });
      });
    },

    // 获取当前位置并转换为地址
    async getCurrentAddress() {
      try {
        const location = await this.getCurrentLocation();
        
        // 这里需要调用逆地理编码API
        // 实际项目中需要申请地图API密钥
        // 暂时返回位置对象
        const locationObj = {
          name: '当前位置',
          address: '',
          latitude: location.latitude,
          longitude: location.longitude
        };
        
        return locationObj;
      } catch (error) {
        throw error;
      }
    }
  },

  /**
   * 组件生命周期
   */
  lifetimes: {
    attached: function() {
      this.loadRecentLocations();
      
      // 如果自动获取位置且有位置信息
      if (this.properties.autoGetLocation && !this.properties.location.name) {
        this.checkLocationPermission()
          .then(hasPermission => {
            if (hasPermission) {
              this.getCurrentAddress()
                .then(location => {
                  this.setData({ location });
                  this.triggerEvent('change', { location });
                })
                .catch(error => {
                  console.error('获取当前位置失败:', error);
                });
            }
          });
      }
    }
  }
});