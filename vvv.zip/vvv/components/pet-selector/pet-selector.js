// components/pet-selector/pet-selector.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // 宠物列表数据
    pets: {
      type: Array,
      value: [],
      observer: function(newVal) {
        this.processPetsData(newVal);
      }
    },
    // 已选中的宠物ID数组
    selectedIds: {
      type: Array,
      value: [],
      observer: function(newVal) {
        this.checkAllSelected(newVal);
      }
    },
    // 选择模式：single（单选）或 multiple（多选）
    mode: {
      type: String,
      value: 'multiple'
    },
    // 最多可选数量（多选模式下有效）
    maxSelect: {
      type: Number,
      value: 0 // 0表示不限制
    },
    // 标题
    title: {
      type: String,
      value: ''
    },
    // 副标题
    subtitle: {
      type: String,
      value: ''
    },
    // 是否显示搜索框
    showSearch: {
      type: Boolean,
      value: true
    },
    // 滚动区域高度
    scrollHeight: {
      type: Number,
      value: 600
    },
    // 是否显示详情箭头
    showDetail: {
      type: Boolean,
      value: false
    },
    // 是否显示空状态下的操作按钮
    showEmptyAction: {
      type: Boolean,
      value: false
    },
    // 空状态提示文字
    emptyTip: {
      type: String,
      value: ''
    },
    // 空状态操作按钮文字
    emptyActionText: {
      type: String,
      value: ''
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    searchKeyword: '', // 搜索关键词
    filteredPets: [], // 筛选后的宠物列表
    isAllSelected: false, // 是否全选
    scrollTop: 0 // 滚动位置
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 处理宠物数据
    processPetsData(pets) {
      const processedPets = pets.map(pet => {
        return {
          ...pet,
          avatar: pet.avatar || '/images/default-pet.png',
          breed: pet.breed || '未知品种',
          gender: pet.gender || 'unknown',
          birthDate: pet.birthDate || '',
          status: pet.status || 'active'
        };
      });
      
      // 初始时显示所有宠物
      this.setData({
        filteredPets: this.filterPets(processedPets, this.data.searchKeyword)
      });
    },

    // 筛选宠物
    filterPets(pets, keyword) {
      if (!keyword) return pets;
      
      const lowerKeyword = keyword.toLowerCase();
      return pets.filter(pet => {
        return (
          (pet.name && pet.name.toLowerCase().includes(lowerKeyword)) ||
          (pet.breed && pet.breed.toLowerCase().includes(lowerKeyword)) ||
          (pet.color && pet.color.toLowerCase().includes(lowerKeyword))
        );
      });
    },

    // 计算年龄
    calculateAge(birthDate) {
      if (!birthDate) return '年龄未知';
      
      const birth = new Date(birthDate);
      const now = new Date();
      
      let age = now.getFullYear() - birth.getFullYear();
      const monthDiff = now.getMonth() - birth.getMonth();
      
      if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < birth.getDate())) {
        age--;
      }
      
      if (age === 0) {
        const months = now.getMonth() - birth.getMonth();
        if (months < 0) months += 12;
        return `${months}个月`;
      }
      
      return `${age}岁`;
    },

    // 获取状态文本
    getStatusText(status) {
      const statusMap = {
        active: '健康',
        lost: '走失',
        deceased: '已故',
        adopted: '已被领养'
      };
      return statusMap[status] || '未知';
    },

    // 点击宠物项
    onPetTap(e) {
      const pet = e.currentTarget.dataset.pet;
      const { mode, selectedIds, maxSelect } = this.data;
      
      let newSelectedIds = [...selectedIds];
      
      if (mode === 'single') {
        // 单选模式
        newSelectedIds = [pet.id];
      } else {
        // 多选模式
        const index = newSelectedIds.indexOf(pet.id);
        
        if (index > -1) {
          // 取消选择
          newSelectedIds.splice(index, 1);
        } else {
          // 检查是否超过最大选择数量
          if (maxSelect > 0 && newSelectedIds.length >= maxSelect) {
            wx.showToast({
              title: `最多只能选择${maxSelect}个宠物`,
              icon: 'none'
            });
            return;
          }
          newSelectedIds.push(pet.id);
        }
      }
      
      this.setData({
        selectedIds: newSelectedIds
      });
      
      // 触发选择变化事件
      this.triggerEvent('change', {
        selectedIds: newSelectedIds,
        selectedPets: this.data.pets.filter(p => newSelectedIds.includes(p.id))
      });
    },

    // 搜索输入
    onSearchInput(e) {
      const keyword = e.detail.value;
      this.setData({
        searchKeyword: keyword,
        filteredPets: this.filterPets(this.data.pets, keyword),
        scrollTop: 0 // 搜索时滚动到顶部
      });
    },

    // 搜索确认
    onSearchConfirm(e) {
      const keyword = e.detail.value;
      this.setData({
        searchKeyword: keyword,
        filteredPets: this.filterPets(this.data.pets, keyword)
      });
    },

    // 全选/取消全选
    onSelectAll() {
      const { isAllSelected, filteredPets, maxSelect } = this.data;
      let newSelectedIds = [];
      
      if (!isAllSelected) {
        // 全选
        const availableIds = filteredPets.map(pet => pet.id);
        
        // 检查是否超过最大选择数量
        if (maxSelect > 0 && availableIds.length > maxSelect) {
          wx.showToast({
            title: `最多只能选择${maxSelect}个宠物`,
            icon: 'none'
          });
          newSelectedIds = availableIds.slice(0, maxSelect);
        } else {
          newSelectedIds = availableIds;
        }
      }
      
      this.setData({
        selectedIds: newSelectedIds
      });
      
      this.triggerEvent('change', {
        selectedIds: newSelectedIds,
        selectedPets: this.data.pets.filter(p => newSelectedIds.includes(p.id))
      });
    },

    // 检查是否全选
    checkAllSelected(selectedIds) {
      const { filteredPets } = this.data;
      const availableIds = filteredPets.map(pet => pet.id);
      const isAllSelected = availableIds.length > 0 && 
                           availableIds.every(id => selectedIds.includes(id));
      
      this.setData({
        isAllSelected: isAllSelected
      });
    },

    // 确认选择
    onConfirm() {
      const { selectedIds } = this.data;
      
      if (selectedIds.length === 0) {
        wx.showToast({
          title: '请至少选择一个宠物',
          icon: 'none'
        });
        return;
      }
      
      this.triggerEvent('confirm', {
        selectedIds: selectedIds,
        selectedPets: this.data.pets.filter(p => selectedIds.includes(p.id))
      });
    },

    // 空状态操作
    onEmptyAction() {
      this.triggerEvent('emptyaction');
    },

    // 清空选择
    clearSelection() {
      this.setData({
        selectedIds: []
      });
      
      this.triggerEvent('change', {
        selectedIds: [],
        selectedPets: []
      });
    },

    // 获取选中的宠物
    getSelectedPets() {
      return this.data.pets.filter(pet => this.data.selectedIds.includes(pet.id));
    }
  },

  /**
   * 组件生命周期
   */
  lifetimes: {
    attached: function() {
      // 在组件实例进入页面节点树时执行
      this.processPetsData(this.properties.pets);
    }
  }
});