// components/loading-more/loading-more.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // 状态：loading, no-more, error, 默认空表示还有更多
    status: {
      type: String,
      value: ''
    },
    // 是否可见
    visible: {
      type: Boolean,
      value: true
    },
    // 自定义类名
    customClass: {
      type: String,
      value: ''
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    // 组件内部状态，可以根据需要扩展
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 点击重试
    onRetryTap() {
      if (this.data.status === 'error') {
        this.triggerEvent('retry');
      }
    }
  }
});