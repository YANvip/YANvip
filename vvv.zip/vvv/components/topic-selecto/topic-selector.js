// components/topic-selector/topic-selector.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // 话题列表数据
    topics: {
      type: Array,
      value: [],
      observer: function(newVal) {
        this.processTopicsData(newVal);
      }
    },
    // 已选中的话题名称数组
    selectedTopics: {
      type: Array,
      value: []
    },
    // 热门话题列表
    hotTopics: {
      type: Array,
      value: [],
      observer: function(newVal) {
        this.setData({
          hotTopics: newVal || []
        });
      }
    },
    // 最多可选数量
    maxSelect: {
      type: Number,
      value: 5
    },
    // 标题
    title: {
      type: String,
      value: ''
    },
    // 副标题
    subtitle: {
      type: String,
      value: ''
    },
    // 占位符
    placeholder: {
      type: String,
      value: ''
    },
    // 是否允许创建话题
    allowCreate: {
      type: Boolean,
      value: true
    },
    // 是否显示热门话题
    showHot: {
      type: Boolean,
      value: true
    },
    // 滚动区域高度
    scrollHeight: {
      type: Number,
      value: 400
    },
    // 是否显示空状态下的操作按钮
    showEmptyAction: {
      type: Boolean,
      value: false
    },
    // 空状态提示文字
    emptyTip: {
      type: String,
      value: ''
    },
    // 空状态操作按钮文字
    emptyActionText: {
      type: String,
      value: ''
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    searchKeyword: '', // 搜索关键词
    filteredTopics: [], // 筛选后的话题列表
    scrollTop: 0 // 滚动位置
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 处理话题数据
    processTopicsData(topics) {
      const processedTopics = topics.map(topic => {
        return {
          id: topic.id || topic.name,
          name: topic.name,
          count: topic.count || 0,
          description: topic.description || ''
        };
      });
      
      this.setData({
        filteredTopics: this.filterTopics(processedTopics, this.data.searchKeyword)
      });
    },

    // 筛选话题
    filterTopics(topics, keyword) {
      if (!keyword) return topics;
      
      const lowerKeyword = keyword.toLowerCase();
      return topics.filter(topic => {
        return topic.name.toLowerCase().includes(lowerKeyword);
      });
    },

    // 搜索输入
    onSearchInput(e) {
      const keyword = e.detail.value;
      this.setData({
        searchKeyword: keyword,
        filteredTopics: this.filterTopics(this.data.topics, keyword),
        scrollTop: 0
      });
    },

    // 搜索确认
    onSearchConfirm(e) {
      const keyword = e.detail.value;
      this.setData({
        searchKeyword: keyword,
        filteredTopics: this.filterTopics(this.data.topics, keyword)
      });
    },

    // 点击话题
    onTopicTap(e) {
      const topic = e.currentTarget.dataset.topic;
      this.toggleTopic(topic.name);
    },

    // 点击热门话题
    onHotTopicTap(e) {
      const topic = e.currentTarget.dataset.topic;
      this.toggleTopic(topic.name);
    },

    // 切换话题选择状态
    toggleTopic(topicName) {
      const { selectedTopics, maxSelect } = this.data;
      let newSelected = [...selectedTopics];
      
      const index = newSelected.indexOf(topicName);
      if (index > -1) {
        // 取消选择
        newSelected.splice(index, 1);
      } else {
        // 检查是否超过最大选择数量
        if (newSelected.length >= maxSelect) {
          wx.showToast({
            title: `最多只能选择${maxSelect}个话题`,
            icon: 'none'
          });
          return;
        }
        newSelected.push(topicName);
      }
      
      this.setData({
        selectedTopics: newSelected
      });
      
      this.triggerEvent('change', {
        selectedTopics: newSelected
      });
    },

    // 删除已选话题
    onDeleteSelected(e) {
      const index = e.currentTarget.dataset.index;
      const newSelected = [...this.data.selectedTopics];
      newSelected.splice(index, 1);
      
      this.setData({
        selectedTopics: newSelected
      });
      
      this.triggerEvent('change', {
        selectedTopics: newSelected
      });
    },

    // 创建话题
    onCreateTopic() {
      const { searchKeyword, selectedTopics, maxSelect } = this.data;
      
      if (!searchKeyword.trim()) {
        wx.showToast({
          title: '请输入话题名称',
          icon: 'none'
        });
        return;
      }
      
      if (selectedTopics.length >= maxSelect) {
        wx.showToast({
          title: `最多只能选择${maxSelect}个话题`,
          icon: 'none'
        });
        return;
      }
      
      // 检查是否已存在相同话题
      if (selectedTopics.includes(searchKeyword)) {
        wx.showToast({
          title: '该话题已选择',
          icon: 'none'
        });
        return;
      }
      
      const newSelected = [...selectedTopics, searchKeyword];
      this.setData({
        selectedTopics: newSelected,
        searchKeyword: ''
      });
      
      this.triggerEvent('change', {
        selectedTopics: newSelected
      });
      
      this.triggerEvent('create', {
        topicName: searchKeyword
      });
    },

    // 取消
    onCancel() {
      this.triggerEvent('cancel');
    },

    // 确认
    onConfirm() {
      const { selectedTopics } = this.data;
      
      if (selectedTopics.length === 0) {
        wx.showToast({
          title: '请至少选择一个话题',
          icon: 'none'
        });
        return;
      }
      
      this.triggerEvent('confirm', {
        selectedTopics: selectedTopics
      });
    },

    // 空状态操作
    onEmptyAction() {
      this.triggerEvent('emptyaction');
    }
  },

  /**
   * 组件生命周期
   */
  lifetimes: {
    attached: function() {
      this.processTopicsData(this.properties.topics);
    }
  }
});