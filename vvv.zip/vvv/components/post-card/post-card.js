// components/post-card/post-card.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // 帖子数据对象
    post: {
      type: Object,
      value: {},
      observer: function(newVal) {
        // 当post数据更新时，处理一些额外逻辑
        if (newVal) {
          this.processPostData(newVal);
        }
      }
    },
    // 是否显示更多操作菜单
    showMoreMenu: {
      type: Boolean,
      value: false
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    currentPost: {}
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 处理帖子数据
    processPostData(post) {
      // 确保帖子对象有必要的字段
      const processedPost = {
        ...post,
        user: post.user || {},
        images: post.images || [],
        petIds: post.petIds || [],
        likes: post.likes || 0,
        comments: post.comments || 0,
        shares: post.shares || 0,
        isLiked: post.isLiked || false,
        location: post.location || {}
      };
      
      this.setData({
        currentPost: processedPost
      });
    },

    // 格式化时间
    formatTime(timestamp) {
      if (!timestamp) return '刚刚';
      
      const date = new Date(timestamp);
      const now = new Date();
      const diff = now.getTime() - date.getTime();
      
      // 计算时间差
      const minute = 60 * 1000;
      const hour = 60 * minute;
      const day = 24 * hour;
      const month = 30 * day;
      const year = 365 * day;
      
      if (diff < minute) {
        return '刚刚';
      } else if (diff < hour) {
        return Math.floor(diff / minute) + '分钟前';
      } else if (diff < day) {
        return Math.floor(diff / hour) + '小时前';
      } else if (diff < month) {
        return Math.floor(diff / day) + '天前';
      } else if (diff < year) {
        return Math.floor(diff / month) + '个月前';
      } else {
        return Math.floor(diff / year) + '年前';
      }
    },

    // 获取帖子类型文本
    getTypeText(type) {
      const typeMap = {
        daily: '日常',
        lost: '寻宠',
        found: '招领',
        adoption: '领养'
      };
      return typeMap[type] || '未知';
    },

    // 点击帖子
    onPostTap() {
      this.triggerEvent('posttap', {
        postId: this.data.currentPost.id
      });
    },

    // 点击图片
    onImageTap(e) {
      const index = e.currentTarget.dataset.index;
      this.triggerEvent('imagetap', {
        images: this.data.currentPost.images,
        currentIndex: index
      });
    },

    // 点赞
    onLikeTap() {
      const currentPost = this.data.currentPost;
      const newIsLiked = !currentPost.isLiked;
      const newLikes = newIsLiked ? currentPost.likes + 1 : currentPost.likes - 1;
      
      this.setData({
        'currentPost.isLiked': newIsLiked,
        'currentPost.likes': newLikes
      });
      
      this.triggerEvent('like', {
        postId: currentPost.id,
        isLiked: newIsLiked
      });
    },

    // 评论
    onCommentTap() {
      this.triggerEvent('comment', {
        postId: this.data.currentPost.id
      });
    },

    // 分享
    onShareTap() {
      this.triggerEvent('share', {
        postId: this.data.currentPost.id
      });
    },

    // 更多操作
    onMoreTap() {
      this.triggerEvent('more', {
        postId: this.data.currentPost.id
      });
    }
  },

  /**
   * 组件生命周期
   */
  lifetimes: {
    attached: function() {
      // 在组件实例进入页面节点树时执行
      if (this.properties.post) {
        this.processPostData(this.properties.post);
      }
    }
  }
});