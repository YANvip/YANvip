// components/pet-info-card/pet-info-card.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // 宠物数据对象
    pet: {
      type: Object,
      value: {}
    },
    // 是否显示操作按钮区域
    showActions: {
      type: Boolean,
      value: false
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    currentPet: {}
  },

  observers: {
    'pet': function(pet) {
      if (pet) {
        this.setData({
          currentPet: pet
        });
      }
    }
  },

  /**
   * 组件的方法列表
   */
  methods: {
    // 计算宠物年龄
    getPetAge(birthDate) {
      if (!birthDate) return '年龄未知';
      
      const birth = new Date(birthDate);
      const now = new Date();
      
      let age = now.getFullYear() - birth.getFullYear();
      const monthDiff = now.getMonth() - birth.getMonth();
      
      if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < birth.getDate())) {
        age--;
      }
      
      if (age === 0) {
        const months = now.getMonth() - birth.getMonth();
        return `${months}个月`;
      }
      
      return `${age}岁`;
    },
    
    // 点击宠物卡片
    onCardTap() {
      this.triggerEvent('cardtap', {
        petId: this.data.currentPet.id
      });
    }
  }
})