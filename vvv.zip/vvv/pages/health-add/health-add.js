// pages/health-add/health-add.js
Page({
  data: {
    // 记录类型（从参数获取或默认）
    recordType: 'general',
    
    // 表单数据
    formData: {
      // 基础信息
      title: '',
      petId: '',
      date: '',
      type: 'general',
      
      // 详细信息
      description: '',
      hospital: '',
      doctor: '',
      cost: '',
      notes: '',
      
      // 下次提醒
      hasNextDate: false,
      nextDate: '',
      reminderDays: 7,
      reminderNotes: '',
      
      // 状态
      completed: false,
      important: false
    },
    
    // 宠物列表
    pets: [],
    
    // 记录类型选项
    recordTypes: [
      {
        id: 'vaccination',
        name: '疫苗接种',
        icon: '💉',
        color: '#4CAF50',
        fields: ['vaccineName', 'batchNumber', 'manufacturer']
      },
      {
        id: 'deworming',
        name: '驱虫记录',
        icon: '🦠',
        color: '#FF9800',
        fields: ['dewormerType', 'brand', 'dosage']
      },
      {
        id: 'medical',
        name: '医疗记录',
        icon: '🏥',
        color: '#2196F3',
        fields: ['diagnosis', 'symptoms', 'treatment']
      },
      {
        id: 'examination',
        name: '体检记录',
        icon: '📋',
        color: '#009688',
        fields: ['weight', 'temperature', 'heartRate']
      },
      {
        id: 'surgery',
        name: '手术记录',
        icon: '🔪',
        color: '#9C27B0',
        fields: ['surgeryType', 'anesthesia', 'recovery']
      },
      {
        id: 'daily',
        name: '日常护理',
        icon: '✨',
        color: '#FFC107',
        fields: ['careType', 'frequency', 'notes']
      },
      {
        id: 'general',
        name: '一般记录',
        icon: '📝',
        color: '#795548',
        fields: []
      }
    ],
    
    // 当前类型对应的额外字段
    extraFields: [],
    
    // 图片相关
    images: [],
    maxImages: 9,
    uploading: false,
    
    // 表单验证错误
    errors: {},
    
    // 页面状态
    loading: false,
    submitting: false,
    showDatePicker: false,
    showNextDatePicker: false,
    activeSection: 'basic', // basic | details | reminder | images
    
    // 日期选择器配置
    datePicker: {
      current: '',
      start: '2010-01-01',
      end: '2030-12-31'
    },
    
    // 疫苗类型选项（示例）
    vaccineOptions: [
      '狂犬疫苗',
      '犬瘟热疫苗',
      '犬细小病毒疫苗',
      '犬冠状病毒疫苗',
      '猫三联疫苗',
      '猫五联疫苗',
      '其他疫苗'
    ],
    
    // 驱虫药类型选项
    dewormerOptions: [
      '体内驱虫',
      '体外驱虫',
      '内外同驱',
      '其他'
    ]
  },

  onLoad(options) {
    console.log('health-add onLoad', options);
    
    // 获取传递的参数
    const { type, petId } = options || {};
    
    // 初始化页面
    this.initPage(type, petId);
  },

  onShow() {
    // 页面显示时，加载宠物列表
    this.loadPets();
  },

  /**
   * 初始化页面
   */
  initPage(type, petId) {
    const today = this.formatDate(new Date());
    const nextWeek = this.formatDate(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000));
    
    // 设置默认值
    const recordType = type || 'general';
    const selectedType = this.data.recordTypes.find(t => t.id === recordType) || this.data.recordTypes[6];
    
    // 根据类型设置默认标题
    let defaultTitle = '';
    switch (recordType) {
      case 'vaccination':
        defaultTitle = '疫苗接种记录';
        break;
      case 'deworming':
        defaultTitle = '驱虫记录';
        break;
      case 'medical':
        defaultTitle = '医疗就诊记录';
        break;
      case 'examination':
        defaultTitle = '健康体检记录';
        break;
      case 'surgery':
        defaultTitle = '手术记录';
        break;
      default:
        defaultTitle = '健康记录';
    }
    
    this.setData({
      recordType: recordType,
      'formData.type': recordType,
      'formData.title': defaultTitle,
      'formData.date': today,
      'formData.nextDate': nextWeek,
      'formData.petId': petId || '',
      'datePicker.current': today
    });
    
    // 加载类型的额外字段
    this.loadExtraFields(recordType);
    
    // 设置导航栏标题
    wx.setNavigationBarTitle({
      title: `添加${selectedType.name}`
    });
  },

  /**
   * 加载宠物列表
   */
  loadPets() {
    try {
      const pets = wx.getStorageSync('pets') || [];
      
      if (pets.length === 0) {
        // 如果没有宠物，提示用户先添加宠物
        wx.showModal({
          title: '提示',
          content: '请先添加宠物再记录健康信息',
          confirmText: '去添加',
          success: (res) => {
            if (res.confirm) {
              wx.navigateBack();
            }
          }
        });
        return;
      }
      
      this.setData({
        pets: pets.map(pet => ({
          id: pet.id,
          name: pet.name,
          breed: pet.breed,
          avatar: pet.avatar || '/images/default-pet-avatar.png'
        }))
      });
      
      // 如果没有选中宠物，默认选择第一个
      if (!this.data.formData.petId && pets.length > 0) {
        this.setData({
          'formData.petId': pets[0].id
        });
      }
      
    } catch (error) {
      console.error('加载宠物列表失败:', error);
    }
  },

  /**
   * 加载额外字段
   */
  loadExtraFields(type) {
    const typeConfig = this.data.recordTypes.find(t => t.id === type);
    if (!typeConfig) return;
    
    const extraFields = typeConfig.fields.map(field => {
      const fieldConfig = {
        name: field,
        value: '',
        label: this.getFieldLabel(field),
        placeholder: this.getFieldPlaceholder(field),
        type: this.getFieldType(field),
        required: false
      };
      
      // 如果是选择类型的字段，添加选项
      if (field === 'vaccineName') {
        fieldConfig.options = this.data.vaccineOptions;
      } else if (field === 'dewormerType') {
        fieldConfig.options = this.data.dewormerOptions;
      }
      
      return fieldConfig;
    });
    
    this.setData({
      extraFields: extraFields
    });
  },

  /**
   * 获取字段标签
   */
  getFieldLabel(field) {
    const labels = {
      vaccineName: '疫苗名称',
      batchNumber: '批号',
      manufacturer: '生产厂家',
      dewormerType: '驱虫类型',
      brand: '品牌',
      dosage: '剂量',
      diagnosis: '诊断结果',
      symptoms: '症状描述',
      treatment: '治疗方案',
      weight: '体重(kg)',
      temperature: '体温(°C)',
      heartRate: '心率(次/分)',
      surgeryType: '手术类型',
      anesthesia: '麻醉方式',
      recovery: '恢复情况',
      careType: '护理类型',
      frequency: '频率'
    };
    
    return labels[field] || field;
  },

  /**
   * 获取字段占位符
   */
  getFieldPlaceholder(field) {
    const placeholders = {
      vaccineName: '请选择疫苗名称',
      batchNumber: '请输入疫苗批号',
      manufacturer: '请输入生产厂家',
      dewormerType: '请选择驱虫类型',
      brand: '请输入品牌',
      dosage: '例如：1片/次',
      diagnosis: '请输入诊断结果',
      symptoms: '请输入症状描述',
      treatment: '请输入治疗方案',
      weight: '请输入体重',
      temperature: '请输入体温',
      heartRate: '请输入心率',
      surgeryType: '请输入手术类型',
      anesthesia: '请输入麻醉方式',
      recovery: '请输入恢复情况',
      careType: '请输入护理类型',
      frequency: '例如：每天1次'
    };
    
    return placeholders[field] || '请输入内容';
  },

  /**
   * 获取字段类型
   */
  getFieldType(field) {
    const numberFields = ['cost', 'weight', 'temperature', 'heartRate', 'dosage'];
    const selectFields = ['vaccineName', 'dewormerType'];
    
    if (numberFields.includes(field)) {
      return 'number';
    } else if (selectFields.includes(field)) {
      return 'select';
    } else {
      return 'text';
    }
  },

  /**
   * 格式化日期
   */
  formatDate(date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  },

  /**
   * 选择记录类型
   */
  selectRecordType(e) {
    const { type } = e.currentTarget.dataset;
    
    if (type === this.data.recordType) return;
    
    const selectedType = this.data.recordTypes.find(t => t.id === type);
    if (!selectedType) return;
    
    // 更新标题
    let newTitle = this.data.formData.title;
    if (newTitle.includes('记录')) {
      newTitle = newTitle.replace(/[\u4e00-\u9fa5]+记录/, selectedType.name);
    } else {
      newTitle = `${selectedType.name}记录`;
    }
    
    this.setData({
      recordType: type,
      'formData.type': type,
      'formData.title': newTitle,
      extraFields: []
    }, () => {
      // 加载新的额外字段
      this.loadExtraFields(type);
      
      // 更新导航栏标题
      wx.setNavigationBarTitle({
        title: `添加${selectedType.name}`
      });
    });
  },

  /**
   * 输入表单字段
   */
  onInput(e) {
    const { field } = e.currentTarget.dataset;
    const value = e.detail.value;
    
    // 清除该字段的错误
    const newErrors = { ...this.data.errors };
    delete newErrors[field];
    
    this.setData({
      [`formData.${field}`]: value,
      errors: newErrors
    });
  },

  /**
   * 输入额外字段
   */
  onExtraInput(e) {
    const { index, field } = e.currentTarget.dataset;
    const value = e.detail.value;
    
    const extraFields = [...this.data.extraFields];
    extraFields[index].value = value;
    
    this.setData({
      extraFields: extraFields
    });
  },

  /**
   * 选择宠物
   */
  selectPet(e) {
    const { petId } = e.currentTarget.dataset;
    
    this.setData({
      'formData.petId': petId
    });
  },

  /**
   * 切换是否设置下次提醒
   */
  toggleNextDate() {
    this.setData({
      'formData.hasNextDate': !this.data.formData.hasNextDate
    });
  },

  /**
   * 切换重要标记
   */
  toggleImportant() {
    this.setData({
      'formData.important': !this.data.formData.important
    });
  },

  /**
   * 切换完成状态
   */
  toggleCompleted() {
    this.setData({
      'formData.completed': !this.data.formData.completed
    });
  },

  /**
   * 选择日期
   */
  selectDate() {
    this.setData({
      showDatePicker: true
    });
  },

  /**
   * 选择下次提醒日期
   */
  selectNextDate() {
    this.setData({
      showNextDatePicker: true
    });
  },

  /**
   * 日期选择器变化
   */
  onDateChange(e) {
    const value = e.detail.value;
    
    if (this.data.showDatePicker) {
      this.setData({
        'formData.date': value,
        showDatePicker: false
      });
    } else if (this.data.showNextDatePicker) {
      this.setData({
        'formData.nextDate': value,
        showNextDatePicker: false
      });
    }
  },

  /**
   * 取消日期选择
   */
  cancelDatePicker() {
    this.setData({
      showDatePicker: false,
      showNextDatePicker: false
    });
  },

  /**
   * 选择图片
   */
  chooseImages() {
    const { images, maxImages } = this.data;
    const count = maxImages - images.length;
    
    if (count <= 0) {
      wx.showToast({
        title: `最多只能上传${maxImages}张图片`,
        icon: 'none'
      });
      return;
    }
    
    wx.chooseImage({
      count: count,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const tempFilePaths = res.tempFilePaths;
        this.uploadImages(tempFilePaths);
      }
    });
  },

  /**
   * 上传图片
   */
  uploadImages(filePaths) {
    if (this.data.uploading) return;
    
    this.setData({ uploading: true });
    
    const uploadPromises = filePaths.map(filePath => {
      return new Promise((resolve) => {
        // 模拟上传过程
        setTimeout(() => {
          const fileName = `health_${Date.now()}_${Math.random().toString(36).substr(2)}.jpg`;
          resolve({
            url: filePath, // 实际开发中应替换为上传后的URL
            name: fileName,
            status: 'success'
          });
        }, 500);
      });
    });
    
    Promise.all(uploadPromises)
      .then(results => {
        const newImages = [...this.data.images, ...results];
        this.setData({
          images: newImages,
          uploading: false
        });
        
        wx.showToast({
          title: '图片上传成功',
          icon: 'success'
        });
      })
      .catch(error => {
        console.error('图片上传失败:', error);
        this.setData({ uploading: false });
        
        wx.showToast({
          title: '部分图片上传失败',
          icon: 'error'
        });
      });
  },

  /**
   * 预览图片
   */
  previewImage(e) {
    const { index } = e.currentTarget.dataset;
    const urls = this.data.images.map(img => img.url);
    
    wx.previewImage({
      current: urls[index],
      urls: urls
    });
  },

  /**
   * 删除图片
   */
  deleteImage(e) {
    const { index } = e.currentTarget.dataset;
    
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这张图片吗？',
      success: (res) => {
        if (res.confirm) {
          const images = [...this.data.images];
          images.splice(index, 1);
          this.setData({ images });
        }
      }
    });
  },

  /**
   * 切换页面部分
   */
  switchSection(e) {
    const { section } = e.currentTarget.dataset;
    
    if (section === this.data.activeSection) return;
    
    // 验证当前部分
    if (!this.validateCurrentSection()) {
      return;
    }
    
    this.setData({
      activeSection: section
    });
  },

  /**
   * 验证当前部分
   */
  validateCurrentSection() {
    const { activeSection, formData } = this.data;
    const errors = {};
    
    switch (activeSection) {
      case 'basic':
        if (!formData.title.trim()) {
          errors.title = '请填写记录标题';
        }
        if (!formData.petId) {
          errors.petId = '请选择宠物';
        }
        if (!formData.date) {
          errors.date = '请选择记录日期';
        }
        break;
        
      case 'details':
        // 详细信息的验证相对宽松
        break;
    }
    
    if (Object.keys(errors).length > 0) {
      this.setData({ errors });
      
      // 显示第一个错误
      const firstError = Object.values(errors)[0];
      wx.showToast({
        title: firstError,
        icon: 'none'
      });
      
      return false;
    }
    
    return true;
  },

  /**
   * 保存草稿
   */
  saveDraft() {
    if (!this.validateForm()) return;
    
    wx.showModal({
      title: '保存草稿',
      content: '确定要将此记录保存为草稿吗？',
      success: (res) => {
        if (res.confirm) {
          this.submitForm(true);
        }
      }
    });
  },

  /**
   * 提交表单
   */
  submitForm(isDraft = false) {
    if (!this.validateForm()) return;
    
    if (this.data.submitting) return;
    
    this.setData({ submitting: true });
    
    // 收集所有数据
    const recordData = this.collectFormData(isDraft);
    
    // 模拟提交过程
    setTimeout(() => {
      this.saveRecord(recordData, isDraft);
    }, 1000);
  },

  /**
   * 验证整个表单
   */
  validateForm() {
    const { formData } = this.data;
    const errors = {};
    
    // 基础验证
    if (!formData.title.trim()) {
      errors.title = '请填写记录标题';
    }
    if (!formData.petId) {
      errors.petId = '请选择宠物';
    }
    if (!formData.date) {
      errors.date = '请选择记录日期';
    }
    
    // 如果设置了下次提醒，验证下次提醒日期
    if (formData.hasNextDate && !formData.nextDate) {
      errors.nextDate = '请选择下次提醒日期';
    }
    
    // 检查是否有错误
    if (Object.keys(errors).length > 0) {
      this.setData({ errors });
      
      // 显示第一个错误
      const firstError = Object.values(errors)[0];
      wx.showToast({
        title: firstError,
        icon: 'none'
      });
      
      // 跳转到有错误的部分
      if (errors.title || errors.petId || errors.date) {
        this.setData({ activeSection: 'basic' });
      } else if (errors.nextDate) {
        this.setData({ activeSection: 'reminder' });
      }
      
      return false;
    }
    
    return true;
  },

  /**
   * 收集表单数据
   */
  collectFormData(isDraft) {
    const { formData, extraFields, images, recordType, pets } = this.data;
    
    // 获取宠物信息
    const selectedPet = pets.find(pet => pet.id === formData.petId);
    
    // 构建额外字段数据
    const extraData = {};
    extraFields.forEach(field => {
      extraData[field.name] = field.value;
    });
    
    // 构建完整记录
    const record = {
      id: `health_${Date.now()}_${Math.random().toString(36).substr(2)}`,
      petId: formData.petId,
      petName: selectedPet ? selectedPet.name : '',
      type: formData.type,
      title: formData.title,
      date: formData.date,
      description: formData.description,
      hospital: formData.hospital,
      doctor: formData.doctor,
      cost: formData.cost ? parseFloat(formData.cost) : 0,
      notes: formData.notes,
      hasNextDate: formData.hasNextDate,
      nextDate: formData.hasNextDate ? formData.nextDate : null,
      reminderDays: formData.reminderDays || 7,
      reminderNotes: formData.reminderNotes,
      completed: formData.completed,
      important: formData.important,
      isDraft: isDraft,
      images: images.map(img => img.url),
      extraData: extraData,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    return record;
  },

  /**
   * 保存记录
   */
  async saveRecord(record, isDraft) {
    try {
      // 获取现有记录
      let healthRecords = wx.getStorageSync('healthRecords') || [];
      
      // 添加新记录
      healthRecords.unshift(record);
      
      // 保存到缓存
      wx.setStorageSync('healthRecords', healthRecords);
      
      // 如果设置了下次提醒，保存到提醒列表
      if (record.hasNextDate && record.nextDate) {
        this.saveReminder(record);
      }
      
      // 显示成功提示
      wx.showToast({
        title: isDraft ? '保存草稿成功' : '添加记录成功',
        icon: 'success',
        duration: 2000
      });
      
      // 延迟返回
      setTimeout(() => {
        this.setData({ submitting: false });
        
        // 返回上一页
        wx.navigateBack();
        
        // 发送事件通知列表页刷新
        if (getCurrentPages().length > 1) {
          const prevPage = getCurrentPages()[getCurrentPages().length - 2];
          if (prevPage.route === 'pages/health/health') {
            prevPage.onShow();
          }
        }
      }, 1500);
      
    } catch (error) {
      console.error('保存记录失败:', error);
      this.setData({ submitting: false });
      
      wx.showToast({
        title: '保存失败',
        icon: 'error'
      });
    }
  },

  /**
   * 保存提醒
   */
  saveReminder(record) {
    try {
      let reminders = wx.getStorageSync('reminders') || [];
      
      const reminder = {
        id: `reminder_${record.id}`,
        recordId: record.id,
        type: 'health',
        subType: record.type,
        title: `${record.petName} - ${record.title}`,
        petId: record.petId,
        petName: record.petName,
        dueDate: record.nextDate,
        notes: record.reminderNotes,
        completed: false,
        createdAt: new Date().toISOString()
      };
      
      reminders.push(reminder);
      wx.setStorageSync('reminders', reminders);
      
    } catch (error) {
      console.error('保存提醒失败:', error);
    }
  },

  /**
   * 重置表单
   */
  resetForm() {
    wx.showModal({
      title: '重置表单',
      content: '确定要清空所有已填写的内容吗？',
      confirmColor: '#f44336',
      success: (res) => {
        if (res.confirm) {
          const today = this.formatDate(new Date());
          const nextWeek = this.formatDate(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000));
          
          this.setData({
            'formData.title': '',
            'formData.description': '',
            'formData.hospital': '',
            'formData.doctor': '',
            'formData.cost': '',
            'formData.notes': '',
            'formData.date': today,
            'formData.nextDate': nextWeek,
            'formData.reminderNotes': '',
            'formData.completed': false,
            'formData.important': false,
            images: [],
            errors: {},
            activeSection: 'basic'
          });
          
          // 重置额外字段
          this.loadExtraFields(this.data.recordType);
        }
      }
    });
  },

  /**
   * 返回上一页
   */
  goBack() {
    wx.navigateBack();
  },

  /**
   * 键盘完成按钮事件
   */
  onConfirm() {
    // 如果是最后一个输入框，尝试提交
    if (this.data.activeSection === 'images') {
      this.submitForm();
    }
  }
});
// pages/health-add/health-add.js
Page({
  // ... 其他代码
  selectPet(e) {
    // 原代码：const petId = e.currentTarget.dataset.petId;
    const petId = e.currentTarget.dataset.petid; // 同步修改为小写 petid
    this.setData({
      'formData.petId': petId
    });
  },
  // ... 其他代码
});