// pages/community/community.js
const app = getApp()

Page({
  data: {
    // 用户信息
    userInfo: null,
    isLoggedIn: false,
    
    // 标签页
    activeTab: 'recommend',
    tabs: [
      { key: 'recommend', name: '推荐', icon: '🔥' },
      { key: 'follow', name: '关注', icon: '👥' },
      { key: 'hot', name: '热门', icon: '🌟' },
      { key: 'nearby', name: '附近', icon: '📍' }
    ],
    
    // 帖子数据
    posts: [],
    page: 1,
    pageSize: 10,
    hasMore: true,
    isLoading: false,
    isRefreshing: false,
    
    // 筛选条件
    filters: {
      petType: 'all',
      sortBy: 'latest',
      showMineOnly: false
    },
    
    // 推荐宠物（右侧栏）
    recommendedPets: [],
    
    // 热门话题
    hotTopics: [
      { id: 1, name: '宠物医疗', count: 1280, icon: '🏥' },
      { id: 2, name: '养宠心得', count: 890, icon: '💡' },
      { id: 3, name: '萌宠日常', count: 3560, icon: '🐾' },
      { id: 4, name: '走失互助', count: 420, icon: '🔍' },
      { id: 5, name: '宠物领养', count: 210, icon: '🏠' }
    ],
    
    // 活动信息
    activeActivities: [],
    
    // 界面状态
    showFilterModal: false,
    showPostModal: false,
    showLoginModal: false,
    showTopicModal: false,
    showSearch: false,
    searchKeyword: '',
    
    // 新帖内容
    newPost: {
      content: '',
      images: [],
      petId: null,
      topicId: null,
      location: '',
      isPublic: true
    },
    
    // 地理位置
    userLocation: null,
    locationLoading: false,
    
    // 滚动位置
    scrollTop: 0,
    scrollIntoView: '',
    
    // 统计数据
    stats: {
      totalPosts: 0,
      totalUsers: 0,
      onlineUsers: 0
    },
    
    // 安全区域
    safeAreaBottom: 0,
    windowHeight: 0
  },

  onLoad() {
    // 获取设备信息
    this.getSystemInfo()
    
    // 检查登录状态
    this.checkLoginStatus()
    
    // 加载初始数据
    this.loadInitialData()
    
    // 获取地理位置
    this.getUserLocation()
    
    // 监听全局事件
    this.setupEventListeners()
  },

  onShow() {
    // 每次显示页面时检查登录状态
    this.checkLoginStatus()
    
    // 如果已登录，刷新关注列表
    if (this.data.isLoggedIn) {
      this.loadFollowedUsersPosts()
    }
    
    // 检查是否有草稿
    this.checkDraft()
  },

  onPullDownRefresh() {
    this.setData({ isRefreshing: true })
    this.refreshData()
  },

  onReachBottom() {
    if (this.data.hasMore && !this.data.isLoading) {
      this.loadMorePosts()
    }
  },

  onPageScroll(e) {
    this.setData({ scrollTop: e.scrollTop })
  },

  onShareAppMessage() {
    return {
      title: '快来宠物社区分享你的爱宠日常！',
      path: '/pages/community/community',
      imageUrl: '/assets/community-share.jpg'
    }
  },

  getSystemInfo() {
    const systemInfo = wx.getSystemInfoSync()
    this.setData({
      safeAreaBottom: systemInfo.screenHeight - systemInfo.safeArea.bottom,
      windowHeight: systemInfo.windowHeight
    })
  },

  checkLoginStatus() {
    const userInfo = app.globalData.userInfo
    const isLoggedIn = !!userInfo
    
    this.setData({
      userInfo,
      isLoggedIn
    })
    
    if (isLoggedIn && !this.data.newPost.petId) {
      // 默认选择用户的第一个宠物
      const myPets = app.globalData.myPets || []
      if (myPets.length > 0) {
        this.setData({
          'newPost.petId': myPets[0].id
        })
      }
    }
  },

  async loadInitialData() {
    wx.showLoading({ title: '加载中...' })
    
    try {
      // 并行加载多个接口
      await Promise.all([
        this.loadPosts(),
        this.loadCommunityStats(),
        this.loadRecommendedPets(),
        this.loadActivities()
      ])
      
      wx.hideLoading()
    } catch (error) {
      console.error('加载数据失败:', error)
      wx.hideLoading()
      wx.showToast({
        title: '加载失败',
        icon: 'error'
      })
    }
  },

  async loadPosts() {
    if (this.data.isLoading) return
    
    this.setData({ isLoading: true })
    
    try {
      const params = {
        page: this.data.page,
        pageSize: this.data.pageSize,
        tab: this.data.activeTab,
        ...this.data.filters
      }
      
      if (this.data.searchKeyword) {
        params.keyword = this.data.searchKeyword
      }
      
      const response = await app.request({
        url: '/api/community/posts',
        method: 'GET',
        data: params
      })
      
      if (response.code === 0) {
        const newPosts = response.data.posts || []
        const hasMore = newPosts.length === this.data.pageSize
        
        this.setData({
          posts: this.data.page === 1 ? newPosts : [...this.data.posts, ...newPosts],
          hasMore,
          isLoading: false,
          isRefreshing: false
        })
        
        wx.stopPullDownRefresh()
      } else {
        throw new Error(response.msg)
      }
    } catch (error) {
      console.error('加载帖子失败:', error)
      this.setData({
        isLoading: false,
        isRefreshing: false
      })
      wx.stopPullDownRefresh()
      
      wx.showToast({
        title: '加载失败',
        icon: 'error'
      })
    }
  },

  async loadCommunityStats() {
    try {
      const response = await app.request({
        url: '/api/community/stats',
        method: 'GET'
      })
      
      if (response.code === 0) {
        this.setData({ stats: response.data })
      }
    } catch (error) {
      console.error('加载统计数据失败:', error)
    }
  },

  async loadRecommendedPets() {
    try {
      const response = await app.request({
        url: '/api/community/recommended-pets',
        method: 'GET'
      })
      
      if (response.code === 0) {
        this.setData({ recommendedPets: response.data })
      }
    } catch (error) {
      console.error('加载推荐宠物失败:', error)
    }
  },

  async loadActivities() {
    try {
      const response = await app.request({
        url: '/api/community/activities',
        method: 'GET'
      })
      
      if (response.code === 0) {
        this.setData({ activeActivities: response.data })
      }
    } catch (error) {
      console.error('加载活动失败:', error)
    }
  },

  async loadFollowedUsersPosts() {
    if (!this.data.isLoggedIn) return
    
    try {
      const response = await app.request({
        url: '/api/community/following-posts',
        method: 'GET'
      })
      
      if (response.code === 0) {
        // 可以在这里处理关注用户的帖子
      }
    } catch (error) {
      console.error('加载关注帖子失败:', error)
    }
  },

  refreshData() {
    this.setData({ page: 1 })
    this.loadPosts()
    this.loadCommunityStats()
  },

  loadMorePosts() {
    if (!this.data.hasMore || this.data.isLoading) return
    
    this.setData({ page: this.data.page + 1 })
    this.loadPosts()
  },

  getUserLocation() {
    this.setData({ locationLoading: true })
    
    wx.getLocation({
      type: 'wgs84',
      success: (res) => {
        const { latitude, longitude } = res
        this.setData({
          userLocation: { latitude, longitude },
          locationLoading: false
        })
        
        // 逆地理编码获取具体地址
        this.reverseGeocode(latitude, longitude)
      },
      fail: () => {
        this.setData({ locationLoading: false })
      }
    })
  },

  async reverseGeocode(latitude, longitude) {
    try {
      // 这里可以使用腾讯地图或高德地图的API
      // 简化处理，直接存储坐标
      this.setData({
        'newPost.location': `${latitude},${longitude}`
      })
    } catch (error) {
      console.error('逆地理编码失败:', error)
    }
  },

  setupEventListeners() {
    // 监听帖子更新事件
    app.eventBus.on('postUpdated', this.handlePostUpdated.bind(this))
    app.eventBus.on('postDeleted', this.handlePostDeleted.bind(this))
  },

  handlePostUpdated(updatedPost) {
    const posts = this.data.posts.map(post => 
      post.id === updatedPost.id ? { ...post, ...updatedPost } : post
    )
    this.setData({ posts })
  },

  handlePostDeleted(postId) {
    const posts = this.data.posts.filter(post => post.id !== postId)
    this.setData({ posts })
  },

  // 标签切换
  switchTab(e) {
    const { tab } = e.currentTarget.dataset
    
    if (this.data.activeTab === tab) return
    
    this.setData({
      activeTab: tab,
      page: 1,
      posts: []
    }, () => {
      this.loadPosts()
      
      // 滚动到顶部
      this.setData({
        scrollTop: 0,
        scrollIntoView: 'top'
      })
    })
  },

  // 搜索功能
  toggleSearch() {
    this.setData({
      showSearch: !this.data.showSearch,
      searchKeyword: ''
    })
  },

  onSearchInput(e) {
    this.setData({ searchKeyword: e.detail.value })
  },

  onSearchConfirm() {
    this.setData({ page: 1 })
    this.loadPosts()
  },

  clearSearch() {
    this.setData({ searchKeyword: '' })
    this.setData({ page: 1 })
    this.loadPosts()
  },

  // 发布新帖
  showPostModal() {
    if (!this.data.isLoggedIn) {
      this.setData({ showLoginModal: true })
      return
    }
    
    this.setData({ showPostModal: true })
  },

  hidePostModal() {
    this.setData({ showPostModal: false })
  },

  // 帖子内容输入
  onPostContentInput(e) {
    this.setData({ 'newPost.content': e.detail.value })
  },

  // 选择话题
  showTopicModal() {
    this.setData({ showTopicModal: true })
  },

  selectTopic(e) {
    const { topic } = e.currentTarget.dataset
    this.setData({
      'newPost.topicId': topic.id,
      showTopicModal: false
    })
  },

  // 选择宠物
  selectPet(e) {
    const { pet } = e.currentTarget.dataset
    
    if (this.data.newPost.petId === pet.id) {
      this.setData({ 'newPost.petId': null })
    } else {
      this.setData({ 'newPost.petId': pet.id })
    }
  },

  // 上传图片
  uploadImages() {
    if (this.data.newPost.images.length >= 9) {
      wx.showToast({
        title: '最多上传9张图片',
        icon: 'none'
      })
      return
    }
    
    wx.chooseMedia({
      count: 9 - this.data.newPost.images.length,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      sizeType: ['compressed'],
      success: (res) => {
        const tempFiles = res.tempFiles.map(file => file.tempFilePath)
        const images = [...this.data.newPost.images, ...tempFiles]
        
        this.setData({ 'newPost.images': images })
      }
    })
  },

  // 预览图片
  previewImage(e) {
    const { index } = e.currentTarget.dataset
    const images = this.data.newPost.images
    
    wx.previewImage({
      current: images[index],
      urls: images
    })
  },

  // 删除图片
  removeImage(e) {
    const { index } = e.currentTarget.dataset
    const images = [...this.data.newPost.images]
    images.splice(index, 1)
    
    this.setData({ 'newPost.images': images })
  },

  // 发布帖子
  async submitPost() {
    const { content, images, petId } = this.data.newPost
    
    // 验证
    if (!content.trim()) {
      wx.showToast({
        title: '请输入内容',
        icon: 'none'
      })
      return
    }
    
    if (content.length > 1000) {
      wx.showToast({
        title: '内容过长，请精简',
        icon: 'none'
      })
      return
    }
    
    wx.showLoading({ title: '发布中...' })
    
    try {
      // 先上传图片
      let imageUrls = []
      if (images.length > 0) {
        const uploadPromises = images.map(image => this.uploadImage(image))
        imageUrls = await Promise.all(uploadPromises)
      }
      
      // 提交帖子
      const postData = {
        content: content.trim(),
        images: imageUrls,
        petId,
        topicId: this.data.newPost.topicId,
        location: this.data.newPost.location,
        isPublic: this.data.newPost.isPublic
      }
      
      const response = await app.request({
        url: '/api/community/posts',
        method: 'POST',
        data: postData
      })
      
      if (response.code === 0) {
        wx.hideLoading()
        wx.showToast({
          title: '发布成功',
          icon: 'success'
        })
        
        // 清空表单
        this.resetNewPost()
        this.hidePostModal()
        
        // 刷新帖子列表
        this.refreshData()
      } else {
        throw new Error(response.msg)
      }
    } catch (error) {
      wx.hideLoading()
      wx.showToast({
        title: error.message || '发布失败',
        icon: 'error'
      })
    }
  },

  async uploadImage(filePath) {
    return new Promise((resolve, reject) => {
      wx.uploadFile({
        url: `${app.globalData.apiBase}/api/upload`,
        filePath: filePath,
        name: 'file',
        formData: {
          type: 'post'
        },
        success: (res) => {
          const result = JSON.parse(res.data)
          if (result.code === 0) {
            resolve(result.data.url)
          } else {
            reject(new Error(result.msg))
          }
        },
        fail: reject
      })
    })
  },

  resetNewPost() {
    this.setData({
      newPost: {
        content: '',
        images: [],
        petId: this.data.userInfo && app.globalData.myPets?.[0]?.id || null,
        topicId: null,
        location: '',
        isPublic: true
      }
    })
  },

  // 保存草稿
  saveDraft() {
    const draft = {
      content: this.data.newPost.content,
      images: this.data.newPost.images,
      timestamp: Date.now()
    }
    
    wx.setStorageSync('postDraft', draft)
    wx.showToast({
      title: '已保存草稿',
      icon: 'success'
    })
  },

  checkDraft() {
    const draft = wx.getStorageSync('postDraft')
    if (draft) {
      wx.showModal({
        title: '发现草稿',
        content: '是否继续编辑未发布的帖子？',
        success: (res) => {
          if (res.confirm) {
            this.setData({
              'newPost.content': draft.content,
              'newPost.images': draft.images,
              showPostModal: true
            })
            
            // 清除草稿
            wx.removeStorageSync('postDraft')
          } else {
            // 删除草稿
            wx.removeStorageSync('postDraft')
          }
        }
      })
    }
  },

  // 筛选功能
  showFilterModal() {
    this.setData({ showFilterModal: true })
  },

  hideFilterModal() {
    this.setData({ showFilterModal: false })
  },

  updateFilter(e) {
    const { field } = e.currentTarget.dataset
    const { value } = e.detail
    
    this.setData({
      [`filters.${field}`]: value
    })
  },

  applyFilters() {
    this.hideFilterModal()
    this.setData({ page: 1 })
    this.loadPosts()
  },

  resetFilters() {
    this.setData({
      filters: {
        petType: 'all',
        sortBy: 'latest',
        showMineOnly: false
      }
    })
  },

  // 话题点击
  onTopicClick(e) {
    const { topic } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/community-topic/community-topic?id=${topic.id}`
    })
  },

  // 宠物点击
  onPetClick(e) {
    const { pet } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/public-pet-info/public-pet-info?id=${pet.id}`
    })
  },

  // 活动点击
  onActivityClick(e) {
    const { activity } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/community-activity/community-activity?id=${activity.id}`
    })
  },

  // 点赞帖子
  async likePost(e) {
    if (!this.data.isLoggedIn) {
      this.setData({ showLoginModal: true })
      return
    }
    
    const { postId, liked } = e.currentTarget.dataset
    
    try {
      const response = await app.request({
        url: `/api/community/posts/${postId}/like`,
        method: liked ? 'DELETE' : 'POST'
      })
      
      if (response.code === 0) {
        // 更新本地数据
        const posts = this.data.posts.map(post => {
          if (post.id === postId) {
            const likeCount = liked ? post.likeCount - 1 : post.likeCount + 1
            return {
              ...post,
              liked: !liked,
              likeCount
            }
          }
          return post
        })
        
        this.setData({ posts })
      }
    } catch (error) {
      console.error('点赞失败:', error)
      wx.showToast({
        title: '操作失败',
        icon: 'error'
      })
    }
  },

  // 收藏帖子
  async collectPost(e) {
    if (!this.data.isLoggedIn) {
      this.setData({ showLoginModal: true })
      return
    }
    
    const { postId, collected } = e.currentTarget.dataset
    
    try {
      const response = await app.request({
        url: `/api/community/posts/${postId}/collect`,
        method: collected ? 'DELETE' : 'POST'
      })
      
      if (response.code === 0) {
        // 更新本地数据
        const posts = this.data.posts.map(post => {
          if (post.id === postId) {
            return { ...post, collected: !collected }
          }
          return post
        })
        
        this.setData({ posts })
      }
    } catch (error) {
      console.error('收藏失败:', error)
      wx.showToast({
        title: '操作失败',
        icon: 'error'
      })
    }
  },

  // 分享帖子
  sharePost(e) {
    const { postId } = e.currentTarget.dataset
    const post = this.data.posts.find(p => p.id === postId)
    
    if (!post) return
    
    wx.showActionSheet({
      itemList: ['分享给好友', '复制链接', '生成海报'],
      success: (res) => {
        switch (res.tapIndex) {
          case 0:
            this.shareToFriend(post)
            break
          case 1:
            this.copyPostLink(post)
            break
          case 2:
            this.generatePostPoster(post)
            break
        }
      }
    })
  },

  shareToFriend(post) {
    wx.shareAppMessage({
      title: `${post.user.nickname}的分享`,
      path: `/pages/community-post-detail/community-post-detail?id=${post.id}`,
      imageUrl: post.images?.[0] || '/assets/default-post.jpg'
    })
  },

  copyPostLink(post) {
    const link = `${app.globalData.appBaseUrl}/pages/community-post-detail/community-post-detail?id=${post.id}`
    
    wx.setClipboardData({
      data: link,
      success: () => {
        wx.showToast({
          title: '链接已复制',
          icon: 'success'
        })
      }
    })
  },

  generatePostPoster(post) {
    wx.showLoading({ title: '生成中...' })
    
    // 这里可以调用后端生成海报的接口
    setTimeout(() => {
      wx.hideLoading()
      wx.showToast({
        title: '生成成功',
        icon: 'success'
      })
    }, 1000)
  },

  // 评论帖子
  commentPost(e) {
    const { postId } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/community-post-detail/community-post-detail?id=${postId}&focus=comment`
    })
  },

  // 用户点击
  onUserClick(e) {
    const { userId } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/community-user/community-user?id=${userId}`
    })
  },

  // 查看帖子详情
  viewPostDetail(e) {
    const { postId } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/community-post-detail/community-post-detail?id=${postId}`
    })
  },

  // 登录处理
  handleLoginSuccess(userInfo) {
    this.setData({
      userInfo,
      isLoggedIn: true,
      showLoginModal: false
    })
    
    // 重新加载数据
    this.refreshData()
  },

  closeLoginModal() {
    this.setData({ showLoginModal: false })
  },

  // 滚动到顶部
  scrollToTop() {
    this.setData({
      scrollTop: 0,
      scrollIntoView: 'top'
    })
  },

  // 加载占位符
  getPlaceholderPosts() {
    return Array(5).fill().map((_, index) => ({
      id: `placeholder-${index}`,
      isPlaceholder: true
    }))
  }
})
// community.js
Page({
  data: {
    // 使用下划线命名
    is_loading: false,
    is_refreshing: false,
    is_logged_in: false,
    scroll_top: 0,
    scroll_into_view: '',
    window_height: 0,
    search_keyword: '',
    show_search: false,
    show_post_modal: false,
    show_filter_modal: false,
    show_topic_modal: false,
    show_login_modal: false,
    
    // 统计数据
    stats: {
      total_posts: 0,
      total_users: 0,
      online_users: 0
    },
    
    // 其他数据...
  },
  
  onLoad() {
    // 获取窗口高度
    wx.getSystemInfo({
      success: (res) => {
        this.setData({
          window_height: res.windowHeight * 2 // 转换为rpx
        });
      }
    });
    
    // 获取用户登录状态
    const app = getApp();
    this.setData({
      is_logged_in: !!app.globalData.userInfo,
      my_pets: app.globalData.pets || []
    });
  }
});