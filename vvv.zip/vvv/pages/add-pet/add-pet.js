// pages/add-pet/add-pet.js
const app = getApp()
const request = require('../../utils/request')
const { showToast, showModal, chooseImage } = require('../../utils/wxapi')
const { formatDate, validatePhone, getPetTypeIcon } = require('../../utils/util')

Page({
  data: {
    // 页面状态
    loading: false,
    isEditing: false,
    petId: null,
    fromScan: false,
    qrCode: '',
    
    // 表单数据
    formData: {
      // 宠物基本信息
      name: '',
      type: 'dog',
      breed: '',
      gender: 'male',
      birthDate: '',
      weight: '',
      color: '',
      avatar: '🐕',
      description: '',
      
      // 芯片信息
      chipId: '',
      microchipNumber: '',
      
      // 主人信息
      ownerName: '',
      ownerPhone: '',
      ownerAddress: '',
      ownerWechat: '',
      
      // 紧急联系人
      emergencyContact: '',
      emergencyPhone: '',
      emergencyRelation: '',
      
      // 隐私设置
      isPublic: true,
      showOwnerInfo: true,
      allowContact: true,
      
      // 医疗信息
      healthStatus: 'healthy',
      neutered: false,
      neuteredDate: '',
      
      // 其他信息
      habits: '',
      allergies: '',
      favoriteFood: '',
      favoriteToy: ''
    },
    
    // 表单验证错误
    errors: {},
    
    // 选择器数据
    petTypes: [
      { value: 'dog', label: '狗狗', icon: '🐕' },
      { value: 'cat', label: '猫咪', icon: '🐈' },
      { value: 'rabbit', label: '兔子', icon: '🐇' },
      { value: 'bird', label: '鸟类', icon: '🐦' },
      { value: 'fish', label: '鱼类', icon: '🐠' },
      { value: 'other', label: '其他', icon: '🐾' }
    ],
    
    genders: [
      { value: 'male', label: '男孩' },
      { value: 'female', label: '女孩' },
      { value: 'unknown', label: '未知' }
    ],
    
    healthStatuses: [
      { value: 'healthy', label: '健康' },
      { value: 'sick', label: '生病' },
      { value: 'injured', label: '受伤' },
      { value: 'recovering', label: '恢复中' }
    ],
    
    // 品种数据
    breedOptions: {
      dog: [
        { value: 'golden_retriever', label: '金毛寻回犬' },
        { value: 'labrador', label: '拉布拉多犬' },
        { value: 'poodle', label: '贵宾犬' },
        { value: 'samoyed', label: '萨摩耶犬' },
        { value: 'husky', label: '哈士奇' },
        { value: 'pembroke_welsh_corgi', label: '柯基犬' },
        { value: 'chihuahua', label: '吉娃娃' },
        { value: 'pug', label: '巴哥犬' },
        { value: 'shih_tzu', label: '西施犬' },
        { value: 'other', label: '其他品种' }
      ],
      cat: [
        { value: 'british_shorthair', label: '英国短毛猫' },
        { value: 'american_shorthair', label: '美国短毛猫' },
        { value: 'persian', label: '波斯猫' },
        { value: 'siamese', label: '暹罗猫' },
        { value: 'ragdoll', label: '布偶猫' },
        { value: 'munchkin', label: '曼基康猫' },
        { value: 'scottish_fold', label: '苏格兰折耳猫' },
        { value: 'other', label: '其他品种' }
      ],
      rabbit: [
        { value: 'dwarf', label: '侏儒兔' },
        { value: 'lop', label: '垂耳兔' },
        { value: 'rex', label: '雷克斯兔' },
        { value: 'other', label: '其他品种' }
      ],
      bird: [
        { value: 'parrot', label: '鹦鹉' },
        { value: 'finch', label: '雀类' },
        { value: 'other', label: '其他品种' }
      ],
      fish: [
        { value: 'goldfish', label: '金鱼' },
        { value: 'tropical', label: '热带鱼' },
        { value: 'other', label: '其他品种' }
      ],
      other: [
        { value: 'hamster', label: '仓鼠' },
        { value: 'turtle', label: '龟类' },
        { value: 'other', label: '其他' }
      ]
    },
    
    // 当前选择的品种列表
    currentBreedOptions: [],
    
    // 颜色选择
    colorOptions: [
      '白色', '黑色', '棕色', '灰色', '黄色', '金色', '花色', '混色', '其他'
    ],
    
    // 页面控制
    currentStep: 1, // 1:基本信息, 2:主人信息, 3:医疗信息, 4:其他信息
    totalSteps: 4,
    
    // 上传的图片
    uploadedImages: [],
    maxImages: 9,
    
    // 计算出的年龄
    calculatedAge: ''
  },

  onLoad(options) {
    this.initPage(options)
  },

  onShow() {
    // 检查登录状态
    if (!app.globalData.isLogged) {
      this.showLoginModal()
      return
    }
  },

  // 初始化页面
  async initPage(options) {
    // 设置默认数据
    const today = formatDate(new Date(), 'YYYY-MM-DD')
    this.setData({
      'formData.birthDate': today,
      'formData.ownerName': app.globalData.userInfo?.nickName || '',
      'formData.ownerWechat': app.globalData.userInfo?.nickName || ''
    })
    
    // 检查参数
    if (options) {
      // 编辑模式
      if (options.petId) {
        await this.loadPetData(options.petId)
        this.setData({
          isEditing: true,
          petId: options.petId
        })
        wx.setNavigationBarTitle({
          title: '编辑宠物信息'
        })
      }
      
      // 从扫码过来
      if (options.qrCode) {
        this.setData({
          fromScan: true,
          qrCode: options.qrCode,
          'formData.chipId': options.qrCode
        })
      }
      
      // 直接指定芯片号
      if (options.chipId) {
        this.setData({
          'formData.chipId': options.chipId
        })
      }
    }
    
    // 初始化品种选项
    this.updateBreedOptions()
  },

  // 加载宠物数据
  async loadPetData(petId) {
    this.setData({ loading: true })
    
    try {
      // 尝试从后端加载
      const pet = await request.get(`/pets/${petId}`, {
        showLoading: true
      })
      
      if (pet) {
        this.fillFormData(pet)
      } else {
        // 从本地缓存加载
        const pets = app.globalData.pets || []
        const localPet = pets.find(p => p.id === petId)
        if (localPet) {
          this.fillFormData(localPet)
        } else {
          throw new Error('未找到宠物信息')
        }
      }
    } catch (error) {
      console.error('加载宠物数据失败:', error)
      showToast(error.message || '加载失败', 'none')
      
      // 返回上一页
      setTimeout(() => {
        wx.navigateBack()
      }, 1500)
    } finally {
      this.setData({ loading: false })
    }
  },

  // 填充表单数据
  fillFormData(pet) {
    // 基本转换
    const formData = {
      name: pet.name || '',
      type: pet.type || 'dog',
      breed: pet.breed || '',
      gender: pet.gender || 'male',
      birthDate: pet.birthDate || '',
      weight: pet.weight ? String(pet.weight) : '',
      color: pet.color || '',
      avatar: pet.avatar || getPetTypeIcon(pet.type),
      description: pet.description || '',
      
      chipId: pet.chipId || '',
      microchipNumber: pet.microchipNumber || '',
      
      ownerName: pet.ownerName || '',
      ownerPhone: pet.ownerPhone || '',
      ownerAddress: pet.ownerAddress || '',
      ownerWechat: pet.ownerWechat || '',
      
      emergencyContact: pet.emergencyContact || '',
      emergencyPhone: pet.emergencyPhone || '',
      emergencyRelation: pet.emergencyRelation || '',
      
      isPublic: pet.isPublic !== false,
      showOwnerInfo: pet.showOwnerInfo !== false,
      allowContact: pet.allowContact !== false,
      
      healthStatus: pet.healthStatus || 'healthy',
      neutered: !!pet.neutered,
      neuteredDate: pet.neuteredDate || '',
      
      habits: pet.habits || '',
      allergies: pet.allergies || '',
      favoriteFood: pet.favoriteFood || '',
      favoriteToy: pet.favoriteToy || ''
    }
    
    this.setData({
      formData: formData,
      calculatedAge: pet.age || ''
    })
    
    // 更新品种选项
    this.updateBreedOptions()
  },

  // 更新品种选项
  updateBreedOptions() {
    const type = this.data.formData.type
    const options = this.data.breedOptions[type] || this.data.breedOptions.other
    this.setData({
      currentBreedOptions: options
    })
  },

  // 表单输入处理
  onInput(e) {
    const { field } = e.currentTarget.dataset
    const value = e.detail.value
    
    this.setData({
      [`formData.${field}`]: value
    })
    
    // 清除该字段的错误
    if (this.data.errors[field]) {
      this.setData({
        [`errors.${field}`]: ''
      })
    }
    
    // 特殊字段处理
    if (field === 'birthDate') {
      this.calculateAge(value)
    } else if (field === 'type') {
      this.updateBreedOptions()
      // 自动更新头像
      const selectedType = this.data.petTypes.find(t => t.value === value)
      if (selectedType && !this.data.formData.avatar) {
        this.setData({
          'formData.avatar': selectedType.icon
        })
      }
    }
  },

  // 数字输入
  onNumberInput(e) {
    const { field } = e.currentTarget.dataset
    let value = e.detail.value
    
    // 验证是否为数字
    if (value && !/^\d*\.?\d*$/.test(value)) {
      return
    }
    
    this.setData({
      [`formData.${field}`]: value
    })
  },

  // 选择器改变
  onPickerChange(e) {
    const { field } = e.currentTarget.dataset
    const value = e.detail.value
    
    this.setData({
      [`formData.${field}`]: value
    })
    
    // 特殊处理
    if (field === 'type') {
      this.updateBreedOptions()
    }
  },

  // 切换开关
  onSwitchChange(e) {
    const { field } = e.currentTarget.dataset
    const value = e.detail.value
    
    this.setData({
      [`formData.${field}`]: value
    })
  },

  // 计算年龄
  calculateAge(birthDate) {
    if (!birthDate) {
      this.setData({ calculatedAge: '' })
      return
    }
    
    const birth = new Date(birthDate)
    const today = new Date()
    
    let years = today.getFullYear() - birth.getFullYear()
    let months = today.getMonth() - birth.getMonth()
    let days = today.getDate() - birth.getDate()
    
    if (days < 0) {
      months--
      days += new Date(today.getFullYear(), today.getMonth(), 0).getDate()
    }
    
    if (months < 0) {
      years--
      months += 12
    }
    
    let age = ''
    if (years > 0) {
      age = `${years}岁${months > 0 ? months + '个月' : ''}`
    } else if (months > 0) {
      age = `${months}个月${days > 0 ? days + '天' : ''}`
    } else if (days > 0) {
      age = `${days}天`
    } else {
      age = '新生儿'
    }
    
    this.setData({ calculatedAge: age })
  },

  // 选择头像
  async onSelectAvatar() {
    const avatars = ['🐕', '🐈', '🐇', '🐦', '🐠', '🐢', '🐭', '🦜', '🦔', '🐿️', '🐾', '❤️']
    
    const result = await new Promise((resolve) => {
      wx.showActionSheet({
        itemList: avatars,
        success: (res) => {
          resolve(res.tapIndex)
        },
        fail: () => {
          resolve(-1)
        }
      })
    })
    
    if (result >= 0 && result < avatars.length) {
      this.setData({
        'formData.avatar': avatars[result]
      })
    }
  },

  // 上传图片
  async onUploadImage() {
    if (this.data.uploadedImages.length >= this.data.maxImages) {
      showToast(`最多上传${this.data.maxImages}张图片`, 'none')
      return
    }
    
    try {
      const res = await chooseImage(this.data.maxImages - this.data.uploadedImages.length)
      if (res.tempFilePaths.length > 0) {
        // 显示上传进度
        const uploadedImages = [...this.data.uploadedImages]
        
        for (let i = 0; i < res.tempFilePaths.length; i++) {
          const filePath = res.tempFilePaths[i]
          
          // 这里应该上传到服务器，暂时先保存本地路径
          uploadedImages.push({
            id: Date.now() + i,
            path: filePath,
            isUploading: true
          })
        }
        
        this.setData({ uploadedImages })
        
        // 模拟上传过程
        setTimeout(() => {
          const updatedImages = this.data.uploadedImages.map(img => ({
            ...img,
            isUploading: false
          }))
          this.setData({ uploadedImages: updatedImages })
          showToast('图片上传完成', 'success')
        }, 1000)
      }
    } catch (error) {
      console.error('选择图片失败:', error)
      showToast('选择图片失败', 'none')
    }
  },

  // 删除图片
  onDeleteImage(e) {
    const { index } = e.currentTarget.dataset
    const uploadedImages = [...this.data.uploadedImages]
    uploadedImages.splice(index, 1)
    this.setData({ uploadedImages })
  },

  // 预览图片
  onPreviewImage(e) {
    const { index } = e.currentTarget.dataset
    const urls = this.data.uploadedImages.map(img => img.path)
    wx.previewImage({
      current: urls[index],
      urls: urls
    })
  },

  // 验证表单
  validateForm(step) {
    const errors = {}
    const form = this.data.formData
    
    // 基础验证
    if (!form.name.trim()) {
      errors.name = '请填写宠物名称'
    }
    
    if (!form.type) {
      errors.type = '请选择宠物类型'
    }
    
    if (step >= 2) {
      // 主人信息验证
      if (!form.ownerName.trim()) {
        errors.ownerName = '请填写主人姓名'
      }
      
      if (!form.ownerPhone.trim()) {
        errors.ownerPhone = '请填写联系电话'
      } else if (!validatePhone(form.ownerPhone)) {
        errors.ownerPhone = '请输入正确的手机号码'
      }
    }
    
    if (step >= 3) {
      // 紧急联系人验证
      if (form.emergencyContact && !form.emergencyPhone) {
        errors.emergencyPhone = '请填写紧急联系人电话'
      } else if (form.emergencyPhone && !validatePhone(form.emergencyPhone)) {
        errors.emergencyPhone = '请输入正确的手机号码'
      }
    }
    
    this.setData({ errors })
    return Object.keys(errors).length === 0
  },

  // 下一步
  onNextStep() {
    if (!this.validateForm(this.data.currentStep)) {
      showToast('请完善必填信息', 'none')
      return
    }
    
    if (this.data.currentStep < this.data.totalSteps) {
      this.setData({
        currentStep: this.data.currentStep + 1
      })
      
      // 滚动到顶部
      wx.pageScrollTo({
        scrollTop: 0,
        duration: 300
      })
    }
  },

  // 上一步
  onPrevStep() {
    if (this.data.currentStep > 1) {
      this.setData({
        currentStep: this.data.currentStep - 1
      })
      
      // 滚动到顶部
      wx.pageScrollTo({
        scrollTop: 0,
        duration: 300
      })
    }
  },

  // 跳转到指定步骤
  onJumpToStep(e) {
    const { step } = e.currentTarget.dataset
    const stepNum = parseInt(step)
    
    if (stepNum >= 1 && stepNum <= this.data.totalSteps) {
      // 验证之前的步骤
      let valid = true
      for (let i = 1; i < stepNum; i++) {
        if (!this.validateForm(i)) {
          valid = false
          break
        }
      }
      
      if (valid) {
        this.setData({ currentStep: stepNum })
        
        // 滚动到顶部
        wx.pageScrollTo({
          scrollTop: 0,
          duration: 300
        })
      } else {
        showToast('请先完成前面的必填项', 'none')
      }
    }
  },

  // 提交表单
  async onSubmit() {
    if (!this.validateForm(this.data.totalSteps)) {
      showToast('请完善必填信息', 'none')
      return
    }
    
    // 确认提交
    showModal('确认提交', '确定要保存宠物信息吗？').then(async (confirm) => {
      if (!confirm) return
      
      await this.savePet()
    })
  },

  // 保存宠物信息
  async savePet() {
    this.setData({ loading: true })
    
    try {
      const petData = this.preparePetData()
      
      let result
      if (this.data.isEditing) {
        // 更新宠物
        result = await request.put(`/pets/${this.data.petId}`, petData)
        showToast('更新成功', 'success')
      } else {
        // 添加宠物
        result = await request.post('/pets', petData)
        showToast('添加成功', 'success')
      }
      
      // 更新本地数据
      await this.updateLocalData(result)
      
      // 返回到上一页或宠物详情页
      setTimeout(() => {
        if (this.data.fromScan) {
          // 从扫码过来的，返回扫码结果页
          wx.navigateBack({ delta: 2 })
        } else if (this.data.isEditing) {
          // 编辑完成，返回宠物详情
          wx.navigateBack()
        } else {
          // 添加完成，跳转到宠物详情
          wx.navigateTo({
            url: `/pages/pet-detail/pet-detail?petId=${result.id}`
          })
        }
      }, 1500)
      
    } catch (error) {
      console.error('保存宠物失败:', error)
      showToast(error.message || '保存失败', 'none')
    } finally {
      this.setData({ loading: false })
    }
  },

  // 准备宠物数据
  preparePetData() {
    const form = this.data.formData
    const user = app.globalData.userInfo
    
    // 生成二维码（如果是从扫码过来的，使用扫码的二维码）
    let qrCode = this.data.qrCode
    if (!qrCode) {
      // 生成唯一二维码
      qrCode = `PET_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    }
    
    return {
      // 基本信息
      name: form.name.trim(),
      type: form.type,
      breed: form.breed,
      gender: form.gender,
      birthDate: form.birthDate,
      age: this.data.calculatedAge,
      weight: form.weight ? parseFloat(form.weight) : null,
      color: form.color,
      avatar: form.avatar,
      description: form.description.trim(),
      
      // 芯片信息
      chipId: form.chipId.trim(),
      microchipNumber: form.microchipNumber.trim(),
      qrCode: qrCode,
      
      // 主人信息
      ownerId: user?.id || '',
      ownerName: form.ownerName.trim(),
      ownerPhone: form.ownerPhone.trim(),
      ownerAddress: form.ownerAddress.trim(),
      ownerWechat: form.ownerWechat.trim(),
      
      // 紧急联系人
      emergencyContact: form.emergencyContact.trim(),
      emergencyPhone: form.emergencyPhone.trim(),
      emergencyRelation: form.emergencyRelation.trim(),
      
      // 隐私设置
      isPublic: form.isPublic,
      showOwnerInfo: form.showOwnerInfo,
      allowContact: form.allowContact,
      
      // 医疗信息
      healthStatus: form.healthStatus,
      neutered: form.neutered,
      neuteredDate: form.neuteredDate,
      
      // 其他信息
      habits: form.habits.trim(),
      allergies: form.allergies.trim(),
      favoriteFood: form.favoriteFood.trim(),
      favoriteToy: form.favoriteToy.trim(),
      
      // 图片
      images: this.data.uploadedImages.map(img => ({
        url: img.path,
        isMain: false
      })),
      
      // 状态
      status: 'active',
      isRegistered: true,
      registrationDate: new Date().toISOString().split('T')[0]
    }
  },

  // 更新本地数据
  async updateLocalData(pet) {
    // 更新应用全局数据
    if (this.data.isEditing) {
      // 更新现有宠物
      app.updatePetInGlobal(pet.id, pet)
    } else {
      // 添加新宠物
      app.addPetToGlobal(pet)
    }
    
    // 保存到本地存储
    const pets = app.globalData.pets || []
    wx.setStorageSync('pets', pets)
    
    // 如果是从扫码绑定，更新二维码绑定状态
    if (this.data.qrCode) {
      wx.setStorageSync(`qr_${this.data.qrCode}`, {
        petId: pet.id,
        boundAt: new Date().toISOString()
      })
    }
  },

  // 显示登录弹窗
  showLoginModal() {
    showModal('登录提示', '添加宠物需要先登录，是否立即登录？').then((confirm) => {
      if (confirm) {
        wx.navigateTo({
          url: '/pages/login/login'
        })
      } else {
        wx.navigateBack()
      }
    })
  },

  // 快速填充示例数据
  onFillExample() {
    const examples = [
      {
        name: '旺财',
        type: 'dog',
        breed: 'golden_retriever',
        gender: 'male',
        birthDate: '2022-05-15',
        weight: '25.5',
        color: '金色',
        avatar: '🐕',
        description: '活泼可爱的金毛犬，喜欢玩球和游泳'
      },
      {
        name: '咪咪',
        type: 'cat',
        breed: 'british_shorthair',
        gender: 'female',
        birthDate: '2021-08-20',
        weight: '4.2',
        color: '灰色',
        avatar: '🐈',
        description: '温顺的英短猫，喜欢睡觉和晒太阳'
      }
    ]
    
    const randomExample = examples[Math.floor(Math.random() * examples.length)]
    
    this.setData({
      formData: {
        ...this.data.formData,
        ...randomExample
      }
    })
    
    // 计算年龄
    this.calculateAge(randomExample.birthDate)
    
    // 更新品种选项
    this.updateBreedOptions()
    
    showToast('示例数据已填充', 'success')
  },

  // 清空表单
  onClearForm() {
    showModal('确认清空', '确定要清空所有表单数据吗？').then((confirm) => {
      if (!confirm) return
      
      const today = formatDate(new Date(), 'YYYY-MM-DD')
      this.setData({
        formData: {
          ...this.data.formData,
          name: '',
          breed: '',
          birthDate: today,
          weight: '',
          color: '',
          description: '',
          chipId: '',
          microchipNumber: '',
          ownerName: app.globalData.userInfo?.nickName || '',
          ownerPhone: '',
          ownerAddress: '',
          emergencyContact: '',
          emergencyPhone: '',
          habits: '',
          allergies: '',
          favoriteFood: '',
          favoriteToy: ''
        },
        uploadedImages: [],
        calculatedAge: '',
        errors: {}
      })
      
      showToast('表单已清空', 'success')
    })
  },

  // 扫描芯片
  onScanChip() {
    wx.scanCode({
      onlyFromCamera: true,
      scanType: ['qrCode', 'barCode'],
      success: (res) => {
        const result = res.result
        this.setData({
          'formData.chipId': result
        })
        showToast('芯片扫描成功', 'success')
      },
      fail: () => {
        showToast('扫描失败，请手动输入', 'none')
      }
    })
  },

  // 获取当前位置
  onGetLocation() {
    wx.getLocation({
      type: 'gcj02',
      success: (res) => {
        // 将坐标转换为地址
        wx.chooseLocation({
          latitude: res.latitude,
          longitude: res.longitude,
          success: (locationRes) => {
            this.setData({
              'formData.ownerAddress': locationRes.address || locationRes.name
            })
          }
        })
      },
      fail: () => {
        showToast('获取位置失败', 'none')
      }
    })
  },

  // 页面卸载
  onUnload() {
    // 清理数据
    if (this.data.loading) {
      this.setData({ loading: false })
    }
  },

  // 错误处理
  onError(e) {
    console.error('页面错误:', e)
    showToast('页面加载失败，请重试', 'none')
  }
})
// add-pet.js 中需要添加
Page({
  data: {
    today: '', // 今日日期
    currentBreedIndex: 0,
    breedText: '',
    petTypeText: '',
  },
  
  onLoad() {
    // 设置今日日期
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];
    this.setData({ today: todayStr });
    
    // 其他预处理...
  }
});