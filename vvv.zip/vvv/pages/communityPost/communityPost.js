// pages/communityPost/communityPost.js
const app = getApp()

Page({
  data: {
    // 帖子数据
    postId: null,
    post: null,
    isLoading: true,
    isRefreshing: false,
    isOwner: false,
    hasPermission: false,
    
    // 评论相关
    comments: [],
    commentPage: 1,
    commentPageSize: 20,
    hasMoreComments: true,
    isCommentLoading: false,
    commentCount: 0,
    
    // 评论输入
    commentInput: '',
    replyTo: null, // 回复对象 {id, name, type: 'comment'|'user'}
    isCommenting: false,
    commentFocus: false,
    
    // 点赞收藏
    liked: false,
    collected: false,
    likeCount: 0,
    collectCount: 0,
    
    // 操作菜单
    showActionSheet: false,
    showDeleteConfirm: false,
    showReportModal: false,
    showShareMenu: false,
    showCommentMenu: false,
    selectedCommentId: null,
    
    // 举报相关
    reportReasons: [
      '广告或垃圾信息',
      '不友善内容',
      '色情低俗',
      '违法信息',
      '侵犯隐私',
      '其他原因'
    ],
    reportReason: '',
    reportDescription: '',
    
    // 分享选项
    shareOptions: [
      { name: '分享给好友', icon: '👥', type: 'friend' },
      { name: '生成分享海报', icon: '🖼️', type: 'poster' },
      { name: '复制链接', icon: '🔗', type: 'link' },
      { name: '保存图片', icon: '📱', type: 'save' }
    ],
    
    // 评论操作菜单
    commentActions: [
      { name: '回复', icon: '↩️', type: 'reply' },
      { name: '点赞', icon: '❤️', type: 'like' },
      { name: '复制', icon: '📋', type: 'copy' },
      { name: '举报', icon: '⚠️', type: 'report' }
    ],
    
    // 用户信息
    userInfo: null,
    isLoggedIn: false,
    
    // 图片预览
    previewImages: [],
    previewIndex: 0,
    
    // 滚动位置
    scrollTop: 0,
    scrollIntoView: '',
    
    // 安全区域
    safeAreaBottom: 0,
    keyboardHeight: 0,
    
    // 编辑相关
    showEditModal: false,
    editContent: '',
    editImages: [],
    isEditing: false,
    
    // 热门评论
    hotComments: [],
    
    // 相关帖子
    relatedPosts: []
  },

  onLoad(options) {
    const { id, commentId, focus } = options
    
    if (!id) {
      wx.showToast({
        title: '帖子不存在',
        icon: 'error',
        complete: () => {
          setTimeout(() => wx.navigateBack(), 1500)
        }
      })
      return
    }
    
    // 获取安全区域
    const systemInfo = wx.getSystemInfoSync()
    this.setData({
      safeAreaBottom: systemInfo.screenHeight - systemInfo.safeArea.bottom,
      postId: id
    })
    
    // 检查登录状态
    this.checkLoginStatus()
    
    // 加载帖子数据
    this.loadPostDetail(id)
    
    // 如果有评论ID，滚动到该评论
    if (commentId) {
      setTimeout(() => {
        this.scrollToComment(commentId)
      }, 1000)
    }
    
    // 如果需要聚焦评论框
    if (focus === 'comment') {
      setTimeout(() => {
        this.focusCommentInput()
      }, 800)
    }
    
    // 监听键盘事件
    this.listenKeyboard()
  },

  onShow() {
    // 每次显示时检查登录状态
    this.checkLoginStatus()
    
    // 如果帖子已加载，刷新点赞收藏状态
    if (this.data.post) {
      this.checkLikeCollectStatus()
    }
  },

  onHide() {
    // 移除键盘监听
    this.removeKeyboardListeners()
  },

  onUnload() {
    // 清理资源
    this.removeKeyboardListeners()
  },

  onPullDownRefresh() {
    this.setData({ isRefreshing: true })
    this.refreshData()
  },

  onReachBottom() {
    if (this.data.hasMoreComments && !this.data.isCommentLoading) {
      this.loadMoreComments()
    }
  },

  onPageScroll(e) {
    this.setData({ scrollTop: e.scrollTop })
  },

  onShareAppMessage() {
    const post = this.data.post
    if (!post) return {}
    
    return {
      title: post.content.substring(0, 50) + (post.content.length > 50 ? '...' : ''),
      path: `/pages/communityPost/communityPost?id=${post.id}`,
      imageUrl: post.images?.[0] || '/assets/default-post.jpg'
    }
  },

  onShareTimeline() {
    const post = this.data.post
    if (!post) return {}
    
    return {
      title: post.content.substring(0, 50) + (post.content.length > 50 ? '...' : ''),
      imageUrl: post.images?.[0] || '/assets/default-post.jpg'
    }
  },

  // 键盘监听
  listenKeyboard() {
    wx.onKeyboardHeightChange((res) => {
      this.setData({
        keyboardHeight: res.height
      })
    })
  },

  removeKeyboardListeners() {
    wx.offKeyboardHeightChange()
  },

  checkLoginStatus() {
    const userInfo = app.globalData.userInfo
    const isLoggedIn = !!userInfo
    
    this.setData({
      userInfo,
      isLoggedIn
    })
  },

  async loadPostDetail(postId) {
    this.setData({ isLoading: true })
    
    try {
      const response = await app.request({
        url: `/api/community/posts/${postId}`,
        method: 'GET'
      })
      
      if (response.code === 0) {
        const post = response.data
        const userInfo = app.globalData.userInfo
        
        // 检查是否是帖子主人
        const isOwner = userInfo && userInfo.id === post.user.id
        
        // 检查是否有操作权限
        const hasPermission = isOwner || (userInfo && userInfo.role === 'admin')
        
        this.setData({
          post: post,
          isOwner: isOwner,
          hasPermission: hasPermission,
          liked: post.liked || false,
          collected: post.collected || false,
          likeCount: post.likeCount || 0,
          collectCount: post.collectCount || 0,
          commentCount: post.commentCount || 0,
          isLoading: false,
          isRefreshing: false
        })
        
        // 设置导航栏标题
        wx.setNavigationBarTitle({
          title: post.user.nickname + '的帖子'
        })
        
        // 加载评论
        this.loadComments()
        
        // 加载相关帖子
        this.loadRelatedPosts()
        
        // 加载热门评论
        this.loadHotComments()
        
      } else {
        throw new Error(response.msg || '加载失败')
      }
    } catch (error) {
      console.error('加载帖子详情失败:', error)
      this.setData({
        isLoading: false,
        isRefreshing: false
      })
      wx.showToast({
        title: error.message || '加载失败',
        icon: 'error'
      })
      wx.stopPullDownRefresh()
    }
  },

  async loadComments() {
    if (this.data.isCommentLoading) return
    
    this.setData({ isCommentLoading: true })
    
    try {
      const response = await app.request({
        url: `/api/community/posts/${this.data.postId}/comments`,
        method: 'GET',
        data: {
          page: this.data.commentPage,
          pageSize: this.data.commentPageSize
        }
      })
      
      if (response.code === 0) {
        const newComments = response.data.comments || []
        const hasMore = newComments.length === this.data.commentPageSize
        
        this.setData({
          comments: this.data.commentPage === 1 ? newComments : [...this.data.comments, ...newComments],
          hasMoreComments: hasMore,
          commentCount: response.data.total || 0,
          isCommentLoading: false
        })
      } else {
        throw new Error(response.msg)
      }
    } catch (error) {
      console.error('加载评论失败:', error)
      this.setData({ isCommentLoading: false })
    }
  },

  async loadHotComments() {
    try {
      const response = await app.request({
        url: `/api/community/posts/${this.data.postId}/comments/hot`,
        method: 'GET'
      })
      
      if (response.code === 0) {
        this.setData({ hotComments: response.data })
      }
    } catch (error) {
      console.error('加载热门评论失败:', error)
    }
  },

  async loadRelatedPosts() {
    try {
      const response = await app.request({
        url: `/api/community/posts/${this.data.postId}/related`,
        method: 'GET'
      })
      
      if (response.code === 0) {
        this.setData({ relatedPosts: response.data })
      }
    } catch (error) {
      console.error('加载相关帖子失败:', error)
    }
  },

  refreshData() {
    this.setData({
      commentPage: 1,
      comments: []
    })
    this.loadPostDetail(this.data.postId)
  },

  loadMoreComments() {
    if (!this.data.hasMoreComments || this.data.isCommentLoading) return
    
    this.setData({ commentPage: this.data.commentPage + 1 })
    this.loadComments()
  },

  // 点赞帖子
  async likePost() {
    if (!this.data.isLoggedIn) {
      this.showLoginModal()
      return
    }
    
    const liked = !this.data.liked
    const likeCount = liked ? this.data.likeCount + 1 : this.data.likeCount - 1
    
    // 立即更新UI
    this.setData({
      liked: liked,
      likeCount: likeCount
    })
    
    try {
      const response = await app.request({
        url: `/api/community/posts/${this.data.postId}/like`,
        method: liked ? 'POST' : 'DELETE'
      })
      
      if (response.code !== 0) {
        // 失败时回滚
        this.setData({
          liked: !liked,
          likeCount: liked ? this.data.likeCount - 1 : this.data.likeCount + 1
        })
        throw new Error(response.msg)
      }
    } catch (error) {
      console.error('点赞失败:', error)
      wx.showToast({
        title: '操作失败',
        icon: 'error'
      })
    }
  },

  // 收藏帖子
  async collectPost() {
    if (!this.data.isLoggedIn) {
      this.showLoginModal()
      return
    }
    
    const collected = !this.data.collected
    const collectCount = collected ? this.data.collectCount + 1 : this.data.collectCount - 1
    
    // 立即更新UI
    this.setData({
      collected: collected,
      collectCount: collectCount
    })
    
    try {
      const response = await app.request({
        url: `/api/community/posts/${this.data.postId}/collect`,
        method: collected ? 'POST' : 'DELETE'
      })
      
      if (response.code !== 0) {
        // 失败时回滚
        this.setData({
          collected: !collected,
          collectCount: collected ? this.data.collectCount - 1 : this.data.collectCount + 1
        })
        throw new Error(response.msg)
      }
    } catch (error) {
      console.error('收藏失败:', error)
      wx.showToast({
        title: '操作失败',
        icon: 'error'
      })
    }
  },

  // 检查点赞收藏状态
  async checkLikeCollectStatus() {
    if (!this.data.isLoggedIn) return
    
    try {
      const response = await app.request({
        url: `/api/community/posts/${this.data.postId}/interaction-status`,
        method: 'GET'
      })
      
      if (response.code === 0) {
        this.setData({
          liked: response.data.liked || false,
          collected: response.data.collected || false
        })
      }
    } catch (error) {
      console.error('检查交互状态失败:', error)
    }
  },

  // 评论输入
  onCommentInput(e) {
    this.setData({ commentInput: e.detail.value })
  },

  // 聚焦评论输入框
  focusCommentInput() {
    this.setData({ commentFocus: true })
  },

  // 设置回复对象
  setReplyTo(commentId, userName, type = 'comment') {
    this.setData({
      replyTo: {
        id: commentId,
        name: userName,
        type: type
      },
      commentFocus: true
    })
  },

  // 清除回复对象
  clearReplyTo() {
    this.setData({
      replyTo: null,
      commentInput: ''
    })
  },

  // 提交评论
  async submitComment() {
    if (!this.data.isLoggedIn) {
      this.showLoginModal()
      return
    }
    
    const content = this.data.commentInput.trim()
    if (!content) {
      wx.showToast({
        title: '请输入评论内容',
        icon: 'none'
      })
      return
    }
    
    if (content.length > 500) {
      wx.showToast({
        title: '评论内容过长',
        icon: 'none'
      })
      return
    }
    
    this.setData({ isCommenting: true })
    
    try {
      const commentData = {
        content: content,
        postId: this.data.postId
      }
      
      // 如果是回复评论
      if (this.data.replyTo && this.data.replyTo.type === 'comment') {
        commentData.parentId = this.data.replyTo.id
      }
      
      // 如果是回复用户
      if (this.data.replyTo && this.data.replyTo.type === 'user') {
        commentData.replyToUserId = this.data.replyTo.id
      }
      
      const response = await app.request({
        url: `/api/community/comments`,
        method: 'POST',
        data: commentData
      })
      
      if (response.code === 0) {
        // 清空输入框
        this.setData({
          commentInput: '',
          replyTo: null,
          isCommenting: false
        })
        
        // 添加新评论到列表
        const newComment = response.data
        this.setData({
          comments: [newComment, ...this.data.comments],
          commentCount: this.data.commentCount + 1
        })
        
        // 如果当前有热门评论区域，可能需要更新
        if (this.data.hotComments.length < 3) {
          this.loadHotComments()
        }
        
        wx.showToast({
          title: '评论成功',
          icon: 'success'
        })
      } else {
        throw new Error(response.msg)
      }
    } catch (error) {
      console.error('提交评论失败:', error)
      this.setData({ isCommenting: false })
      wx.showToast({
        title: error.message || '评论失败',
        icon: 'error'
      })
    }
  },

  // 点赞评论
  async likeComment(e) {
    if (!this.data.isLoggedIn) {
      this.showLoginModal()
      return
    }
    
    const { commentId, liked } = e.currentTarget.dataset
    
    try {
      const response = await app.request({
        url: `/api/community/comments/${commentId}/like`,
        method: liked ? 'DELETE' : 'POST'
      })
      
      if (response.code === 0) {
        // 更新评论列表
        const comments = this.data.comments.map(comment => {
          if (comment.id === commentId) {
            const likeCount = liked ? comment.likeCount - 1 : comment.likeCount + 1
            return {
              ...comment,
              liked: !liked,
              likeCount: likeCount
            }
          }
          return comment
        })
        
        this.setData({ comments })
        
        // 更新热门评论
        const hotComments = this.data.hotComments.map(comment => {
          if (comment.id === commentId) {
            const likeCount = liked ? comment.likeCount - 1 : comment.likeCount + 1
            return {
              ...comment,
              liked: !liked,
              likeCount: likeCount
            }
          }
          return comment
        })
        
        this.setData({ hotComments })
      }
    } catch (error) {
      console.error('点赞评论失败:', error)
      wx.showToast({
        title: '操作失败',
        icon: 'error'
      })
    }
  },

  // 显示评论操作菜单
  showCommentActionSheet(e) {
    const { commentId } = e.currentTarget.dataset
    this.setData({
      selectedCommentId: commentId,
      showCommentMenu: true
    })
  },

  // 处理评论操作
  async handleCommentAction(e) {
    const { type } = e.currentTarget.dataset
    const commentId = this.data.selectedCommentId
    const comment = this.data.comments.find(c => c.id === commentId) || 
                    this.data.hotComments.find(c => c.id === commentId)
    
    this.setData({ showCommentMenu: false })
    
    switch (type) {
      case 'reply':
        this.setReplyTo(commentId, comment.user.nickname, 'comment')
        break
      case 'like':
        this.likeComment({ currentTarget: { dataset: { commentId, liked: comment.liked } } })
        break
      case 'copy':
        wx.setClipboardData({
          data: comment.content,
          success: () => {
            wx.showToast({
              title: '已复制',
              icon: 'success'
            })
          }
        })
        break
      case 'report':
        this.showReportModal('comment', commentId)
        break
    }
  },

  // 删除评论
  async deleteComment(commentId) {
    try {
      const response = await app.request({
        url: `/api/community/comments/${commentId}`,
        method: 'DELETE'
      })
      
      if (response.code === 0) {
        // 从评论列表中移除
        const comments = this.data.comments.filter(c => c.id !== commentId)
        const hotComments = this.data.hotComments.filter(c => c.id !== commentId)
        
        this.setData({
          comments,
          hotComments,
          commentCount: Math.max(0, this.data.commentCount - 1)
        })
        
        wx.showToast({
          title: '删除成功',
          icon: 'success'
        })
      }
    } catch (error) {
      console.error('删除评论失败:', error)
      wx.showToast({
        title: '删除失败',
        icon: 'error'
      })
    }
  },

  // 显示操作菜单
  showActionSheet() {
    const actions = ['分享', '举报']
    
    // 如果是帖子主人或管理员，添加编辑和删除选项
    if (this.data.hasPermission) {
      actions.unshift('编辑', '删除')
    }
    
    wx.showActionSheet({
      itemList: actions,
      success: (res) => {
        const action = actions[res.tapIndex]
        switch (action) {
          case '编辑':
            this.editPost()
            break
          case '删除':
            this.showDeleteConfirmModal()
            break
          case '分享':
            this.showShareMenu()
            break
          case '举报':
            this.showReportModal('post', this.data.postId)
            break
        }
      }
    })
  },

  // 编辑帖子
  editPost() {
    const post = this.data.post
    this.setData({
      showEditModal: true,
      editContent: post.content,
      editImages: post.images || []
    })
  },

  // 更新编辑内容
  onEditContentInput(e) {
    this.setData({ editContent: e.detail.value })
  },

  // 保存编辑
  async saveEdit() {
    const content = this.data.editContent.trim()
    if (!content) {
      wx.showToast({
        title: '请输入内容',
        icon: 'none'
      })
      return
    }
    
    this.setData({ isEditing: true })
    
    try {
      const response = await app.request({
        url: `/api/community/posts/${this.data.postId}`,
        method: 'PUT',
        data: {
          content: content,
          images: this.data.editImages
        }
      })
      
      if (response.code === 0) {
        // 更新帖子数据
        this.setData({
          'post.content': content,
          'post.images': this.data.editImages,
          showEditModal: false,
          isEditing: false
        })
        
        wx.showToast({
          title: '编辑成功',
          icon: 'success'
        })
      } else {
        throw new Error(response.msg)
      }
    } catch (error) {
      console.error('编辑帖子失败:', error)
      this.setData({ isEditing: false })
      wx.showToast({
        title: error.message || '编辑失败',
        icon: 'error'
      })
    }
  },

  // 显示删除确认
  showDeleteConfirmModal() {
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这个帖子吗？此操作不可恢复。',
      confirmColor: '#f44336',
      success: (res) => {
        if (res.confirm) {
          this.deletePost()
        }
      }
    })
  },

  // 删除帖子
  async deletePost() {
    try {
      const response = await app.request({
        url: `/api/community/posts/${this.data.postId}`,
        method: 'DELETE'
      })
      
      if (response.code === 0) {
        wx.showToast({
          title: '删除成功',
          icon: 'success',
          complete: () => {
            // 返回上一页
            setTimeout(() => {
              wx.navigateBack()
            }, 1500)
          }
        })
        
        // 广播帖子删除事件
        app.eventBus.emit('postDeleted', this.data.postId)
      }
    } catch (error) {
      console.error('删除帖子失败:', error)
      wx.showToast({
        title: '删除失败',
        icon: 'error'
      })
    }
  },

  // 显示分享菜单
  showShareMenu() {
    this.setData({ showShareMenu: true })
  },

  // 处理分享操作
  async handleShareAction(e) {
    const { type } = e.currentTarget.dataset
    this.setData({ showShareMenu: false })
    
    switch (type) {
      case 'friend':
        this.shareToFriend()
        break
      case 'poster':
        this.generateSharePoster()
        break
      case 'link':
        this.copyShareLink()
        break
      case 'save':
        this.savePostImage()
        break
    }
  },

  // 分享给好友
  shareToFriend() {
    const post = this.data.post
    wx.shareAppMessage({
      title: `${post.user.nickname}的分享`,
      path: `/pages/communityPost/communityPost?id=${post.id}`,
      imageUrl: post.images?.[0] || '/assets/default-post.jpg'
    })
  },

  // 生成分享海报
  async generateSharePoster() {
    wx.showLoading({ title: '生成中...' })
    
    try {
      const response = await app.request({
        url: `/api/share/poster`,
        method: 'POST',
        data: {
          postId: this.data.postId,
          type: 'post'
        }
      })
      
      if (response.code === 0) {
        const posterUrl = response.data.url
        
        // 预览海报
        wx.previewImage({
          current: posterUrl,
          urls: [posterUrl]
        })
      }
    } catch (error) {
      wx.showToast({
        title: '生成失败',
        icon: 'error'
      })
    } finally {
      wx.hideLoading()
    }
  },

  // 复制分享链接
  copyShareLink() {
    const link = `${app.globalData.appBaseUrl}/pages/communityPost/communityPost?id=${this.data.postId}`
    
    wx.setClipboardData({
      data: link,
      success: () => {
        wx.showToast({
          title: '链接已复制',
          icon: 'success'
        })
      }
    })
  },

  // 保存帖子图片
  savePostImage() {
    const post = this.data.post
    if (!post.images || post.images.length === 0) {
      wx.showToast({
        title: '该帖子没有图片',
        icon: 'none'
      })
      return
    }
    
    wx.showActionSheet({
      itemList: ['保存第一张', '保存所有图片'],
      success: (res) => {
        if (res.tapIndex === 0) {
          this.saveImageToAlbum(post.images[0])
        } else {
          this.saveAllImages(post.images)
        }
      }
    })
  },

  // 保存单张图片
  saveImageToAlbum(url) {
    wx.showLoading({ title: '保存中...' })
    
    wx.downloadFile({
      url: url,
      success: (res) => {
        wx.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
          success: () => {
            wx.showToast({
              title: '保存成功',
              icon: 'success'
            })
          },
          fail: (err) => {
            if (err.errMsg.includes('auth')) {
              this.showAuthModal('scope.writePhotosAlbum')
            } else {
              wx.showToast({
                title: '保存失败',
                icon: 'error'
              })
            }
          }
        })
      },
      fail: () => {
        wx.showToast({
          title: '下载失败',
          icon: 'error'
        })
      },
      complete: () => {
        wx.hideLoading()
      }
    })
  },

  // 保存所有图片
  async saveAllImages(images) {
    wx.showLoading({ title: `保存中 0/${images.length}` })
    
    let successCount = 0
    for (let i = 0; i < images.length; i++) {
      try {
        await this.downloadAndSave(images[i])
        successCount++
        wx.showLoading({ title: `保存中 ${successCount}/${images.length}` })
      } catch (error) {
        console.error('保存图片失败:', error)
      }
    }
    
    wx.hideLoading()
    wx.showToast({
      title: `成功保存${successCount}张图片`,
      icon: 'success'
    })
  },

  downloadAndSave(url) {
    return new Promise((resolve, reject) => {
      wx.downloadFile({
        url: url,
        success: (res) => {
          wx.saveImageToPhotosAlbum({
            filePath: res.tempFilePath,
            success: resolve,
            fail: reject
          })
        },
        fail: reject
      })
    })
  },

  // 显示权限申请
  showAuthModal(scope) {
    wx.showModal({
      title: '权限申请',
      content: '需要相册权限才能保存图片',
      confirmText: '去设置',
      success: (res) => {
        if (res.confirm) {
          wx.openSetting()
        }
      }
    })
  },

  // 显示举报模态框
  showReportModal(type, targetId) {
    this.setData({
      showReportModal: true,
      reportType: type,
      reportTargetId: targetId,
      reportReason: '',
      reportDescription: ''
    })
  },

  // 提交举报
  async submitReport() {
    if (!this.data.reportReason) {
      wx.showToast({
        title: '请选择举报原因',
        icon: 'none'
      })
      return
    }
    
    try {
      const response = await app.request({
        url: '/api/report',
        method: 'POST',
        data: {
          type: this.data.reportType,
          targetId: this.data.reportTargetId,
          reason: this.data.reportReason,
          description: this.data.reportDescription
        }
      })
      
      if (response.code === 0) {
        this.setData({ showReportModal: false })
        wx.showToast({
          title: '举报成功',
          icon: 'success'
        })
      }
    } catch (error) {
      console.error('提交举报失败:', error)
      wx.showToast({
        title: '举报失败',
        icon: 'error'
      })
    }
  },

  // 图片预览
  previewImage(e) {
    const { index } = e.currentTarget.dataset
    const images = this.data.post.images
    
    if (images && images.length > 0) {
      this.setData({
        previewImages: images,
        previewIndex: index
      })
      
      wx.previewImage({
        current: images[index],
        urls: images
      })
    }
  },

  // 查看用户主页
  viewUserProfile(e) {
    const { userId } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/community-user/community-user?id=${userId}`
    })
  },

  // 查看宠物信息
  viewPetProfile(e) {
    const { petId } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/public-pet-info/public-pet-info?id=${petId}`
    })
  },

  // 滚动到评论
  scrollToComment(commentId) {
    this.setData({
      scrollIntoView: `comment-${commentId}`
    })
  },

  // 显示登录模态框
  showLoginModal() {
    wx.showModal({
      title: '需要登录',
      content: '登录后可以点赞、评论、收藏',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login?redirect=' + encodeURIComponent('/pages/communityPost/communityPost?id=' + this.data.postId)
          })
        }
      }
    })
  },

  // 返回上一页
  goBack() {
    wx.navigateBack()
  },

  // 滚动到顶部
  scrollToTop() {
    this.setData({
      scrollTop: 0,
      scrollIntoView: 'top'
    })
  },

  // 格式化时间
  formatTime(time) {
    const date = new Date(time)
    const now = new Date()
    const diff = now - date
    
    // 小于1分钟
    if (diff < 60000) {
      return '刚刚'
    }
    
    // 小于1小时
    if (diff < 3600000) {
      return Math.floor(diff / 60000) + '分钟前'
    }
    
    // 小于1天
    if (diff < 86400000) {
      return Math.floor(diff / 3600000) + '小时前'
    }
    
    // 小于7天
    if (diff < 604800000) {
      return Math.floor(diff / 86400000) + '天前'
    }
    
    // 显示日期
    return `${date.getMonth() + 1}月${date.getDate()}日`
  }
})