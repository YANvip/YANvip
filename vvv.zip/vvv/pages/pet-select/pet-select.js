// pages/pet-select/pet-select.js
const app = getApp();
const { request, showLoading, hideLoading, showToast } = require('../../utils/util');

Page({
  data: {
    // 查询参数
    searchKeyword: '',
    activeFilter: 'all',
    
    // 宠物数据
    allPets: [],          // 所有宠物
    filteredPets: [],     // 筛选后的宠物
    
    // 选择状态
    selectedPetId: null,
    selectedPet: null,
    
    // 页面参数
    pageTitle: '选择宠物',
    selectionMode: 'single', // 选择模式：single, multiple
    maxSelection: 1,         // 最大选择数量
    
    // 状态映射
    statusMap: {
      active: '健康',
      pending: '待完善',
      lost: '走失'
    }
  },

  onLoad(options) {
    // 解析页面参数
    this.parsePageOptions(options);
    
    // 设置页面标题
    if (this.data.pageTitle) {
      wx.setNavigationBarTitle({
        title: this.data.pageTitle
      });
    }
    
    // 加载宠物列表
    this.loadPets();
  },

  onShow() {
    // 如果全局数据有变化，重新加载
    if (app.globalData.petsUpdated) {
      this.loadPets();
      app.globalData.petsUpdated = false;
    }
  },

  // 解析页面参数
  parsePageOptions(options) {
    const {
      title = '选择宠物',
      mode = 'single',
      max = '1',
      selectedId = '',
      filter = 'all'
    } = options;

    this.setData({
      pageTitle: decodeURIComponent(title),
      selectionMode: mode,
      maxSelection: parseInt(max, 10) || 1,
      selectedPetId: selectedId || null,
      activeFilter: filter
    });

    // 如果是多选模式，初始化已选择的宠物数组
    if (mode === 'multiple') {
      const selectedIds = selectedId ? selectedId.split(',').map(id => id.trim()) : [];
      this.setData({
        selectedPetIds: selectedIds,
        selectedPets: []
      });
    }
  },

  // 加载宠物列表
  async loadPets() {
    try {
      showLoading('加载中...');
      
      // 优先从服务器获取
      const res = await request({
        url: '/api/pets/my-pets',
        method: 'GET'
      });
      
      if (res.code === 0 && res.data) {
        const pets = res.data.list || res.data || [];
        this.processPetsData(pets);
      } else {
        // 服务器失败时从本地缓存读取
        this.loadPetsFromLocal();
      }
    } catch (error) {
      console.error('加载宠物列表失败:', error);
      // 网络错误时从本地缓存读取
      this.loadPetsFromLocal();
    } finally {
      hideLoading();
    }
  },

  // 从本地缓存加载
  loadPetsFromLocal() {
    try {
      const localPets = wx.getStorageSync('petList') || [];
      this.processPetsData(localPets);
    } catch (error) {
      console.error('从本地加载宠物列表失败:', error);
      showToast('加载失败');
    }
  },

  // 处理宠物数据
  processPetsData(pets) {
    // 设置已选中的宠物
    let selectedPet = null;
    if (this.data.selectedPetId) {
      selectedPet = pets.find(pet => pet.id === this.data.selectedPetId) || null;
    }
    
    this.setData({
      allPets: pets,
      filteredPets: this.filterPets(pets, this.data.searchKeyword, this.data.activeFilter),
      selectedPet: selectedPet
    });
  },

  // 筛选宠物
  filterPets(pets, keyword, filter) {
    return pets.filter(pet => {
      // 搜索关键词筛选
      if (keyword && keyword.trim()) {
        const searchLower = keyword.toLowerCase();
        const nameMatch = pet.name && pet.name.toLowerCase().includes(searchLower);
        const breedMatch = pet.breed && pet.breed.toLowerCase().includes(searchLower);
        if (!nameMatch && !breedMatch) return false;
      }
      
      // 类型筛选
      if (filter === 'dog' && pet.type !== 'dog') return false;
      if (filter === 'cat' && pet.type !== 'cat') return false;
      
      // 状态筛选
      if (filter === 'active' && pet.status !== 'active') return false;
      if (filter === 'pending' && pet.status !== 'pending') return false;
      
      return true;
    });
  },

  // 搜索输入处理
  onSearchInput(e) {
    const keyword = e.detail.value;
    this.setData({
      searchKeyword: keyword,
      filteredPets: this.filterPets(this.data.allPets, keyword, this.data.activeFilter)
    });
  },

  // 搜索确认
  onSearchConfirm(e) {
    const keyword = e.detail.value;
    this.setData({
      searchKeyword: keyword,
      filteredPets: this.filterPets(this.data.allPets, keyword, this.data.activeFilter)
    });
  },

  // 清除搜索
  clearSearch() {
    this.setData({
      searchKeyword: '',
      filteredPets: this.filterPets(this.data.allPets, '', this.data.activeFilter)
    });
  },

  // 切换筛选标签
  changeFilter(e) {
    const filter = e.currentTarget.dataset.filter;
    this.setData({
      activeFilter: filter,
      filteredPets: this.filterPets(this.data.allPets, this.data.searchKeyword, filter)
    });
  },

  // 选择宠物
  selectPet(e) {
    const pet = e.currentTarget.dataset.pet;
    
    if (this.data.selectionMode === 'multiple') {
      // 多选模式
      this.handleMultiSelect(pet);
    } else {
      // 单选模式
      this.handleSingleSelect(pet);
    }
  },

  // 处理单选选择
  handleSingleSelect(pet) {
    if (this.data.selectedPetId === pet.id) {
      // 取消选择
      this.setData({
        selectedPetId: null,
        selectedPet: null
      });
    } else {
      // 选择新宠物
      this.setData({
        selectedPetId: pet.id,
        selectedPet: pet
      });
    }
  },

  // 处理多选选择
  handleMultiSelect(pet) {
    let selectedIds = [...(this.data.selectedPetIds || [])];
    let selectedPets = [...(this.data.selectedPets || [])];
    
    const index = selectedIds.indexOf(pet.id);
    
    if (index > -1) {
      // 取消选择
      selectedIds.splice(index, 1);
      selectedPets.splice(index, 1);
    } else {
      // 检查是否达到最大选择数量
      if (selectedIds.length >= this.data.maxSelection) {
        showToast(`最多只能选择${this.data.maxSelection}个宠物`);
        return;
      }
      
      // 添加选择
      selectedIds.push(pet.id);
      selectedPets.push(pet);
    }
    
    this.setData({
      selectedPetIds: selectedIds,
      selectedPets: selectedPets
    });
  },

  // 确认选择
  confirmSelection() {
    const { selectionMode, selectedPet, selectedPets } = this.data;
    
    if (selectionMode === 'single') {
      if (!selectedPet) {
        showToast('请先选择一个宠物');
        return;
      }
      
      // 返回选择的宠物信息给上一页
      const pages = getCurrentPages();
      const prevPage = pages[pages.length - 2];
      
      if (prevPage && prevPage.onPetSelected) {
        prevPage.onPetSelected(selectedPet);
      }
      
      // 返回上一页
      wx.navigateBack();
    } else {
      // 多选模式
      if (!selectedPets || selectedPets.length === 0) {
        showToast('请至少选择一个宠物');
        return;
      }
      
      const pages = getCurrentPages();
      const prevPage = pages[pages.length - 2];
      
      if (prevPage && prevPage.onPetsSelected) {
        prevPage.onPetsSelected(selectedPets);
      }
      
      wx.navigateBack();
    }
  },

  // 计算年龄
  calculateAge(birthDate) {
    if (!birthDate) return '?';
    
    const birth = new Date(birthDate);
    const now = new Date();
    let age = now.getFullYear() - birth.getFullYear();
    
    const monthDiff = now.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < birth.getDate())) {
      age--;
    }
    
    return age < 1 ? '<1' : age;
  },

  // 获取状态文本
  getStatusText(status) {
    return this.data.statusMap[status] || '未知';
  },

  // 跳转到添加宠物
  goToAddPet() {
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  // 用户点击右上角分享
  onShareAppMessage() {
    return {
      title: '选择宠物',
      path: '/pages/pet-select/pet-select'
    };
  }
});