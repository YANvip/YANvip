// pages/index-guest/index-guest.js
Page({
  data: {
    // 轮播图
    banners: [
      {
        id: 1,
        image: '/images/banner1.jpg',
        title: '专业的宠物管理',
        desc: '一站式宠物信息管理平台'
      },
      {
        id: 2,
        image: '/images/banner2.jpg',
        title: '健康无忧',
        desc: '宠物健康提醒与医疗记录'
      },
      {
        id: 3,
        image: '/images/banner3.jpg',
        title: '社区交流',
        desc: '与万千宠友分享养宠经验'
      }
    ],
    
    // 核心功能介绍
    features: [
      {
        id: 'qr',
        icon: '📱',
        title: '二维码管理',
        desc: '一宠一码，快速查看信息',
        color: '#4CAF50'
      },
      {
        id: 'health',
        icon: '🏥',
        title: '健康管理',
        desc: '疫苗接种、驱虫等提醒',
        color: '#2196F3'
      },
      {
        id: 'community',
        icon: '👥',
        title: '社区互动',
        desc: '分享经验，互帮互助',
        color: '#FF9800'
      },
      {
        id: 'emergency',
        icon: '🆘',
        title: '紧急求助',
        desc: '宠物丢失快速求助',
        color: '#f44336'
      }
    ],
    
    // 用户案例
    userStories: [
      {
        id: 1,
        user: '张先生',
        pet: '柯基"豆豆"',
        content: '用宠物管家管理狗狗的健康记录，再也不会忘记打疫苗的时间了！',
        avatar: '/images/avatar1.jpg'
      },
      {
        id: 2,
        user: '李女士',
        pet: '英短"咪咪"',
        content: '社区的宠友都很热心，帮我解决了好多养猫的困惑。',
        avatar: '/images/avatar2.jpg'
      },
      {
        id: 3,
        user: '王小姐',
        pet: '泰迪"宝宝"',
        content: '二维码太方便了！带狗狗出门扫一扫就知道信息。',
        avatar: '/images/avatar3.jpg'
      }
    ],
    
    // 统计数据
    stats: [
      {
        number: '10万+',
        label: '注册用户'
      },
      {
        number: '20万+',
        label: '宠物信息'
      },
      {
        number: '50万+',
        label: '健康记录'
      },
      {
        number: '5万+',
        label: '求助成功'
      }
    ],
    
    // 如何使用步骤
    howToUse: [
      {
        step: 1,
        icon: '📱',
        title: '扫码绑定',
        desc: '扫描宠物牌上的二维码'
      },
      {
        step: 2,
        icon: '📝',
        title: '填写信息',
        desc: '登记宠物基本信息'
      },
      {
        step: 3,
        icon: '👥',
        title: '加入社区',
        desc: '与其他宠友交流经验'
      },
      {
        step: 4,
        icon: '🏥',
        title: '健康管理',
        desc: '记录健康信息和提醒'
      }
    ],
    
    // 页面状态
    currentBanner: 0,
    autoplay: true,
    interval: 3000,
    duration: 500,
    
    // 按钮状态
    showLoginModal: false,
    isLogging: false
  },

  onLoad(options) {
    console.log('index-guest onLoad');
    this.initPage();
  },

  onShow() {
    // 页面显示时，检查是否需要显示登录引导
    this.checkLoginStatus();
  },

  onShareAppMessage() {
    return {
      title: '宠物管家 - 专业的宠物管理工具',
      path: '/pages/index/index',
      imageUrl: '/images/share-default.jpg'
    };
  },

  onShareTimeline() {
    return {
      title: '发现一个好用的宠物管理小程序',
      query: '',
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 初始化页面
   */
  initPage() {
    // 可以在这里初始化一些数据
    console.log('访客首页初始化完成');
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    
    // 如果用户已经登录，自动跳转到已登录首页
    if (app.globalData.isLoggedIn) {
      wx.switchTab({
        url: '/pages/index/index'
      });
    }
  },

  /**
   * 轮播图切换
   */
  onBannerChange(e) {
    this.setData({
      currentBanner: e.detail.current
    });
  },

  /**
   * 点击轮播图
   */
  onBannerTap(e) {
    const { banner } = e.currentTarget.dataset;
    console.log('点击轮播图:', banner);
    
    // 根据banner类型跳转到不同页面
    switch (banner.id) {
      case 1:
        this.navigateToFeatures();
        break;
      case 2:
        this.navigateToHealth();
        break;
      case 3:
        this.navigateToCommunity();
        break;
    }
  },

  /**
   * 点击功能模块
   */
  onFeatureTap(e) {
    const { feature } = e.currentTarget.dataset;
    
    // 需要登录才能使用功能，显示登录提示
    this.showLoginGuide(feature.title);
  },

  /**
   * 显示登录引导
   */
  showLoginGuide(featureName = '此功能') {
    wx.showModal({
      title: '需要登录',
      content: `登录后才能使用${featureName}`,
      confirmText: '立即登录',
      cancelText: '稍后再说',
      success: (res) => {
        if (res.confirm) {
          this.navigateToLogin();
        }
      }
    });
  },

  /**
   * 点击用户案例
   */
  onStoryTap(e) {
    const { story } = e.currentTarget.dataset;
    console.log('点击用户案例:', story);
    
    // 可以跳转到详细故事页面
    // 这里先展示一个弹窗
    wx.showModal({
      title: `${story.user}的分享`,
      content: story.content,
      showCancel: false,
      confirmText: '知道了'
    });
  },

  /**
   * 快速开始按钮
   */
  onQuickStartTap() {
    this.navigateToLogin();
  },

  /**
   * 扫码体验按钮
   */
  onScanTap() {
    // 引导用户扫码体验
    wx.showActionSheet({
      itemList: ['扫码体验功能', '查看示例二维码', '先登录再使用'],
      success: (res) => {
        switch (res.tapIndex) {
          case 0:
            this.startScan();
            break;
          case 1:
            this.showSampleQR();
            break;
          case 2:
            this.navigateToLogin();
            break;
        }
      }
    });
  },

  /**
   * 开始扫码
   */
  startScan() {
    // 跳转到扫码页面
    wx.navigateTo({
      url: '/pages/scan/scan?mode=guest'
    });
  },

  /**
   * 显示示例二维码
   */
  showSampleQR() {
    wx.previewImage({
      urls: ['/images/sample-qr.jpg']
    });
  },

  /**
   * 跳转到登录页
   */
  navigateToLogin() {
    wx.navigateTo({
      url: '/pages/login/login'
    });
  },

  /**
   * 跳转到注册页
   */
  navigateToRegister() {
    wx.navigateTo({
      url: '/pages/register/register'
    });
  },

  /**
   * 跳转到功能介绍
   */
  navigateToFeatures() {
    wx.navigateTo({
      url: '/pages/features/features'
    });
  },

  /**
   * 跳转到健康管理介绍
   */
  navigateToHealth() {
    wx.navigateTo({
      url: '/pages/health-intro/health-intro'
    });
  },

  /**
   * 跳转到社区介绍
   */
  navigateToCommunity() {
    wx.navigateTo({
      url: '/pages/community-intro/community-intro'
    });
  },

  /**
   * 立即注册按钮
   */
  onRegisterTap() {
    this.navigateToRegister();
  },

  /**
   * 已有账号登录按钮
   */
  onLoginTap() {
    this.navigateToLogin();
  },

  /**
   * 微信快速登录
   */
  async onWechatLoginTap() {
    if (this.data.isLogging) return;
    
    this.setData({ isLogging: true });
    
    try {
      const app = getApp();
      const result = await app.wxLogin();
      
      if (result.success) {
        // 登录成功，跳转到首页
        wx.switchTab({
          url: '/pages/index/index'
        });
      } else {
        wx.showToast({
          title: '登录失败',
          icon: 'error'
        });
      }
    } catch (error) {
      console.error('微信登录失败:', error);
      wx.showToast({
        title: '登录失败，请重试',
        icon: 'error'
      });
    } finally {
      this.setData({ isLogging: false });
    }
  },

  /**
   * 查看更多用户案例
   */
  viewMoreStories() {
    wx.navigateTo({
      url: '/pages/user-stories/user-stories'
    });
  },

  /**
   * 播放宣传视频
   */
  playPromoVideo() {
    wx.navigateTo({
      url: '/pages/video/video?type=promo'
    });
  },

  /**
   * 联系客服
   */
  contactCustomerService() {
    wx.showActionSheet({
      itemList: ['在线客服', '电话联系', '微信咨询'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 跳转到客服页面
            wx.navigateTo({
              url: '/pages/customer-service/customer-service'
            });
            break;
          case 1:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 2:
            wx.setClipboardData({
              data: 'petcare_wechat',
              success: () => {
                wx.showToast({
                  title: '客服微信号已复制',
                  icon: 'success'
                });
              }
            });
            break;
        }
      }
    });
  },

  /**
   * 关于我们
   */
  navigateToAbout() {
    wx.navigateTo({
      url: '/pages/about/about'
    });
  }
});