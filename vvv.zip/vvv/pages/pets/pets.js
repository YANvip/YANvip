// pages/pets/pets.js
const app = getApp();
const { formatTime, request, showToast, showLoading, hideLoading } = require('../../utils/util');

Page({
  data: {
    // 用户信息
    userInfo: null,
    
    // 宠物统计
    petStats: {
      total: 0,
      active: 0,
      reminders: 0
    },
    
    // 宠物列表
    petList: [],
    
    // 分页相关
    currentPage: 1,
    pageSize: 10,
    hasMore: true,
    loading: false,
    
    // 添加方式
    showAddMethods: false,
    
    // 二维码弹窗
    showQRModal: false,
    currentQRCode: '',
    
    // 健康状态映射
    healthStatusMap: {
      normal: '健康',
      warning: '注意',
      critical: '需关注'
    }
  },

  onLoad() {
    this.checkLogin();
  },

  onShow() {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo
      });
      this.loadPetList();
      this.loadPetStats();
    }
  },

  onPullDownRefresh() {
    this.refreshPetList();
  },

  onReachBottom() {
    this.loadMorePets();
  },

  // 检查登录状态
  checkLogin() {
    const userInfo = app.globalData.userInfo;
    if (!userInfo) {
      wx.showModal({
        title: '需要登录',
        content: '请先登录以查看宠物列表',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          } else {
            wx.navigateBack();
          }
        }
      });
      return;
    }
    
    this.setData({ userInfo });
  },

  // 加载宠物列表
  async loadPetList() {
    try {
      showLoading('加载中...');
      
      // 优先尝试从服务器获取
      const res = await request({
        url: '/api/pets/my-pets',
        method: 'GET',
        data: {
          page: this.data.currentPage,
          pageSize: this.data.pageSize
        }
      });
      
      if (res.code === 0) {
        const pets = res.data.list || [];
        const total = res.data.total || 0;
        
        this.setData({
          petList: this.data.currentPage === 1 ? pets : [...this.data.petList, ...pets],
          hasMore: this.data.petList.length < total,
          loading: false
        });
        
        // 更新全局数据
        app.globalData.petList = this.data.petList;
        
        // 如果服务器失败，尝试从本地缓存读取
        if (pets.length === 0) {
          this.loadFromLocalStorage();
        }
      }
    } catch (error) {
      console.error('加载宠物列表失败:', error);
      // 失败时从本地缓存读取
      this.loadFromLocalStorage();
    } finally {
      hideLoading();
      wx.stopPullDownRefresh();
    }
  },

  // 从本地缓存加载
  loadFromLocalStorage() {
    try {
      const localPets = wx.getStorageSync('petList') || [];
      this.setData({
        petList: localPets,
        hasMore: false
      });
    } catch (error) {
      console.error('从本地加载宠物列表失败:', error);
    }
  },

  // 加载宠物统计
  async loadPetStats() {
    try {
      const res = await request({
        url: '/api/home/stats',
        method: 'GET'
      });
      
      if (res.code === 0 && res.data) {
        this.setData({
          petStats: res.data.petStats || this.data.petStats
        });
      }
    } catch (error) {
      console.error('加载宠物统计失败:', error);
    }
  },

  // 刷新宠物列表
  refreshPetList() {
    this.setData({
      currentPage: 1,
      petList: [],
      hasMore: true
    });
    this.loadPetList();
  },

  // 加载更多宠物
  loadMorePets() {
    if (!this.data.hasMore || this.data.loading) return;
    
    this.setData({
      currentPage: this.data.currentPage + 1,
      loading: true
    });
    
    this.loadPetList();
  },

  // 计算年龄
  calculateAge(birthDate) {
    if (!birthDate) return '?';
    
    const birth = new Date(birthDate);
    const now = new Date();
    let age = now.getFullYear() - birth.getFullYear();
    
    // 调整月份
    const monthDiff = now.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < birth.getDate())) {
      age--;
    }
    
    return age < 1 ? '<1' : age;
  },

  // 获取健康状态文本
  getHealthStatusText(status) {
    return this.data.healthStatusMap[status] || '未知';
  },

  // 格式化时间
  formatTime(time) {
    return formatTime(time, 'MM-DD hh:mm');
  },

  // 跳转到添加宠物
  goToAddPet() {
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  // 切换添加方式显示
  toggleAddMethods() {
    this.setData({
      showAddMethods: !this.data.showAddMethods
    });
  },

  // 手动添加
  addByManual() {
    wx.navigateTo({
      url: '/pages/addPet/addPet?method=manual'
    });
  },

  // 芯片扫描添加
  addByChip() {
    wx.navigateTo({
      url: '/pages/addPet/addPet?method=chip'
    });
  },

  // NFC感应添加
  addByNFC() {
    wx.navigateTo({
      url: '/pages/addPet/addPet?method=nfc'
    });
  },

  // 跳转到宠物详情
  goToPetDetail(e) {
    const petId = e.currentTarget.dataset.petid;
    wx.navigateTo({
      url: `/pages/pet-detail/pet-detail?id=${petId}`
    });
  },

  // 跳转到编辑宠物
  goToEditPet(e) {
    const petId = e.currentTarget.dataset.petid;
    wx.navigateTo({
      url: `/pages/addPet/addPet?id=${petId}&action=edit`
    });
  },

  // 显示二维码
  showQRCode(e) {
    const qrCode = e.currentTarget.dataset.qrcode;
    
    if (!qrCode) {
      showToast('该宠物暂无二维码');
      return;
    }
    
    this.setData({
      showQRModal: true,
      currentQRCode: qrCode
    });
    
    // 延迟绘制二维码
    setTimeout(() => {
      this.drawQRCode(qrCode);
    }, 100);
  },

  // 隐藏二维码
  hideQRCode() {
    this.setData({
      showQRModal: false
    });
  },

  // 绘制二维码
  drawQRCode(text) {
    const ctx = wx.createCanvasContext('qrcodeCanvas', this);
    
    // 清空画布
    ctx.clearRect(0, 0, 250, 250);
    
    // 绘制二维码（简化版本，实际应使用二维码生成库）
    // 这里绘制一个简单的占位二维码
    ctx.setFillStyle('#000000');
    ctx.fillRect(50, 50, 150, 150);
    ctx.setFillStyle('#ffffff');
    ctx.fillRect(60, 60, 130, 130);
    ctx.setFillStyle('#000000');
    ctx.fillRect(70, 70, 110, 110);
    
    // 中心Logo
    ctx.setFillStyle('#4CAF50');
    ctx.fillRect(105, 105, 40, 40);
    
    ctx.draw();
  },

  // 保存二维码
  saveQRCode() {
    wx.canvasToTempFilePath({
      canvasId: 'qrcodeCanvas',
      success: (res) => {
        wx.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
          success: () => {
            showToast('二维码已保存到相册');
          },
          fail: () => {
            showToast('保存失败，请检查权限设置');
          }
        });
      }
    });
  },

  // 分享二维码
  shareQRCode() {
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
    
    wx.showModal({
      title: '分享提示',
      content: '请点击右上角的分享按钮',
      showCancel: false
    });
  },

  // 切换绝育状态
  async toggleNeutered(e) {
    const { petid, current } = e.currentTarget.dataset;
    const newStatus = !current;
    
    try {
      showLoading('更新中...');
      
      await request({
        url: `/api/pets/${petid}`,
        method: 'PUT',
        data: { neutered: newStatus }
      });
      
      // 更新本地数据
      const updatedList = this.data.petList.map(pet => {
        if (pet.id === petid) {
          return { ...pet, neutered: newStatus };
        }
        return pet;
      });
      
      this.setData({ petList: updatedList });
      app.globalData.petList = updatedList;
      
      // 更新本地存储
      wx.setStorageSync('petList', updatedList);
      
      showToast(newStatus ? '已标记为已绝育' : '已标记为未绝育');
    } catch (error) {
      console.error('更新绝育状态失败:', error);
      showToast('更新失败');
    } finally {
      hideLoading();
    }
  },

  // 添加健康记录
  addHealthRecord(e) {
    const petId = e.currentTarget.dataset.petid;
    wx.navigateTo({
      url: `/pages/health-add/health-add?petId=${petId}`
    });
  },

  // 查看公开信息
  goToPublicView(e) {
    const petId = e.currentTarget.dataset.petid;
    wx.navigateTo({
      url: `/pages/public-pet-info/public-pet-info?petId=${petId}`
    });
  },

  // 阻止事件冒泡
  stopPropagation() {
    return;
  },

  // 用户点击右上角分享
  onShareAppMessage() {
    return {
      title: '我的宠物列表',
      path: '/pages/pets/pets',
      imageUrl: '/images/share-pets.jpg'
    };
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '查看我的可爱宠物们',
      query: 'from=pets'
    };
  }
});