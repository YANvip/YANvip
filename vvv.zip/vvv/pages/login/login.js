// pages/login/login.js - 修复版
// 添加错误处理和兼容性修复

// 添加一个安全的getApp函数
function getSafeApp() {
  try {
    const app = getApp();
    // 确保globalData存在
    if (!app.globalData) {
      app.globalData = {};
    }
    // 确保必要属性存在
    if (app.globalData.isLogged === undefined) {
      app.globalData.isLogged = false;
    }
    if (app.globalData.isGuest === undefined) {
      app.globalData.isGuest = false;
    }
    if (!app.globalData.userInfo && !app.globalData.user_info) {
      app.globalData.userInfo = null;
      app.globalData.user_info = null;
    }
    return app;
  } catch (error) {
    console.error('获取App实例失败:', error);
    // 返回一个安全的默认app对象
    return {
      globalData: {
        userInfo: null,
        user_info: null,
        isLogged: false,
        isGuest: false,
        token: null,
        system_info: null,
        base_url: 'https://api.example.com/api'
      },
      request: function(options) {
        return new Promise((resolve, reject) => {
          // 简单的模拟请求
          setTimeout(() => {
            resolve({ success: true, data: {} });
          }, 1000);
        });
      }
    };
  }
}

Page({
  data: {
    // 登录方式：wechat | phone
    loginMethod: 'wechat',
    
    // 手机登录表单
    phoneForm: {
      phoneNumber: '',
      verifyCode: '',
      areaCode: '86'
    },
    
    // 验证码相关
    verifyCode: {
      countdown: 0,
      sendText: '获取验证码',
      sending: false,
      timer: null
    },
    
    // 登录按钮状态
    loginBtn: {
      loading: false,
      disabled: true,
      text: '登录'
    },
    
    // 协议相关
    agreements: {
      userAgreement: false,
      privacyPolicy: false
    },
    
    // 错误信息
    errors: {
      phone: '',
      verifyCode: ''
    },
    
    // 页面状态
    showWelcome: true,
    // 用户头像和昵称（用于展示）
    userAvatar: '/images/default-avatar.png',
    userName: '',
    
    // 系统信息
    systemInfo: {}
  },

  onLoad(options) {
    console.log('登录页面加载，参数:', options);
    
    // 检查是否有重定向参数
    if (options && options.redirect) {
      try {
        wx.setStorageSync('loginRedirect', decodeURIComponent(options.redirect));
      } catch (error) {
        console.error('保存重定向参数失败:', error);
      }
    }
    
    // 获取系统信息
    this.getSystemInfo();
    
    // 显示欢迎动画
    this.showWelcomeAnimation();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onShow() {
    console.log('登录页面显示');
  },

  onUnload() {
    // 清理定时器
    this.clearTimers();
  },

  /**
   * 获取系统信息
   */
  getSystemInfo() {
    try {
      const systemInfo = wx.getSystemInfoSync();
      this.setData({
        systemInfo: systemInfo
      });
    } catch (error) {
      console.error('获取系统信息失败:', error);
    }
  },

  /**
   * 显示欢迎动画
   */
  showWelcomeAnimation() {
    // 2秒后隐藏欢迎动画
    const timeout = setTimeout(() => {
      this.setData({
        showWelcome: false
      });
    }, 2000);
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getSafeApp();
    const isLogged = app.globalData.isLogged || false;
    console.log('检查登录状态:', isLogged);
    
    if (isLogged) {
      // 已登录，跳转到首页
      this.redirectAfterLogin();
    }
  },

  /**
   * 清理定时器
   */
  clearTimers() {
    const { verifyCode } = this.data;
    
    if (verifyCode.timer) {
      clearInterval(verifyCode.timer);
    }
  },

  /**
   * 切换登录方式
   */
  switchLoginMethod(e) {
    const method = e.currentTarget.dataset.method;
    
    if (this.data.loginMethod === method) return;
    
    this.setData({
      loginMethod: method,
      errors: {
        phone: '',
        verifyCode: ''
      }
    });
    
    // 重置表单验证状态
    this.validateForm();
  },

  /**
   * 手机号输入
   */
  onPhoneInput(e) {
    const value = e.detail.value.replace(/\D/g, ''); // 只保留数字
    const formattedValue = this.formatPhoneNumber(value);
    
    this.setData({
      'phoneForm.phoneNumber': formattedValue,
      'errors.phone': ''
    });
    
    // 验证表单
    this.validateForm();
  },

  /**
   * 格式化手机号
   */
  formatPhoneNumber(phone) {
    if (!phone) return '';
    
    // 限制长度
    phone = phone.substring(0, 11);
    
    // 添加空格格式化：123 4567 8901
    if (phone.length > 7) {
      return `${phone.substring(0, 3)} ${phone.substring(3, 7)} ${phone.substring(7)}`;
    } else if (phone.length > 3) {
      return `${phone.substring(0, 3)} ${phone.substring(3)}`;
    }
    
    return phone;
  },

  /**
   * 验证码输入
   */
  onVerifyCodeInput(e) {
    const value = e.detail.value.replace(/\D/g, ''); // 只保留数字
    
    this.setData({
      'phoneForm.verifyCode': value.substring(0, 6),
      'errors.verifyCode': ''
    });
    
    // 验证表单
    this.validateForm();
  },

  /**
   * 获取验证码
   */
  getVerifyCode() {
    const { phoneForm, verifyCode } = this.data;
    
    // 验证手机号
    if (!this.validatePhoneNumber(phoneForm.phoneNumber)) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none'
      });
      return;
    }
    
    // 防止重复发送
    if (verifyCode.sending || verifyCode.countdown > 0) {
      return;
    }
    
    // 开始发送
    this.setData({
      'verifyCode.sending': true,
      'verifyCode.sendText': '发送中...'
    });
    
    try {
      // 模拟获取验证码
      setTimeout(() => {
        this.setData({
          'verifyCode.sending': false
        });
        
        // 开始倒计时
        this.startCountdown();
        
        wx.showToast({
          title: '验证码已发送：123456',
          icon: 'success'
        });
      }, 1500);
      
    } catch (error) {
      console.error('获取验证码失败:', error);
      wx.showToast({
        title: '网络错误，请重试',
        icon: 'none'
      });
      this.setData({
        'verifyCode.sending': false
      });
    }
  },

  /**
   * 开始倒计时
   */
  startCountdown() {
    let countdown = 60;
    
    const timer = setInterval(() => {
      countdown--;
      
      if (countdown <= 0) {
        clearInterval(timer);
        this.setData({
          'verifyCode.countdown': 0,
          'verifyCode.sendText': '重新发送',
          'verifyCode.timer': null
        });
      } else {
        this.setData({
          'verifyCode.countdown': countdown,
          'verifyCode.sendText': `${countdown}s后重新发送`
        });
      }
    }, 1000);
    
    this.setData({
      'verifyCode.countdown': countdown,
      'verifyCode.sendText': `${countdown}s后重新发送`,
      'verifyCode.timer': timer
    });
  },

  /**
   * 验证手机号
   */
  validatePhoneNumber(phone) {
    const cleanPhone = phone.replace(/\s/g, '');
    return /^1[3-9]\d{9}$/.test(cleanPhone);
  },

  /**
   * 验证表单
   */
  validateForm() {
    const { loginMethod, phoneForm, agreements } = this.data;
    
    let isValid = false;
    
    if (loginMethod === 'wechat') {
      // 微信登录只需要同意协议
      isValid = agreements.userAgreement && agreements.privacyPolicy;
    } else {
      // 手机登录需要验证手机号和验证码
      const isPhoneValid = this.validatePhoneNumber(phoneForm.phoneNumber);
      const isCodeValid = phoneForm.verifyCode.length === 6;
      const isAgreed = agreements.userAgreement && agreements.privacyPolicy;
      
      isValid = isPhoneValid && isCodeValid && isAgreed;
    }
    
    this.setData({
      'loginBtn.disabled': !isValid
    });
  },

  /**
   * 切换协议勾选状态
   */
  toggleAgreement(e) {
    const { type } = e.currentTarget.dataset;
    
    this.setData({
      [`agreements.${type}`]: !this.data.agreements[type]
    }, () => {
      this.validateForm();
    });
  },

  /**
   * 跳转到协议页面
   */
  navigateToAgreement(e) {
    const { type } = e.currentTarget.dataset;
    
    const urls = {
      userAgreement: '/pages/agreement/user-agreement',
      privacyPolicy: '/pages/agreement/privacy-policy'
    };
    
    wx.navigateTo({
      url: urls[type] || '/pages/agreement/user-agreement'
    });
  },

  /**
   * 登录
   */
  login() {
    const { loginMethod, phoneForm, loginBtn } = this.data;
    
    if (loginBtn.loading || loginBtn.disabled) return;
    
    // 设置加载状态
    this.setData({
      'loginBtn.loading': true,
      'loginBtn.text': '登录中...'
    });
    
    try {
      if (loginMethod === 'wechat') {
        this.wechatLogin();
      } else {
        this.phoneLogin();
      }
    } catch (error) {
      console.error('登录失败:', error);
      wx.showToast({
        title: '登录失败，请重试',
        icon: 'error'
      });
      this.setData({
        'loginBtn.loading': false,
        'loginBtn.text': '登录'
      });
    }
  },

  /**
   * 微信登录
   */
  wechatLogin() {
    const app = getSafeApp();
    
    // 检查微信登录能力
    if (!wx.getUserProfile) {
      wx.showToast({
        title: '当前微信版本过低，请升级',
        icon: 'none'
      });
      this.setData({
        'loginBtn.loading': false,
        'loginBtn.text': '登录'
      });
      return;
    }
    
    // 使用微信的getUserProfile API获取用户信息
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途
      success: (res) => {
        console.log('用户信息获取成功:', res.userInfo);
        
        // 模拟登录成功
        setTimeout(() => {
          this.loginSuccess({
            token: 'wechat_token_' + Date.now(),
            userInfo: {
              id: 'WX_' + Date.now(),
              nickname: res.userInfo.nickName,
              avatar: res.userInfo.avatarUrl,
              gender: res.userInfo.gender,
              province: res.userInfo.province,
              city: res.userInfo.city,
              country: res.userInfo.country
            }
          });
        }, 1000);
      },
      fail: (err) => {
        console.error('用户信息获取失败:', err);
        wx.showToast({
          title: '获取用户信息失败',
          icon: 'error'
        });
        this.setData({
          'loginBtn.loading': false,
          'loginBtn.text': '登录'
        });
      }
    });
  },

  /**
   * 手机号登录
   */
  phoneLogin() {
    const { phoneForm } = this.data;
    
    // 验证表单
    if (!this.validatePhoneNumber(phoneForm.phoneNumber)) {
      this.setData({
        'errors.phone': '请输入正确的手机号',
        'loginBtn.loading': false,
        'loginBtn.text': '登录'
      });
      return;
    }
    
    if (phoneForm.verifyCode.length !== 6) {
      this.setData({
        'errors.verifyCode': '请输入6位验证码',
        'loginBtn.loading': false,
        'loginBtn.text': '登录'
      });
      return;
    }
    
    try {
      // 模拟登录请求
      setTimeout(() => {
        const phoneNumber = phoneForm.phoneNumber.replace(/\s/g, '');
        this.loginSuccess({
          token: 'mock_token_' + Date.now(),
          userInfo: {
            id: 'USER_' + phoneNumber.slice(-6),
            nickname: '用户' + phoneNumber.slice(-4),
            phone: phoneNumber,
            avatar: '/images/default-avatar.png'
          }
        });
      }, 1500);
      
    } catch (error) {
      console.error('手机登录失败:', error);
      wx.showToast({
        title: '网络错误，请重试',
        icon: 'error'
      });
      this.setData({
        'loginBtn.loading': false,
        'loginBtn.text': '登录'
      });
    }
  },

  /**
   * 登录成功处理
   */
  loginSuccess(data) {
    const app = getSafeApp();
    
    // 保存用户信息
    app.globalData.userInfo = data.userInfo;
    app.globalData.user_info = data.userInfo; // 兼容两种命名
    app.globalData.isLogged = true;
    app.globalData.token = data.token;
    
    // 保存到缓存
    try {
      wx.setStorageSync('userInfo', data.userInfo);
      wx.setStorageSync('user_info', data.userInfo); // 兼容两种命名
      wx.setStorageSync('token', data.token);
    } catch (error) {
      console.error('保存用户信息失败:', error);
    }
    
    // 显示成功提示
    wx.showToast({
      title: '登录成功',
      icon: 'success',
      duration: 1500
    });
    
    // 跳转到目标页面
    setTimeout(() => {
      this.redirectAfterLogin();
    }, 1500);
  },

  /**
   * 登录后重定向
   */
  redirectAfterLogin() {
    // 获取重定向地址
    let redirect = '';
    try {
      redirect = wx.getStorageSync('loginRedirect') || '';
      if (redirect) {
        wx.removeStorageSync('loginRedirect');
      }
    } catch (error) {
      console.error('获取重定向地址失败:', error);
    }
    
    if (redirect) {
      // 跳转到指定页面
      wx.redirectTo({
        url: redirect
      });
    } else {
      // 跳转到首页
      try {
        wx.switchTab({
          url: '/pages/index/index'
        });
      } catch (error) {
        console.error('跳转到首页失败:', error);
        // 如果首页不存在，跳转到测试页面
        wx.redirectTo({
          url: '/pages/test/test'
        });
      }
    }
  },

  /**
   * 隐私协议弹窗
   */
  showPrivacyAgreement() {
    wx.showModal({
      title: '用户协议与隐私政策',
      content: '请阅读并同意《用户协议》和《隐私政策》',
      confirmText: '去阅读',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/agreement/user-agreement'
          });
        }
      }
    });
  },

  /**
   * 游客模式
   */
  guestMode() {
    wx.showModal({
      title: '游客模式',
      content: '游客模式下部分功能受限，建议登录后使用完整功能',
      confirmText: '继续',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          const app = getSafeApp();
          
          // 设置游客标识
          app.globalData.isGuest = true;
          
          // 跳转到首页
          try {
            wx.switchTab({
              url: '/pages/index/index'
            });
          } catch (error) {
            // 如果首页不存在，跳转到测试页面
            wx.redirectTo({
              url: '/pages/test/test'
            });
          }
        }
      }
    });
  },

  /**
   * 一键清空手机号
   */
  clearPhoneNumber() {
    this.setData({
      'phoneForm.phoneNumber': '',
      'errors.phone': ''
    }, () => {
      this.validateForm();
    });
  },

  /**
   * 一键清空验证码
   */
  clearVerifyCode() {
    this.setData({
      'phoneForm.verifyCode': '',
      'errors.verifyCode': ''
    }, () => {
      this.validateForm();
    });
  },

  /**
   * 快速回到首页
   */
  goBackToHome() {
    try {
      wx.switchTab({
        url: '/pages/index/index'
      });
    } catch (error) {
      // 如果首页不存在，跳转到测试页面
      wx.redirectTo({
        url: '/pages/test/test'
      });
    }
  }
});