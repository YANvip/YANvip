// pages/health-edit/health-edit.js
Page({
  data: {
    // 记录ID
    recordId: '',
    
    // 记录类型
    recordType: 'general',
    
    // 表单数据
    formData: {
      // 基础信息
      title: '',
      petId: '',
      date: '',
      type: 'general',
      
      // 详细信息
      description: '',
      hospital: '',
      doctor: '',
      cost: '',
      notes: '',
      
      // 下次提醒
      hasNextDate: false,
      nextDate: '',
      reminderDays: 7,
      reminderNotes: '',
      
      // 状态
      completed: false,
      important: false,
      isDraft: false
    },
    
    // 宠物列表
    pets: [],
    
    // 记录类型选项
    recordTypes: [
      {
        id: 'vaccination',
        name: '疫苗接种',
        icon: '💉',
        color: '#4CAF50',
        fields: ['vaccineName', 'batchNumber', 'manufacturer']
      },
      {
        id: 'deworming',
        name: '驱虫记录',
        icon: '🦠',
        color: '#FF9800',
        fields: ['dewormerType', 'brand', 'dosage']
      },
      {
        id: 'medical',
        name: '医疗记录',
        icon: '🏥',
        color: '#2196F3',
        fields: ['diagnosis', 'symptoms', 'treatment']
      },
      {
        id: 'examination',
        name: '体检记录',
        icon: '📋',
        color: '#009688',
        fields: ['weight', 'temperature', 'heartRate']
      },
      {
        id: 'surgery',
        name: '手术记录',
        icon: '🔪',
        color: '#9C27B0',
        fields: ['surgeryType', 'anesthesia', 'recovery']
      },
      {
        id: 'daily',
        name: '日常护理',
        icon: '✨',
        color: '#FFC107',
        fields: ['careType', 'frequency', 'notes']
      },
      {
        id: 'general',
        name: '一般记录',
        icon: '📝',
        color: '#795548',
        fields: []
      }
    ],
    
    // 当前类型对应的额外字段
    extraFields: [],
    
    // 图片相关
    images: [],
    originalImages: [],
    maxImages: 9,
    uploading: false,
    
    // 表单验证错误
    errors: {},
    
    // 页面状态
    loading: true,
    submitting: false,
    showDatePicker: false,
    showNextDatePicker: false,
    activeSection: 'basic', // basic | details | reminder | images
    
    // 日期选择器配置
    datePicker: {
      current: '',
      start: '2010-01-01',
      end: '2030-12-31'
    },
    
    // 疫苗类型选项
    vaccineOptions: [
      '狂犬疫苗',
      '犬瘟热疫苗',
      '犬细小病毒疫苗',
      '犬冠状病毒疫苗',
      '猫三联疫苗',
      '猫五联疫苗',
      '其他疫苗'
    ],
    
    // 驱虫药类型选项
    dewormerOptions: [
      '体内驱虫',
      '体外驱虫',
      '内外同驱',
      '其他'
    ],
    
    // 是否为新图片（用于判断是否需要保存）
    hasNewImages: false,
    
    // 记录原始数据（用于比较是否有修改）
    originalData: null
  },

  onLoad(options) {
    console.log('health-edit onLoad', options);
    
    // 获取传递的参数
    const { id } = options || {};
    
    if (!id) {
      wx.showToast({
        title: '记录ID不能为空',
        icon: 'error'
      });
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
      return;
    }
    
    this.setData({ recordId: id });
    
    // 初始化页面
    this.initPage();
  },

  onShow() {
    // 页面显示时，加载宠物列表
    this.loadPets();
  },

  /**
   * 初始化页面
   */
  initPage() {
    // 加载记录数据
    this.loadRecordData();
  },

  /**
   * 加载记录数据
   */
  loadRecordData() {
    this.setData({ loading: true });
    
    try {
      // 获取健康记录
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const record = healthRecords.find(r => r.id === this.data.recordId);
      
      if (!record) {
        wx.showToast({
          title: '记录不存在',
          icon: 'error'
        });
        setTimeout(() => {
          wx.navigateBack();
        }, 1500);
        return;
      }
      
      // 保存原始数据
      this.setData({ originalData: JSON.parse(JSON.stringify(record)) });
      
      // 格式化数据
      this.prepareFormData(record);
      
      // 设置记录类型
      const selectedType = this.data.recordTypes.find(t => t.id === record.type) || this.data.recordTypes[6];
      
      // 加载类型的额外字段
      this.loadExtraFields(record.type);
      
      // 设置图片
      if (record.images && record.images.length > 0) {
        const imageObjects = record.images.map(url => ({
          url: url,
          name: url.split('/').pop(),
          status: 'success'
        }));
        
        this.setData({
          images: imageObjects,
          originalImages: [...imageObjects]
        });
      }
      
      // 更新导航栏标题
      wx.setNavigationBarTitle({
        title: `编辑${selectedType.name}`
      });
      
      this.setData({
        loading: false,
        recordType: record.type
      });
      
    } catch (error) {
      console.error('加载记录数据失败:', error);
      this.setData({ loading: false });
      
      wx.showToast({
        title: '加载记录失败',
        icon: 'error'
      });
      
      setTimeout(() => {
        wx.navigateBack();
      }, 1500);
    }
  },

  /**
   * 准备表单数据
   */
  prepareFormData(record) {
    const formData = {
      title: record.title || '',
      petId: record.petId || '',
      date: record.date || this.formatDate(new Date()),
      type: record.type || 'general',
      
      description: record.description || '',
      hospital: record.hospital || '',
      doctor: record.doctor || '',
      cost: record.cost ? record.cost.toString() : '',
      notes: record.notes || '',
      
      hasNextDate: record.hasNextDate || false,
      nextDate: record.nextDate || this.formatDate(new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)),
      reminderDays: record.reminderDays || 7,
      reminderNotes: record.reminderNotes || '',
      
      completed: record.completed || false,
      important: record.important || false,
      isDraft: record.isDraft || false
    };
    
    this.setData({
      formData: formData,
      'datePicker.current': formData.date
    });
    
    // 设置额外字段的值
    if (record.extraData) {
      setTimeout(() => {
        this.setExtraFieldsData(record.extraData);
      }, 100);
    }
  },

  /**
   * 设置额外字段数据
   */
  setExtraFieldsData(extraData) {
    const extraFields = [...this.data.extraFields];
    
    Object.keys(extraData).forEach(key => {
      const fieldIndex = extraFields.findIndex(f => f.name === key);
      if (fieldIndex !== -1) {
        extraFields[fieldIndex].value = extraData[key];
      }
    });
    
    this.setData({ extraFields });
  },

  /**
   * 加载宠物列表
   */
  loadPets() {
    try {
      const pets = wx.getStorageSync('pets') || [];
      
      if (pets.length === 0) {
        wx.showToast({
          title: '没有宠物数据',
          icon: 'none'
        });
        return;
      }
      
      this.setData({
        pets: pets.map(pet => ({
          id: pet.id,
          name: pet.name,
          breed: pet.breed,
          avatar: pet.avatar || '/images/default-pet-avatar.png'
        }))
      });
      
    } catch (error) {
      console.error('加载宠物列表失败:', error);
    }
  },

  /**
   * 加载额外字段
   */
  loadExtraFields(type) {
    const typeConfig = this.data.recordTypes.find(t => t.id === type);
    if (!typeConfig) return;
    
    const extraFields = typeConfig.fields.map(field => {
      const fieldConfig = {
        name: field,
        value: '',
        label: this.getFieldLabel(field),
        placeholder: this.getFieldPlaceholder(field),
        type: this.getFieldType(field),
        required: false
      };
      
      // 如果是选择类型的字段，添加选项
      if (field === 'vaccineName') {
        fieldConfig.options = this.data.vaccineOptions;
      } else if (field === 'dewormerType') {
        fieldConfig.options = this.data.dewormerOptions;
      }
      
      return fieldConfig;
    });
    
    this.setData({ extraFields });
  },

  /**
   * 获取字段标签
   */
  getFieldLabel(field) {
    const labels = {
      vaccineName: '疫苗名称',
      batchNumber: '批号',
      manufacturer: '生产厂家',
      dewormerType: '驱虫类型',
      brand: '品牌',
      dosage: '剂量',
      diagnosis: '诊断结果',
      symptoms: '症状描述',
      treatment: '治疗方案',
      weight: '体重(kg)',
      temperature: '体温(°C)',
      heartRate: '心率(次/分)',
      surgeryType: '手术类型',
      anesthesia: '麻醉方式',
      recovery: '恢复情况',
      careType: '护理类型',
      frequency: '频率'
    };
    
    return labels[field] || field;
  },

  /**
   * 获取字段占位符
   */
  getFieldPlaceholder(field) {
    const placeholders = {
      vaccineName: '请选择疫苗名称',
      batchNumber: '请输入疫苗批号',
      manufacturer: '请输入生产厂家',
      dewormerType: '请选择驱虫类型',
      brand: '请输入品牌',
      dosage: '例如：1片/次',
      diagnosis: '请输入诊断结果',
      symptoms: '请输入症状描述',
      treatment: '请输入治疗方案',
      weight: '请输入体重',
      temperature: '请输入体温',
      heartRate: '请输入心率',
      surgeryType: '请输入手术类型',
      anesthesia: '请输入麻醉方式',
      recovery: '请输入恢复情况',
      careType: '请输入护理类型',
      frequency: '例如：每天1次'
    };
    
    return placeholders[field] || '请输入内容';
  },

  /**
   * 获取字段类型
   */
  getFieldType(field) {
    const numberFields = ['cost', 'weight', 'temperature', 'heartRate', 'dosage'];
    const selectFields = ['vaccineName', 'dewormerType'];
    
    if (numberFields.includes(field)) {
      return 'number';
    } else if (selectFields.includes(field)) {
      return 'select';
    } else {
      return 'text';
    }
  },

  /**
   * 格式化日期
   */
  formatDate(date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
  },

  /**
   * 选择记录类型
   */
  selectRecordType(e) {
    const { type } = e.currentTarget.dataset;
    
    if (type === this.data.recordType) return;
    
    const selectedType = this.data.recordTypes.find(t => t.id === type);
    if (!selectedType) return;
    
    // 确认切换类型
    wx.showModal({
      title: '切换记录类型',
      content: `确定要将记录类型从${this.getTypeName(this.data.recordType)}切换为${selectedType.name}吗？切换后可能需要重新填写部分信息。`,
      success: (res) => {
        if (res.confirm) {
          // 更新标题
          let newTitle = this.data.formData.title;
          if (newTitle.includes('记录')) {
            newTitle = newTitle.replace(/[\u4e00-\u9fa5]+记录/, selectedType.name);
          } else {
            newTitle = `${selectedType.name}记录`;
          }
          
          this.setData({
            recordType: type,
            'formData.type': type,
            'formData.title': newTitle,
            extraFields: []
          }, () => {
            // 加载新的额外字段
            this.loadExtraFields(type);
            
            // 更新导航栏标题
            wx.setNavigationBarTitle({
              title: `编辑${selectedType.name}`
            });
          });
        }
      }
    });
  },

  /**
   * 获取类型名称
   */
  getTypeName(typeId) {
    const type = this.data.recordTypes.find(t => t.id === typeId);
    return type ? type.name : '未知类型';
  },

  /**
   * 输入表单字段
   */
  onInput(e) {
    const { field } = e.currentTarget.dataset;
    let value = e.detail.value;
    
    // 如果是通过data-value传递的值
    if (e.currentTarget.dataset.value !== undefined) {
      value = e.currentTarget.dataset.value;
    }
    
    // 清除该字段的错误
    const newErrors = { ...this.data.errors };
    delete newErrors[field];
    
    this.setData({
      [`formData.${field}`]: value,
      errors: newErrors
    });
  },

  /**
   * 输入额外字段
   */
  onExtraInput(e) {
    const { index, field } = e.currentTarget.dataset;
    const value = e.detail.value;
    
    const extraFields = [...this.data.extraFields];
    extraFields[index].value = value;
    
    this.setData({
      extraFields: extraFields
    });
  },

  /**
   * 选择宠物
   */
  selectPet(e) {
    const { petId } = e.currentTarget.dataset;
    
    this.setData({
      'formData.petId': petId
    });
  },

  /**
   * 切换是否设置下次提醒
   */
  toggleNextDate() {
    this.setData({
      'formData.hasNextDate': !this.data.formData.hasNextDate
    });
  },

  /**
   * 切换重要标记
   */
  toggleImportant() {
    this.setData({
      'formData.important': !this.data.formData.important
    });
  },

  /**
   * 切换完成状态
   */
  toggleCompleted() {
    this.setData({
      'formData.completed': !this.data.formData.completed
    });
  },

  /**
   * 选择日期
   */
  selectDate() {
    this.setData({
      showDatePicker: true
    });
  },

  /**
   * 选择下次提醒日期
   */
  selectNextDate() {
    this.setData({
      showNextDatePicker: true
    });
  },

  /**
   * 日期选择器变化
   */
  onDateChange(e) {
    const value = e.detail.value;
    
    if (this.data.showDatePicker) {
      this.setData({
        'formData.date': value,
        showDatePicker: false
      });
    } else if (this.data.showNextDatePicker) {
      this.setData({
        'formData.nextDate': value,
        showNextDatePicker: false
      });
    }
  },

  /**
   * 取消日期选择
   */
  cancelDatePicker() {
    this.setData({
      showDatePicker: false,
      showNextDatePicker: false
    });
  },

  /**
   * 选择图片
   */
  chooseImages() {
    const { images, maxImages } = this.data;
    const count = maxImages - images.length;
    
    if (count <= 0) {
      wx.showToast({
        title: `最多只能上传${maxImages}张图片`,
        icon: 'none'
      });
      return;
    }
    
    wx.chooseImage({
      count: count,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const tempFilePaths = res.tempFilePaths;
        this.uploadImages(tempFilePaths);
      }
    });
  },

  /**
   * 上传图片
   */
  uploadImages(filePaths) {
    if (this.data.uploading) return;
    
    this.setData({ uploading: true, hasNewImages: true });
    
    const uploadPromises = filePaths.map(filePath => {
      return new Promise((resolve) => {
        // 模拟上传过程
        setTimeout(() => {
          const fileName = `health_${Date.now()}_${Math.random().toString(36).substr(2)}.jpg`;
          resolve({
            url: filePath, // 实际开发中应替换为上传后的URL
            name: fileName,
            status: 'success',
            isNew: true // 标记为新图片
          });
        }, 500);
      });
    });
    
    Promise.all(uploadPromises)
      .then(results => {
        const newImages = [...this.data.images, ...results];
        this.setData({
          images: newImages,
          uploading: false
        });
        
        wx.showToast({
          title: '图片上传成功',
          icon: 'success'
        });
      })
      .catch(error => {
        console.error('图片上传失败:', error);
        this.setData({ uploading: false });
        
        wx.showToast({
          title: '部分图片上传失败',
          icon: 'error'
        });
      });
  },

  /**
   * 预览图片
   */
  previewImage(e) {
    const { index } = e.currentTarget.dataset;
    const urls = this.data.images.map(img => img.url);
    
    wx.previewImage({
      current: urls[index],
      urls: urls
    });
  },

  /**
   * 删除图片
   */
  deleteImage(e) {
    const { index } = e.currentTarget.dataset;
    
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这张图片吗？',
      success: (res) => {
        if (res.confirm) {
          const images = [...this.data.images];
          const deletedImage = images[index];
          
          // 如果删除的是新上传的图片，更新hasNewImages状态
          if (deletedImage.isNew) {
            const remainingNewImages = images.filter((img, i) => i !== index && img.isNew);
            this.setData({
              hasNewImages: remainingNewImages.length > 0
            });
          }
          
          images.splice(index, 1);
          this.setData({ images });
        }
      }
    });
  },

  /**
   * 切换页面部分
   */
  switchSection(e) {
    const { section } = e.currentTarget.dataset;
    
    if (section === this.data.activeSection) return;
    
    // 验证当前部分
    if (!this.validateCurrentSection()) {
      return;
    }
    
    this.setData({
      activeSection: section
    });
  },

  /**
   * 验证当前部分
   */
  validateCurrentSection() {
    const { activeSection, formData } = this.data;
    const errors = {};
    
    switch (activeSection) {
      case 'basic':
        if (!formData.title.trim()) {
          errors.title = '请填写记录标题';
        }
        if (!formData.petId) {
          errors.petId = '请选择宠物';
        }
        if (!formData.date) {
          errors.date = '请选择记录日期';
        }
        break;
        
      case 'details':
        // 详细信息的验证相对宽松
        break;
    }
    
    if (Object.keys(errors).length > 0) {
      this.setData({ errors });
      
      // 显示第一个错误
      const firstError = Object.values(errors)[0];
      wx.showToast({
        title: firstError,
        icon: 'none'
      });
      
      return false;
    }
    
    return true;
  },

  /**
   * 保存为草稿
   */
  saveAsDraft() {
    if (!this.validateForm()) return;
    
    this.submitForm(true);
  },

  /**
   * 提交表单（更新记录）
   */
  submitForm(isDraft = false) {
    if (!this.validateForm()) return;
    
    if (this.data.submitting) return;
    
    this.setData({ submitting: true });
    
    // 检查是否有修改
    if (!this.hasChanges()) {
      wx.showToast({
        title: '没有修改内容',
        icon: 'none'
      });
      this.setData({ submitting: false });
      return;
    }
    
    // 收集所有数据
    const recordData = this.collectFormData(isDraft);
    
    // 模拟提交过程
    setTimeout(() => {
      this.updateRecord(recordData, isDraft);
    }, 1000);
  },

  /**
   * 检查是否有修改
   */
  hasChanges() {
    const { formData, originalData, images, originalImages, extraFields } = this.data;
    
    // 检查基本表单数据
    if (originalData) {
      const fieldsToCompare = ['title', 'petId', 'date', 'type', 'description', 'hospital', 
                               'doctor', 'cost', 'notes', 'hasNextDate', 'nextDate', 
                               'reminderDays', 'reminderNotes', 'completed', 'important', 'isDraft'];
      
      for (let field of fieldsToCompare) {
        const originalValue = originalData[field];
        const currentValue = formData[field];
        
        if (field === 'cost') {
          if (parseFloat(originalValue || 0) !== parseFloat(currentValue || 0)) {
            return true;
          }
        } else if (originalValue != currentValue) {
          return true;
        }
      }
    }
    
    // 检查图片是否有变化
    if (images.length !== originalImages.length) {
      return true;
    }
    
    // 检查额外字段
    if (extraFields.length > 0) {
      const originalExtraData = originalData?.extraData || {};
      for (let field of extraFields) {
        if (field.value !== originalExtraData[field.name]) {
          return true;
        }
      }
    }
    
    // 如果有新图片
    if (this.data.hasNewImages) {
      return true;
    }
    
    return false;
  },

  /**
   * 验证整个表单
   */
  validateForm() {
    const { formData } = this.data;
    const errors = {};
    
    // 基础验证
    if (!formData.title.trim()) {
      errors.title = '请填写记录标题';
    }
    if (!formData.petId) {
      errors.petId = '请选择宠物';
    }
    if (!formData.date) {
      errors.date = '请选择记录日期';
    }
    
    // 如果设置了下次提醒，验证下次提醒日期
    if (formData.hasNextDate && !formData.nextDate) {
      errors.nextDate = '请选择下次提醒日期';
    }
    
    // 检查是否有错误
    if (Object.keys(errors).length > 0) {
      this.setData({ errors });
      
      // 显示第一个错误
      const firstError = Object.values(errors)[0];
      wx.showToast({
        title: firstError,
        icon: 'none'
      });
      
      // 跳转到有错误的部分
      if (errors.title || errors.petId || errors.date) {
        this.setData({ activeSection: 'basic' });
      } else if (errors.nextDate) {
        this.setData({ activeSection: 'reminder' });
      }
      
      return false;
    }
    
    return true;
  },

  /**
   * 收集表单数据
   */
  collectFormData(isDraft) {
    const { formData, extraFields, images, recordType, pets, originalData } = this.data;
    
    // 获取宠物信息
    const selectedPet = pets.find(pet => pet.id === formData.petId);
    
    // 构建额外字段数据
    const extraData = {};
    extraFields.forEach(field => {
      extraData[field.name] = field.value;
    });
    
    // 构建完整记录
    const record = {
      ...originalData, // 保留原始数据中的其他字段
      id: this.data.recordId,
      petId: formData.petId,
      petName: selectedPet ? selectedPet.name : (originalData?.petName || ''),
      type: formData.type,
      title: formData.title,
      date: formData.date,
      description: formData.description,
      hospital: formData.hospital,
      doctor: formData.doctor,
      cost: formData.cost ? parseFloat(formData.cost) : 0,
      notes: formData.notes,
      hasNextDate: formData.hasNextDate,
      nextDate: formData.hasNextDate ? formData.nextDate : null,
      reminderDays: formData.reminderDays || 7,
      reminderNotes: formData.reminderNotes,
      completed: formData.completed,
      important: formData.important,
      isDraft: isDraft,
      images: images.map(img => img.url),
      extraData: extraData,
      updatedAt: new Date().toISOString()
    };
    
    return record;
  },

  /**
   * 更新记录
   */
  async updateRecord(record, isDraft) {
    try {
      // 获取现有记录
      let healthRecords = wx.getStorageSync('healthRecords') || [];
      
      // 找到记录索引并更新
      const recordIndex = healthRecords.findIndex(r => r.id === this.data.recordId);
      
      if (recordIndex === -1) {
        throw new Error('记录不存在');
      }
      
      healthRecords[recordIndex] = record;
      
      // 保存到缓存
      wx.setStorageSync('healthRecords', healthRecords);
      
      // 更新提醒
      this.updateReminder(record);
      
      // 显示成功提示
      wx.showToast({
        title: isDraft ? '保存草稿成功' : '更新记录成功',
        icon: 'success',
        duration: 2000
      });
      
      // 延迟返回
      setTimeout(() => {
        this.setData({ submitting: false });
        
        // 返回上一页
        wx.navigateBack();
        
        // 发送事件通知列表页刷新
        if (getCurrentPages().length > 1) {
          const prevPage = getCurrentPages()[getCurrentPages().length - 2];
          if (prevPage.route === 'pages/health/health' || prevPage.route === 'pages/health-detail/health-detail') {
            prevPage.onShow && prevPage.onShow();
          }
        }
      }, 1500);
      
    } catch (error) {
      console.error('更新记录失败:', error);
      this.setData({ submitting: false });
      
      wx.showToast({
        title: '更新失败',
        icon: 'error'
      });
    }
  },

  /**
   * 更新提醒
   */
  updateReminder(record) {
    try {
      let reminders = wx.getStorageSync('reminders') || [];
      
      // 查找现有提醒
      const reminderIndex = reminders.findIndex(r => r.recordId === record.id);
      
      if (record.hasNextDate && record.nextDate) {
        const reminder = {
          id: `reminder_${record.id}`,
          recordId: record.id,
          type: 'health',
          subType: record.type,
          title: `${record.petName} - ${record.title}`,
          petId: record.petId,
          petName: record.petName,
          dueDate: record.nextDate,
          notes: record.reminderNotes,
          completed: record.completed,
          updatedAt: new Date().toISOString()
        };
        
        if (reminderIndex !== -1) {
          // 更新现有提醒
          reminders[reminderIndex] = { ...reminders[reminderIndex], ...reminder };
        } else {
          // 添加新提醒
          reminder.createdAt = new Date().toISOString();
          reminders.push(reminder);
        }
      } else if (reminderIndex !== -1) {
        // 删除提醒
        reminders.splice(reminderIndex, 1);
      }
      
      wx.setStorageSync('reminders', reminders);
      
    } catch (error) {
      console.error('更新提醒失败:', error);
    }
  },

  /**
   * 删除记录
   */
  deleteRecord() {
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这条健康记录吗？删除后无法恢复。',
      confirmColor: '#f44336',
      success: (res) => {
        if (res.confirm) {
          this.performDeleteRecord();
        }
      }
    });
  },

  /**
   * 执行删除记录
   */
  async performDeleteRecord() {
    try {
      // 获取现有记录
      let healthRecords = wx.getStorageSync('healthRecords') || [];
      
      // 过滤掉要删除的记录
      const updatedRecords = healthRecords.filter(record => record.id !== this.data.recordId);
      
      // 保存到缓存
      wx.setStorageSync('healthRecords', updatedRecords);
      
      // 删除相关提醒
      this.deleteReminder();
      
      // 显示成功提示
      wx.showToast({
        title: '删除成功',
        icon: 'success',
        duration: 2000
      });
      
      // 延迟返回
      setTimeout(() => {
        // 返回上一页
        wx.navigateBack();
        
        // 发送事件通知列表页刷新
        if (getCurrentPages().length > 1) {
          const prevPage = getCurrentPages()[getCurrentPages().length - 2];
          if (prevPage.route === 'pages/health/health') {
            prevPage.onShow && prevPage.onShow();
          }
        }
      }, 1500);
      
    } catch (error) {
      console.error('删除记录失败:', error);
      wx.showToast({
        title: '删除失败',
        icon: 'error'
      });
    }
  },

  /**
   * 删除提醒
   */
  deleteReminder() {
    try {
      let reminders = wx.getStorageSync('reminders') || [];
      const updatedReminders = reminders.filter(r => r.recordId !== this.data.recordId);
      wx.setStorageSync('reminders', updatedReminders);
    } catch (error) {
      console.error('删除提醒失败:', error);
    }
  },

  /**
   * 重置表单到原始状态
   */
  resetForm() {
    wx.showModal({
      title: '重置修改',
      content: '确定要放弃所有修改，恢复到原始状态吗？',
      confirmColor: '#f44336',
      success: (res) => {
        if (res.confirm) {
          // 重新加载原始数据
          this.loadRecordData();
          wx.showToast({
            title: '已重置',
            icon: 'success'
          });
        }
      }
    });
  },

  /**
   * 返回上一页
   */
  goBack() {
    // 检查是否有未保存的修改
    if (this.hasChanges()) {
      wx.showModal({
        title: '有未保存的修改',
        content: '您有未保存的修改，确定要离开吗？',
        confirmText: '离开',
        cancelText: '取消',
        success: (res) => {
          if (res.confirm) {
            wx.navigateBack();
          }
        }
      });
    } else {
      wx.navigateBack();
    }
  },

  /**
   * 键盘完成按钮事件
   */
  onConfirm() {
    // 如果是最后一个输入框，尝试提交
    if (this.data.activeSection === 'images') {
      this.submitForm();
    }
  }
});