// pages/pet-detail/pet-detail.js
const app = getApp()

Page({
  data: {
    // 宠物数据
    petId: null,
    petInfo: null,
    isLoading: true,
    isRefreshing: false,
    isOwner: false,
    
    // 标签页配置
    activeTab: 'info',
    tabs: [
      { key: 'info', name: '信息', icon: '📋' },
      { key: 'health', name: '健康', icon: '🏥' },
      { key: 'records', name: '记录', icon: '📝' },
      { key: 'qr', name: '二维码', icon: '🔗' }
    ],
    
    // 健康数据
    healthRecords: [],
    healthStats: {
      totalRecords: 0,
      lastVetVisit: '',
      nextVaccination: '',
      currentHealthStatus: 'healthy'
    },
    
    // 操作状态
    showActionSheet: false,
    showEditModal: false,
    showShareMenu: false,
    showDeleteConfirm: false,
    showQrModal: false,
    
    // 编辑表单
    editForm: {
      name: '',
      description: '',
      healthStatus: 'healthy',
      showOwnerInfo: true,
      allowContact: true
    },
    
    // 分享数据
    shareOptions: [
      { name: '生成分享海报', icon: '🖼️', type: 'poster' },
      { name: '分享给好友', icon: '👥', type: 'friend' },
      { name: '复制链接', icon: '🔗', type: 'link' },
      { name: '下载二维码', icon: '📱', type: 'qrcode' }
    ],
    
    // 状态标记
    petStatuses: [
      { key: 'active', name: '正常', color: '#4CAF50' },
      { key: 'lost', name: '走失', color: '#FF9800' },
      { key: 'passed', name: '已故', color: '#9E9E9E' },
      { key: 'adopted', name: '被领养', color: '#2196F3' }
    ],
    
    // 临时数据
    tempImages: [],
    isUploadingImage: false,
    qrCodeData: null,
    safeAreaBottom: 0
  },

  onLoad(options) {
    const { id, qrcode } = options
    
    // 获取安全区域
    const systemInfo = wx.getSystemInfoSync()
    this.setData({
      safeAreaBottom: systemInfo.screenHeight - systemInfo.safeArea.bottom,
      petId: id || null
    })
    
    // 如果有二维码，先解析
    if (qrcode) {
      this.processQRCode(qrcode)
    } else if (id) {
      this.loadPetDetail(id)
      this.loadHealthRecords(id)
    } else {
      wx.showToast({
        title: '参数错误',
        icon: 'error',
        complete: () => {
          setTimeout(() => wx.navigateBack(), 1500)
        }
      })
    }
  },

  onShow() {
    // 页面显示时刷新数据
    if (this.data.petId && !this.data.isLoading) {
      this.refreshPetData()
    }
  },

  onPullDownRefresh() {
    this.setData({ isRefreshing: true })
    this.refreshPetData()
  },

  onShareAppMessage() {
    const petInfo = this.data.petInfo
    if (!petInfo) return {}
    
    return {
      title: `看看我的宠物${petInfo.name}`,
      path: `/pages/pet-detail/pet-detail?id=${petInfo.id}`,
      imageUrl: petInfo.avatar || '/assets/default-pet.png'
    }
  },

  async processQRCode(qrCode) {
    try {
      wx.showLoading({ title: '解析二维码中...' })
      
      const response = await app.request({
        url: '/api/pets/qr-code',
        method: 'POST',
        data: { qrCode }
      })
      
      if (response.code === 0 && response.data) {
        const petInfo = response.data
        this.setData({
          petId: petInfo.id,
          petInfo: petInfo
        })
        this.checkOwnership()
        this.loadHealthRecords(petInfo.id)
      } else {
        throw new Error(response.msg || '二维码无效')
      }
    } catch (error) {
      console.error('处理二维码失败:', error)
      wx.showToast({
        title: error.message || '解析失败',
        icon: 'error'
      })
    } finally {
      wx.hideLoading()
    }
  },

  async loadPetDetail(petId) {
    this.setData({ isLoading: true })
    
    try {
      const response = await app.request({
        url: `/api/pets/${petId}`,
        method: 'GET'
      })
      
      if (response.code === 0) {
        const petInfo = response.data
        this.setData({
          petInfo: petInfo,
          isOwner: true, // 这个页面只有主人能进入
          isLoading: false,
          isRefreshing: false
        })
        
        // 初始化编辑表单
        this.initEditForm(petInfo)
        
        // 停止下拉刷新
        wx.stopPullDownRefresh()
        
        // 更新页面标题
        wx.setNavigationBarTitle({
          title: petInfo.name || '宠物详情'
        })
        
        // 更新全局数据
        this.updateGlobalPetData(petInfo)
      } else {
        throw new Error(response.msg || '获取宠物信息失败')
      }
    } catch (error) {
      console.error('加载宠物详情失败:', error)
      this.setData({
        isLoading: false,
        isRefreshing: false
      })
      wx.showToast({
        title: error.message || '加载失败',
        icon: 'error'
      })
      wx.stopPullDownRefresh()
    }
  },

  async loadHealthRecords(petId) {
    try {
      const response = await app.request({
        url: `/api/health/records`,
        method: 'GET',
        data: { petId }
      })
      
      if (response.code === 0) {
        const records = response.data.records || []
        const stats = response.data.stats || {}
        
        this.setData({
          healthRecords: records.slice(0, 5), // 只显示最近5条
          healthStats: {
            totalRecords: stats.totalRecords || 0,
            lastVetVisit: stats.lastVetVisit || '暂无',
            nextVaccination: stats.nextVaccination || '暂无',
            currentHealthStatus: stats.currentHealthStatus || 'healthy'
          }
        })
      }
    } catch (error) {
      console.error('加载健康记录失败:', error)
    }
  },

  initEditForm(petInfo) {
    this.setData({
      editForm: {
        name: petInfo.name || '',
        description: petInfo.description || '',
        healthStatus: petInfo.healthStatus || 'healthy',
        showOwnerInfo: petInfo.showOwnerInfo !== false,
        allowContact: petInfo.allowContact !== false,
        isPublic: petInfo.isPublic !== false
      }
    })
  },

  checkOwnership() {
    const userInfo = app.globalData.userInfo
    const petInfo = this.data.petInfo
    
    if (userInfo && petInfo && userInfo.id === petInfo.ownerId) {
      this.setData({ isOwner: true })
    } else {
      this.setData({ isOwner: false })
      wx.showToast({
        title: '您不是该宠物的主人',
        icon: 'error',
        complete: () => {
          setTimeout(() => wx.navigateBack(), 1500)
        }
      })
    }
  },

  updateGlobalPetData(petInfo) {
    const pets = app.globalData.myPets || []
    const index = pets.findIndex(pet => pet.id === petInfo.id)
    
    if (index !== -1) {
      pets[index] = { ...pets[index], ...petInfo }
      app.globalData.myPets = pets
      wx.setStorageSync('myPets', pets)
    }
  },

  refreshPetData() {
    if (this.data.petId) {
      this.loadPetDetail(this.data.petId)
      this.loadHealthRecords(this.data.petId)
    }
  },

  // 标签页切换
  switchTab(e) {
    const { tab } = e.currentTarget.dataset
    if (this.data.activeTab !== tab) {
      this.setData({ activeTab: tab })
      
      // 切换到二维码标签时生成二维码
      if (tab === 'qr' && !this.data.qrCodeData) {
        this.generateQRCode()
      }
    }
  },

  // 操作按钮
  showActionMenu() {
    this.setData({ showActionSheet: true })
  },

  hideActionMenu() {
    this.setData({ showActionSheet: false })
  },

  // 编辑宠物信息
  onEditPet() {
    this.setData({ 
      showActionSheet: false,
      showEditModal: true 
    })
  },

  // 分享宠物
  onSharePet() {
    this.setData({ 
      showActionSheet: false,
      showShareMenu: true 
    })
  },

  // 标记状态
  onMarkStatus() {
    this.setData({ showActionSheet: false })
    wx.showActionSheet({
      itemList: this.data.petStatuses.map(s => s.name),
      success: (res) => {
        const status = this.data.petStatuses[res.tapIndex]
        this.updatePetStatus(status.key)
      }
    })
  },

  // 删除宠物
  onDeletePet() {
    this.setData({ 
      showActionSheet: false,
      showDeleteConfirm: true 
    })
  },

  // 更新宠物状态
  async updatePetStatus(status) {
    try {
      wx.showLoading({ title: '更新中...' })
      
      const response = await app.request({
        url: `/api/pets/${this.data.petId}/status`,
        method: 'PUT',
        data: { status }
      })
      
      if (response.code === 0) {
        this.refreshPetData()
        wx.showToast({
          title: '状态已更新',
          icon: 'success'
        })
      } else {
        throw new Error(response.msg)
      }
    } catch (error) {
      wx.showToast({
        title: error.message || '更新失败',
        icon: 'error'
      })
    } finally {
      wx.hideLoading()
    }
  },

  // 确认删除宠物
  async confirmDeletePet() {
    try {
      wx.showLoading({ title: '删除中...' })
      
      const response = await app.request({
        url: `/api/pets/${this.data.petId}`,
        method: 'DELETE'
      })
      
      if (response.code === 0) {
        // 从全局数据中移除
        const pets = app.globalData.myPets || []
        const index = pets.findIndex(pet => pet.id === this.data.petId)
        if (index !== -1) {
          pets.splice(index, 1)
          app.globalData.myPets = pets
          wx.setStorageSync('myPets', pets)
        }
        
        wx.showToast({
          title: '删除成功',
          icon: 'success',
          complete: () => {
            setTimeout(() => {
              wx.navigateBack()
            }, 1500)
          }
        })
      } else {
        throw new Error(response.msg)
      }
    } catch (error) {
      wx.showToast({
        title: error.message || '删除失败',
        icon: 'error'
      })
    } finally {
      wx.hideLoading()
      this.setData({ showDeleteConfirm: false })
    }
  },

  // 保存编辑
  async saveEdit() {
    const form = this.data.editForm
    
    // 简单验证
    if (!form.name.trim()) {
      wx.showToast({
        title: '请输入宠物名称',
        icon: 'none'
      })
      return
    }

    try {
      wx.showLoading({ title: '保存中...' })
      
      const response = await app.request({
        url: `/api/pets/${this.data.petId}`,
        method: 'PUT',
        data: form
      })
      
      if (response.code === 0) {
        this.setData({ showEditModal: false })
        this.refreshPetData()
        wx.showToast({
          title: '保存成功',
          icon: 'success'
        })
      } else {
        throw new Error(response.msg)
      }
    } catch (error) {
      wx.showToast({
        title: error.message || '保存失败',
        icon: 'error'
      })
    } finally {
      wx.hideLoading()
    }
  },

  // 表单输入处理
  onFormInput(e) {
    const { field } = e.currentTarget.dataset
    const { value } = e.detail
    
    this.setData({
      [`editForm.${field}`]: value
    })
  },

  onFormSwitchChange(e) {
    const { field } = e.currentTarget.dataset
    const { value } = e.detail
    
    this.setData({
      [`editForm.${field}`]: value
    })
  },

  // 分享操作
  async handleShareAction(e) {
    const { type } = e.currentTarget.dataset
    this.setData({ showShareMenu: false })
    
    switch (type) {
      case 'poster':
        this.generateSharePoster()
        break
      case 'friend':
        this.shareToFriend()
        break
      case 'link':
        this.copyShareLink()
        break
      case 'qrcode':
        this.downloadQRCode()
        break
    }
  },

  // 生成分享海报
  async generateSharePoster() {
    wx.showLoading({ title: '生成中...' })
    
    try {
      // 这里调用后端生成海报的接口
      const response = await app.request({
        url: '/api/share/poster',
        method: 'POST',
        data: {
          petId: this.data.petId,
          type: 'pet'
        }
      })
      
      if (response.code === 0) {
        const posterUrl = response.data.posterUrl
        
        // 预览海报
        wx.previewImage({
          current: posterUrl,
          urls: [posterUrl]
        })
      } else {
        throw new Error(response.msg)
      }
    } catch (error) {
      wx.showToast({
        title: '生成失败',
        icon: 'error'
      })
    } finally {
      wx.hideLoading()
    }
  },

  // 分享给好友
  shareToFriend() {
    const petInfo = this.data.petInfo
    wx.shareAppMessage({
      title: `这是我的宠物${petInfo.name}`,
      path: `/pages/public-pet-info/public-pet-info?id=${petInfo.id}`,
      imageUrl: petInfo.avatar || '/assets/default-pet.png'
    })
  },

  // 复制分享链接
  copyShareLink() {
    const petInfo = this.data.petInfo
    const link = `${app.globalData.appBaseUrl}/public-pet-info?id=${petInfo.id}`
    
    wx.setClipboardData({
      data: link,
      success: () => {
        wx.showToast({
          title: '链接已复制',
          icon: 'success'
        })
      }
    })
  },

  // 下载二维码
  downloadQRCode() {
    if (!this.data.qrCodeData) {
      this.generateQRCode()
    }
    
    // 显示二维码模态框
    this.setData({ showQrModal: true })
  },

  // 生成二维码
  async generateQRCode() {
    try {
      const response = await app.request({
        url: `/api/pets/${this.data.petId}/qrcode`,
        method: 'GET'
      })
      
      if (response.code === 0) {
        this.setData({
          qrCodeData: response.data.qrCodeUrl
        })
      }
    } catch (error) {
      console.error('生成二维码失败:', error)
    }
  },

  // 保存二维码到相册
  saveQRCodeToAlbum() {
    if (!this.data.qrCodeData) return
    
    wx.showLoading({ title: '保存中...' })
    
    wx.downloadFile({
      url: this.data.qrCodeData,
      success: (res) => {
        wx.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
          success: () => {
            wx.showToast({
              title: '保存成功',
              icon: 'success'
            })
            this.setData({ showQrModal: false })
          },
          fail: (err) => {
            if (err.errMsg.includes('auth')) {
              this.showAuthModal('scope.writePhotosAlbum')
            } else {
              wx.showToast({
                title: '保存失败',
                icon: 'error'
              })
            }
          }
        })
      },
      fail: () => {
        wx.showToast({
          title: '下载失败',
          icon: 'error'
        })
      },
      complete: () => {
        wx.hideLoading()
      }
    })
  },

  // 显示权限申请模态框
  showAuthModal(scope) {
    wx.showModal({
      title: '权限申请',
      content: '需要相册权限才能保存图片',
      confirmText: '去设置',
      success: (res) => {
        if (res.confirm) {
          wx.openSetting()
        }
      }
    })
  },

  // 上传图片
  uploadImage() {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const tempFilePath = res.tempFilePaths[0]
        this.setData({ isUploadingImage: true })
        
        // 上传到服务器
        wx.uploadFile({
          url: `${app.globalData.apiBase}/api/upload`,
          filePath: tempFilePath,
          name: 'file',
          formData: {
            petId: this.data.petId,
            type: 'avatar'
          },
          success: (uploadRes) => {
            const result = JSON.parse(uploadRes.data)
            if (result.code === 0) {
              // 更新宠物头像
              this.updatePetAvatar(result.data.url)
            }
          },
          complete: () => {
            this.setData({ isUploadingImage: false })
          }
        })
      }
    })
  },

  // 更新宠物头像
  async updatePetAvatar(avatarUrl) {
    try {
      const response = await app.request({
        url: `/api/pets/${this.data.petId}`,
        method: 'PUT',
        data: { avatar: avatarUrl }
      })
      
      if (response.code === 0) {
        this.refreshPetData()
        wx.showToast({
          title: '头像更新成功',
          icon: 'success'
        })
      }
    } catch (error) {
      console.error('更新头像失败:', error)
    }
  },

  // 查看健康记录
  viewHealthRecord(e) {
    const { id } = e.currentTarget.dataset
    wx.navigateTo({
      url: `/pages/health-record/health-record?id=${id}`
    })
  },

  // 添加健康记录
  addHealthRecord() {
    wx.navigateTo({
      url: `/pages/health-add/health-add?petId=${this.data.petId}`
    })
  },

  // 查看所有健康记录
  viewAllHealthRecords() {
    wx.navigateTo({
      url: `/pages/health/health?petId=${this.data.petId}`
    })
  },

  // 图片预览
  previewImages(e) {
    const { index } = e.currentTarget.dataset
    const images = this.data.petInfo.images || []
    
    if (images.length > 0) {
      wx.previewImage({
        current: images[index],
        urls: images
      })
    }
  },

  // 添加照片
  addPhoto() {
    wx.chooseImage({
      count: 9,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const tempFiles = res.tempFilePaths
        this.uploadPetImages(tempFiles)
      }
    })
  },

  // 上传宠物照片
  async uploadPetImages(files) {
    wx.showLoading({ title: '上传中...' })
    
    try {
      const uploadPromises = files.map(file => {
        return new Promise((resolve, reject) => {
          wx.uploadFile({
            url: `${app.globalData.apiBase}/api/upload`,
            filePath: file,
            name: 'file',
            formData: {
              petId: this.data.petId,
              type: 'image'
            },
            success: (uploadRes) => {
              const result = JSON.parse(uploadRes.data)
              if (result.code === 0) {
                resolve(result.data.url)
              } else {
                reject(new Error(result.msg))
              }
            },
            fail: reject
          })
        })
      })
      
      const urls = await Promise.all(uploadPromises)
      
      // 更新宠物照片
      const currentImages = this.data.petInfo.images || []
      const updatedImages = [...currentImages, ...urls]
      
      await app.request({
        url: `/api/pets/${this.data.petId}`,
        method: 'PUT',
        data: { images: updatedImages }
      })
      
      this.refreshPetData()
      wx.showToast({
        title: '照片上传成功',
        icon: 'success'
      })
    } catch (error) {
      wx.showToast({
        title: '上传失败',
        icon: 'error'
      })
    } finally {
      wx.hideLoading()
    }
  }
})
// pages/pet-detail/pet-detail.js
Page({
  data: {
    // 使用下划线命名的变量
    pet_info: null,
    health_stats: {},
    is_loading: false,
    is_refreshing: false,
    is_owner: false,
    show_action_sheet: false,
    show_edit_modal: false,
    show_delete_confirm: false,
    active_tab: 'info',
    tabs: [
      { key: 'info', name: '信息', icon: '📋' },
      { key: 'health', name: '健康', icon: '🏥' },
      { key: 'records', name: '记录', icon: '📝' },
      { key: 'qr', name: '二维码', icon: '🔗' }
    ]
  },
  
  // 获取状态颜色
  get_status_color: function() {
    const status = this.data.pet_info.status;
    const statuses = {
      'active': '#4CAF50',
      'healthy': '#4CAF50',
      'sick': '#FF9800',
      'injured': '#F44336',
      'lost': '#607D8B',
      'deceased': '#9E9E9E'
    };
    return statuses[status] || '#4CAF50';
  },
  
  // 获取状态名称
  get_status_name: function() {
    const status = this.data.pet_info.status;
    const statuses = {
      'active': '正常',
      'healthy': '健康',
      'sick': '生病',
      'injured': '受伤',
      'lost': '走失',
      'deceased': '已故'
    };
    return statuses[status] || '正常';
  },
  
  // 获取健康状态文本
  get_health_status_text: function() {
    const status = this.data.health_stats.current_health_status;
    return status === 'healthy' ? '健康' : '需关注';
  },
  
  // 获取类型图标
  get_type_icon: function() {
    return this.data.pet_info.type === 'dog' ? '🐶' : '🐱';
  },
  
  // 获取类型名称
  get_type_name: function() {
    return this.data.pet_info.type === 'dog' ? '狗狗' : '猫咪';
  },
  
  // 获取状态标签
  get_status_tags: function() {
    const pet = this.data.pet_info;
    const health = this.data.health_stats;
    
    return [
      {
        label: '健康状态',
        value: health.current_health_status === 'healthy' ? '健康' : '需关注',
        color: health.current_health_status === 'healthy' ? '#4CAF50' : '#FF9800'
      },
      {
        label: '体重',
        value: pet.weight ? pet.weight + 'kg' : '未记录',
        color: '#2196F3'
      },
      {
        label: '绝育',
        value: pet.neutered ? '已绝育' : '未绝育',
        color: '#9C27B0'
      },
      {
        label: '芯片',
        value: pet.chip_id ? '已植入' : '未植入',
        color: '#607D8B'
      }
    ];
  },
  
  // 其他辅助函数...
});