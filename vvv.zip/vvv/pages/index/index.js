// pages/index/index.js
const app = getApp()
const request = require('../../utils/request')
const { showModal, showToast, scanCode } = require('../../utils/wxapi')
const { formatDate } = require('../../utils/util')

Page({
  data: {
    userInfo: null,
    isLogged: false,
    stats: {
      petCount: 0,
      healthCount: 0,
      vaccineCount: 0,
      reminderCount: 0
    },
    recentPets: [],
    healthReminders: [],
    quickActions: [
      { 
        id: 'scan',
        icon: '/assets/icons/qr-scan.png', 
        text: '扫码绑定', 
        action: 'scan' 
      },
      { 
        id: 'add',
        icon: '/assets/icons/add-pet.png', 
        text: '添加宠物', 
        action: 'addPet' 
      },
      { 
        id: 'health',
        icon: '/assets/icons/health.png', 
        text: '健康记录', 
        action: 'health' 
      },
      { 
        id: 'lost',
        icon: '/assets/icons/shield.png', 
        text: '防丢失', 
        action: 'lostPrevention' 
      }
    ],
    banners: [
      {
        id: 1,
        image: '/assets/images/banner1.jpg',
        title: '智能宠物管理',
        desc: '一站式宠物信息管理平台'
      },
      {
        id: 2,
        image: '/assets/images/banner2.jpg',
        title: '健康无忧',
        desc: '疫苗提醒、医疗记录全掌握'
      },
      {
        id: 3,
        image: '/assets/images/banner3.jpg',
        title: '防丢失保障',
        desc: '二维码绑定，快速找回宠物'
      }
    ],
    today: '',
    loading: false,
    hasMore: false,
    page: 1,
    pageSize: 10,
    screenHeight: 667,
    screenWidth: 375,
    statusBarHeight: 20,
    navBarHeight: 44,
    // 动画相关
    userSectionAni: '',
    bannerAni: '',
    quickAni: '',
    statsAni: '',
    petsAni: '',
    remindersAni: '',
    emptyAni: '',
    petCardAni: []
  },

  onLoad(options) {
    this.initPage()
    // 初始化入场动画
    this.initAnimations()
  },

  onShow() {
    this.checkLoginStatus()
    if (app.globalData.isLogged) {
      this.loadHomeData()
    }
  },

  onPullDownRefresh() {
    this.refreshData()
  },

  onReachBottom() {
    if (this.data.hasMore && !this.data.loading) {
      this.loadMoreData()
    }
  },

  onShareAppMessage() {
    return {
      title: '智能宠物管家 - 让爱宠得到更好的照顾',
      path: '/pages/index/index',
      imageUrl: '/assets/images/share.jpg'
    }
  },

  // 初始化页面
  initPage() {
    const today = formatDate(new Date(), 'MM月DD日')
    
    try {
      const windowInfo = wx.getWindowInfo()
      const menuButtonInfo = wx.getMenuButtonBoundingClientRect()
      const statusBarHeight = windowInfo.statusBarHeight
      const navBarHeight = (menuButtonInfo.top - statusBarHeight) * 2 + menuButtonInfo.height
      
      this.setData({ 
        today,
        screenHeight: windowInfo.windowHeight,
        screenWidth: windowInfo.windowWidth,
        statusBarHeight,
        navBarHeight
      })
    } catch (error) {
      const systemInfo = wx.getSystemInfoSync()
      this.setData({ 
        today,
        screenHeight: systemInfo.windowHeight,
        screenWidth: systemInfo.windowWidth,
        statusBarHeight: systemInfo.statusBarHeight || 20,
        navBarHeight: 44
      })
    }
  },

  // 初始化入场动画
  initAnimations() {
    // 创建渐入动画
    const createFadeInAni = (delay = 0) => {
      return wx.createAnimation({
        duration: 600,
        timingFunction: 'ease-out',
        delay
      }).opacity(1).translateY(0).step().export()
    }

    // 逐区域延迟入场
    this.setData({
      userSectionAni: createFadeInAni(100),
      bannerAni: createFadeInAni(300),
      quickAni: createFadeInAni(500),
      statsAni: createFadeInAni(700),
      petsAni: createFadeInAni(900),
      remindersAni: createFadeInAni(1100),
      emptyAni: createFadeInAni(500)
    })
  },

  // 数字增长动画
  countUpAnimation() {
    const stats = this.data.stats
    const elements = ['petCount', 'healthCount', 'vaccineCount', 'reminderCount']
    
    elements.forEach(key => {
      const value = stats[key]
      if (value > 0) {
        // 给数字添加动画类
        wx.createSelectorQuery().select(`#${key}`).boundingClientRect(rect => {
          if (rect) {
            // 这里可以实现数字递增动画，简化版先加过渡类
            this.setData({
              [`stats.${key}`]: value
            })
          }
        }).exec()
      }
    })

    // 宠物卡片逐个入场
    if (this.data.recentPets.length > 0) {
      const petCardAni = this.data.recentPets.map((_, index) => {
        return wx.createAnimation({
          duration: 500,
          timingFunction: 'ease-out',
          delay: 200 * index
        }).opacity(1).translateY(0).step().export()
      })
      this.setData({ petCardAni })
    }
  },

  // 检查登录状态
  async checkLoginStatus() {
    const isLogged = app.globalData.isLogged || false
    const userInfo = app.globalData.userInfo || null
    
    this.setData({
      isLogged,
      userInfo: isLogged && userInfo ? userInfo : null
    })

    if (!isLogged) {
      this.showLoginModal('请先登录以使用完整功能')
    }
  },

  showLoginModal(content = '请先登录以使用完整功能') {
    showModal('登录提示', content).then(res => {
      if (res.confirm) {
        wx.navigateTo({
          url: '/pages/login/login'
        })
      }
    })
  },

  goToLogin() {
    wx.navigateTo({
      url: '/pages/login/login'
    })
  },

  // 加载首页数据
  async loadHomeData() {
    if (this.data.loading) return
    
    this.setData({ loading: true })
    
    try {
      const promises = [
        this.getHomeStats(),
        this.getRecentPets(),
        this.getHealthReminders()
      ]
      
      const [stats, recentPets, reminders] = await Promise.all(promises)
      
      this.setData({
        stats: stats || this.data.stats,
        recentPets: recentPets || [],
        healthReminders: reminders || [],
        loading: false
      })

      // 数据加载完成后执行数字动画
      this.countUpAnimation()
    } catch (error) {
      console.error('加载首页数据失败:', error)
      this.setData({ loading: false })
      this.loadLocalData()
      // 本地数据也执行动画
      this.countUpAnimation()
    }
  },

  // 获取首页统计
  async getHomeStats() {
    try {
      const res = await request.get('/home/stats', {
        showLoading: false
      })
      return res
    } catch (error) {
      const pets = app.globalData.pets || []
      const healthRecords = wx.getStorageSync('healthRecords') || []
      
      const today = new Date()
      const vaccineReminders = healthRecords.filter(record => {
        if (record.type === 'vaccine' && record.nextDate) {
          const nextDate = new Date(record.nextDate)
          const diffDays = Math.ceil((nextDate - today) / (1000 * 60 * 60 * 24))
          return diffDays <= 7 && diffDays >= 0
        }
        return false
      }).length
      
      return {
        petCount: pets.length,
        healthCount: healthRecords.length,
        vaccineCount: vaccineReminders,
        reminderCount: (wx.getStorageSync('notifications') || []).filter(n => !n.read).length
      }
    }
  },

  // 获取最近宠物
  async getRecentPets() {
    try {
      const res = await request.get('/pets/recent', {
        limit: 3,
        showLoading: false
      })
      return res
    } catch (error) {
      const pets = app.globalData.pets || []
      return pets.slice(0, 3).map(pet => ({
        id: pet.id || Date.now(),
        name: pet.name || '未命名',
        avatar: pet.avatar || '🐕',
        breed: pet.breed || '',
        type: pet.type || '狗',
        age: pet.age || '年龄未知',
        status: pet.status || 'normal'
      }))
    }
  },

  // 获取健康提醒
  async getHealthReminders() {
    try {
      const res = await request.get('/health/reminders', {
        showLoading: false
      })
      return res.slice(0, 5)
    } catch (error) {
      const notifications = wx.getStorageSync('notifications') || []
      const healthRecords = wx.getStorageSync('healthRecords') || []
      
      const reminders = notifications.filter(n => !n.read).map(n => ({
        id: n.id || Date.now(),
        type: n.type || 'other',
        title: n.title || '提醒',
        description: n.message || '',
        time: n.time || formatDate(new Date(), 'MM-DD HH:mm'),
        petId: n.petId || '',
        read: n.read || false
      }))
      
      return reminders.slice(0, 5)
    }
  },

  // 加载本地数据
  loadLocalData() {
    const pets = app.globalData.pets || []
    const healthRecords = wx.getStorageSync('healthRecords') || []
    const notifications = wx.getStorageSync('notifications') || []
    
    const stats = {
      petCount: pets.length,
      healthCount: healthRecords.length,
      vaccineCount: healthRecords.filter(r => r.type === 'vaccine').length,
      reminderCount: notifications.filter(n => !n.read).length
    }
    
    const recentPets = pets.slice(0, 3).map(pet => ({
      id: pet.id || Date.now(),
      name: pet.name || '未命名',
      avatar: pet.avatar || '🐕',
      breed: pet.breed || '',
      type: pet.type || '狗',
      age: pet.age || '年龄未知',
      status: pet.status || 'normal'
    }))
    
    const healthReminders = notifications
      .filter(n => !n.read)
      .slice(0, 5)
      .map(n => ({
        id: n.id || Date.now(),
        type: n.type || 'other',
        title: n.title || '提醒',
        description: n.message || '',
        time: n.time || formatDate(new Date(), 'MM-DD HH:mm'),
        petId: n.petId || ''
      }))
    
    this.setData({
      stats,
      recentPets,
      healthReminders
    })
  },

  // 刷新数据
  async refreshData() {
    if (this.data.loading) return
    
    this.setData({ loading: true })
    
    try {
      await this.loadHomeData()
      showToast('刷新成功', 'success')
    } catch (error) {
      showToast('刷新失败', 'none')
    } finally {
      wx.stopPullDownRefresh()
      this.setData({ loading: false })
    }
  },

  loadMoreData() {
    this.setData({ hasMore: false })
  },

  onScan() {
    if (!this.data.isLogged) {
      this.showLoginModal('扫码绑定宠物需要登录')
      return
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    })
  },

  onAddPet() {
    if (!this.data.isLogged) {
      this.showLoginModal('添加宠物需要登录')
      return
    }
    
    wx.navigateTo({
      url: '/pages/add-pet/add-pet'
    })
  },

  onHealth() {
    if (!this.data.isLogged) {
      this.showLoginModal('查看健康记录需要登录')
      return
    }
    
    wx.navigateTo({
      url: '/pages/health/health'
    })
  },

  onLostPrevention() {
    if (!this.data.isLogged) {
      this.showLoginModal('防丢失功能需要登录')
      return
    }
    
    showModal('防丢失功能', '此功能正在开发中，敬请期待！').then(() => {
      // wx.navigateTo({
      //   url: '/pages/lost-prevention/lost-prevention'
      // })
    })
  },

  onQuickAction(e) {
    const { action } = e.currentTarget.dataset
    switch (action) {
      case 'scan':
        this.onScan()
        break
      case 'addPet':
        this.onAddPet()
        break
      case 'health':
        this.onHealth()
        break
      case 'lostPrevention':
        this.onLostPrevention()
        break
    }
  },

  onViewPet(e) {
    const { petId } = e.currentTarget.dataset
    if (!petId) return
    
    wx.navigateTo({
      url: `/pages/pet-detail/pet-detail?petId=${petId}`
    })
  },

  onViewAllPets() {
    wx.switchTab({
      url: '/pages/pets/pets'
    })
  },

  onViewReminder(e) {
    const { reminderId } = e.currentTarget.dataset
    if (!reminderId) return
    
    this.markReminderAsRead(reminderId)
    
    wx.navigateTo({
      url: `/pages/health/health?reminderId=${reminderId}`
    })
  },

  markReminderAsRead(reminderId) {
    const notifications = wx.getStorageSync('notifications') || []
    const updated = notifications.map(n => 
      n.id === reminderId ? { ...n, read: true } : n
    )
    
    wx.setStorageSync('notifications', updated)
    
    const healthReminders = this.data.healthReminders.filter(
      r => r.id !== reminderId
    )
    
    this.setData({
      healthReminders,
      'stats.reminderCount': Math.max(0, this.data.stats.reminderCount - 1)
    })
  },

  onTodayTap() {
    const today = new Date()
    const formattedDate = formatDate(today, 'YYYY年MM月DD日')
    showModal('今天是', formattedDate)
  },

  onWeatherTap() {
    showModal('天气信息', '天气功能正在开发中')
  },

  onUserAvatarTap() {
    if (this.data.isLogged && this.data.userInfo) {
      wx.navigateTo({
        url: '/pages/user/user'
      })
    }
  },

  onLongCopy(e) {
    const text = e.currentTarget.dataset.text
    if (text) {
      wx.setClipboardData({
        data: text,
        success: () => {
          showToast('已复制到剪贴板', 'success')
        }
      })
    }
  },

  onBannerTap(e) {
    const index = e.currentTarget.dataset.index
    const banner = this.data.banners[index]
    showModal(banner.title, banner.desc)
  },

  onViewAllReminders() {
    wx.navigateTo({
      url: '/pages/notifications/notifications'
    })
  },

  onError(e) {
    console.log('图片加载失败:', e.detail)
    const type = e.currentTarget.dataset.type
    console.log('图片类型:', type)
  }
})