// pages/index-logged/index-logged.js
Page({
  data: {
    // 用户信息
    userInfo: {
      nickname: '',
      avatar: ''
    },
    
    // 首页统计数据
    stats: {
      totalPets: 0,
      healthReminders: 0,
      upcomingEvents: 0,
      communityActivities: 0
    },
    
    // 最近的宠物列表
    recentPets: [],
    
    // 健康提醒
    healthReminders: [],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        color: '#4CAF50',
        path: '/pages/addPet/addPet'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        color: '#2196F3',
        path: '/pages/scan/scan'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#FF9800',
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区',
        icon: '👥',
        color: '#9C27B0',
        path: '/pages/community/community'
      }
    ],
    
    // 功能卡片
    featureCards: [
      {
        id: 'petManagement',
        title: '宠物管理',
        desc: '管理您所有宠物的信息',
        icon: '🐾',
        color: '#4CAF50',
        path: '/pages/pets/pets'
      },
      {
        id: 'healthRecords',
        title: '健康档案',
        desc: '记录宠物的健康状况',
        icon: '📋',
        color: '#2196F3',
        path: '/pages/health/health'
      },
      {
        id: 'reminders',
        title: '提醒事项',
        desc: '疫苗接种、驱虫等提醒',
        icon: '⏰',
        color: '#FF9800',
        path: '/pages/reminders/reminders'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        desc: '宠物丢失或紧急情况',
        icon: '🆘',
        color: '#f44336',
        path: '/pages/emergency/emergency'
      }
    ],
    
    // 活动公告
    announcements: [
      {
        id: 1,
        title: '宠物健康检查活动',
        content: '合作宠物医院免费体检',
        time: '进行中',
        type: 'activity'
      },
      {
        id: 2,
        title: '新功能上线',
        content: '宠物健康管理系统升级',
        time: '2天前',
        type: 'update'
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    showGreeting: true,
    currentTime: '',
    greeting: '',
    
    // 天气信息
    weather: {
      temperature: '26°',
      condition: '晴',
      location: '北京市'
    }
  },

  onLoad(options) {
    console.log('index-logged onLoad');
    this.initPage();
  },

  onShow() {
    // 更新时间和问候语
    this.updateTimeAndGreeting();
    
    // 刷新数据
    this.refreshData();
    
    // 检查是否有新消息
    this.checkNewMessages();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshData(true);
  },

  onShareAppMessage() {
    return {
      title: '宠物管家 - 专业的宠物管理工具',
      path: '/pages/index/index',
      imageUrl: '/images/share-default.jpg'
    };
  },

  onShareTimeline() {
    return {
      title: '我在使用宠物管家管理我的宠物',
      query: '',
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 初始化页面
   */
  initPage() {
    // 加载用户信息
    this.loadUserInfo();
    
    // 更新时间问候
    this.updateTimeAndGreeting();
    
    // 开始时间更新定时器
    this.startTimeUpdate();
    
    // 加载首页数据
    this.loadHomeData();
  },

  /**
   * 加载用户信息
   */
  loadUserInfo() {
    const app = getApp();
    const userInfo = app.globalData.userInfo || wx.getStorageSync('userInfo');
    
    if (userInfo) {
      this.setData({
        userInfo: {
          nickname: userInfo.nickname || '用户',
          avatar: userInfo.avatar || '/images/default-avatar.png'
        }
      });
    }
  },

  /**
   * 更新时间问候语
   */
  updateTimeAndGreeting() {
    const now = new Date();
    const hours = now.getHours();
    let greeting = '';
    
    if (hours >= 5 && hours < 9) {
      greeting = '早上好';
    } else if (hours >= 9 && hours < 12) {
      greeting = '上午好';
    } else if (hours >= 12 && hours < 14) {
      greeting = '中午好';
    } else if (hours >= 14 && hours < 18) {
      greeting = '下午好';
    } else if (hours >= 18 && hours < 22) {
      greeting = '晚上好';
    } else {
      greeting = '夜深了';
    }
    
    const timeString = now.toLocaleTimeString('zh-CN', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
    
    this.setData({
      currentTime: timeString,
      greeting: greeting
    });
  },

  /**
   * 开始时间更新定时器
   */
  startTimeUpdate() {
    // 每分钟更新一次时间
    setInterval(() => {
      this.updateTimeAndGreeting();
    }, 60000);
  },

  /**
   * 加载首页数据
   */
  async loadHomeData() {
    this.setData({ loading: true });
    
    try {
      // 并行加载数据
      await Promise.all([
        this.loadStats(),
        this.loadRecentPets(),
        this.loadHealthReminders(),
        this.loadWeather()
      ]);
      
    } catch (error) {
      console.error('加载首页数据失败:', error);
      wx.showToast({
        title: '数据加载失败',
        icon: 'error'
      });
    } finally {
      this.setData({ loading: false });
    }
  },

  /**
   * 刷新数据
   */
  async refreshData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await this.loadHomeData();
      
      if (forceRefresh) {
        wx.showToast({
          title: '刷新成功',
          icon: 'success'
        });
      }
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 加载统计数据
   */
  async loadStats() {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        totalPets: pets.length,
        healthReminders: reminders.filter(r => r.type === 'health').length,
        upcomingEvents: reminders.filter(r => r.daysLeft <= 7).length,
        communityActivities: 3 // 模拟数据
      };
      
      this.setData({ stats });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 加载最近的宠物
   */
  async loadRecentPets() {
    try {
      const pets = wx.getStorageSync('pets') || [];
      
      // 按添加时间排序，取前4个
      const recentPets = pets
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .slice(0, 4)
        .map(pet => ({
          id: pet.id,
          name: pet.name,
          avatar: pet.avatar || '/images/default-pet-avatar.png',
          type: pet.type,
          breed: pet.breed,
          age: pet.age,
          healthStatus: pet.healthStatus || '良好'
        }));
      
      this.setData({ recentPets });
      
    } catch (error) {
      console.error('加载最近宠物失败:', error);
    }
  },

  /**
   * 加载健康提醒
   */
  async loadHealthReminders() {
    try {
      const reminders = wx.getStorageSync('reminders') || [];
      
      // 取最近3个未完成的健康提醒
      const healthReminders = reminders
        .filter(r => r.type === 'health' && !r.completed)
        .sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate))
        .slice(0, 3)
        .map(reminder => ({
          id: reminder.id,
          title: reminder.title,
          petName: reminder.petName,
          dueDate: this.formatDueDate(reminder.dueDate),
          daysLeft: reminder.daysLeft,
          type: reminder.subType // vaccination, deworming, etc.
        }));
      
      this.setData({ healthReminders });
      
    } catch (error) {
      console.error('加载健康提醒失败:', error);
    }
  },

  /**
   * 格式化到期日期
   */
  formatDueDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diffDays = Math.ceil((date - now) / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) {
      return '今天到期';
    } else if (diffDays === 1) {
      return '明天到期';
    } else if (diffDays < 0) {
      return '已过期';
    } else {
      return `${diffDays}天后到期`;
    }
  },

  /**
   * 加载天气信息
   */
  async loadWeather() {
    try {
      // 模拟天气API
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const weather = {
        temperature: `${Math.floor(Math.random() * 10) + 20}°`,
        condition: ['晴', '多云', '阴', '小雨'][Math.floor(Math.random() * 4)],
        location: '北京市'
      };
      
      this.setData({ weather });
      
    } catch (error) {
      console.error('加载天气失败:', error);
    }
  },

  /**
   * 检查新消息
   */
  checkNewMessages() {
    // 模拟检查新消息
    const hasNewMessages = Math.random() > 0.5;
    
    if (hasNewMessages) {
      wx.showTabBarRedDot({
        index: 2 // 消息tab的索引
      });
    }
  },

  /**
   * 点击宠物卡片
   */
  onPetTap(e) {
    const { pet } = e.currentTarget.dataset;
    
    if (pet && pet.id) {
      wx.navigateTo({
        url: `/pages/pet-detail/pet-detail?id=${pet.id}`
      });
    }
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    if (!action || !action.path) return;
    
    if (action.path.includes('/pages/')) {
      wx.navigateTo({
        url: action.path
      });
    } else if (action.path.includes('/tabBar/')) {
      wx.switchTab({
        url: action.path
      });
    }
  },

  /**
   * 点击功能卡片
   */
  onFeatureCardTap(e) {
    const { card } = e.currentTarget.dataset;
    
    if (!card || !card.path) return;
    
    wx.navigateTo({
      url: card.path
    });
  },

  /**
   * 点击健康提醒
   */
  onHealthReminderTap(e) {
    const { reminder } = e.currentTarget.dataset;
    
    if (reminder && reminder.id) {
      wx.navigateTo({
        url: `/pages/health-detail/health-detail?id=${reminder.id}`
      });
    }
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 查看更多宠物
   */
  viewAllPets() {
    wx.switchTab({
      url: '/pages/pets/pets'
    });
  },

  /**
   * 查看更多提醒
   */
  viewAllReminders() {
    wx.navigateTo({
      url: '/pages/reminders/reminders'
    });
  },

  /**
   * 搜索功能
   */
  onSearchTap() {
    wx.navigateTo({
      url: '/pages/search/search'
    });
  },

  /**
   * 消息中心
   */
  onMessageTap() {
    wx.switchTab({
      url: '/pages/messages/messages'
    });
  },

  /**
   * 个人中心
   */
  onProfileTap() {
    wx.switchTab({
      url: '/pages/mine/mine'
    });
  },

  /**
   * 隐藏欢迎语
   */
  hideGreeting() {
    this.setData({
      showGreeting: false
    });
  },

  /**
   * 刷新天气
   */
  refreshWeather() {
    this.loadWeather();
  }
});