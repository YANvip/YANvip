// pages/bind-process/bind-process.js
Page({
  data: {
    // 状态：loading | notRegistered | isOwner | isVisitor | error
    status: 'loading',
    qrCode: '', // 二维码数据
    petData: null, // 宠物数据
    userInfo: null, // 用户信息
    showOwnerInfo: false, // 是否显示主人信息
    countdown: 5, // 倒计时（主人查看时自动跳转）
    timer: null, // 倒计时定时器
    isLogging: false, // 登录中状态
    
    // 错误信息
    errorMsg: '',
    
    // 按钮状态
    buttons: {
      primary: { text: '', disabled: false },
      secondary: { text: '', disabled: false }
    }
  },

  onLoad(options) {
    console.log('bind-process onLoad options:', options);
    
    // 获取传递的参数
    const { scene, qrcode, code } = options;
    const qrData = qrcode || code || scene;
    
    if (!qrData) {
      this.setData({
        status: 'error',
        errorMsg: '未获取到二维码信息，请重新扫码'
      });
      return;
    }
    
    this.setData({
      qrCode: qrData
    });
    
    // 初始化页面
    this.initPage();
  },

  onShow() {
    // 页面显示时，如果之前是未登录状态，重新检查
    if (this.data.status === 'isVisitor' && this.checkLoginStatus()) {
      this.checkQRCodeStatus();
    }
  },

  onUnload() {
    // 清理定时器
    if (this.data.timer) {
      clearInterval(this.data.timer);
    }
  },

  /**
   * 初始化页面
   */
  initPage() {
    // 获取用户信息
    const app = getApp();
    const userInfo = app.globalData.userInfo;
    
    this.setData({
      userInfo: userInfo
    });
    
    // 检查二维码状态
    this.checkQRCodeStatus();
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    return app.globalData.userInfo && app.globalData.isLoggedIn;
  },

  /**
   * 检查二维码状态
   */
  async checkQRCodeStatus() {
    const { qrCode } = this.data;
    
    try {
      // 显示加载状态
      wx.showLoading({
        title: '正在查询...',
        mask: true
      });
      
      // 调用后端接口查询二维码状态
      const result = await this.requestQRCodeStatus(qrCode);
      
      wx.hideLoading();
      
      if (result.success) {
        const { pet, isOwner, isRegistered } = result.data;
        
        if (!isRegistered) {
          // 未注册状态
          this.handleNotRegistered();
        } else if (isOwner) {
          // 已注册且是主人
          this.handleOwnerView(pet);
        } else {
          // 已注册但不是主人（游客）
          this.handleVisitorView(pet);
        }
      } else {
        this.setData({
          status: 'error',
          errorMsg: result.message || '查询二维码状态失败'
        });
      }
    } catch (error) {
      wx.hideLoading();
      console.error('查询二维码状态失败:', error);
      this.setData({
        status: 'error',
        errorMsg: '网络错误，请稍后重试'
      });
    }
  },

  /**
   * 请求二维码状态（模拟/实际接口）
   */
  async requestQRCodeStatus(qrCode) {
    // 模拟请求延迟
    await new Promise(resolve => setTimeout(resolve, 800));
    
    // 从本地缓存获取用户信息
    const app = getApp();
    const userInfo = app.globalData.userInfo;
    const userId = userInfo ? userInfo.id : null;
    
    // 模拟从本地缓存获取宠物数据
    const pets = wx.getStorageSync('pets') || [];
    const pet = pets.find(p => p.qrCode === qrCode);
    
    if (!pet) {
      return {
        success: true,
        data: {
          pet: null,
          isOwner: false,
          isRegistered: false
        }
      };
    }
    
    const isOwner = userId && pet.ownerId === userId;
    
    return {
      success: true,
      data: {
        pet: pet,
        isOwner: isOwner,
        isRegistered: true
      }
    };
  },

  /**
   * 处理未注册状态
   */
  handleNotRegistered() {
    const { userInfo } = this.data;
    
    if (userInfo) {
      // 已登录，直接跳转到添加宠物页面
      this.navigateToAddPet();
    } else {
      // 未登录，显示登录引导
      this.setData({
        status: 'notRegistered',
        buttons: {
          primary: {
            text: '立即登录并绑定',
            disabled: false
          },
          secondary: {
            text: '仅查看公开信息',
            disabled: false
          }
        }
      });
    }
  },

  /**
   * 处理主人查看状态
   */
  handleOwnerView(pet) {
    this.setData({
      status: 'isOwner',
      petData: pet,
      showOwnerInfo: true
    });
    
    // 开始倒计时自动跳转
    this.startCountdown();
  },

  /**
   * 处理游客查看状态
   */
  handleVisitorView(pet) {
    this.setData({
      status: 'isVisitor',
      petData: pet,
      showOwnerInfo: pet.showOwnerInfo || false
    });
  },

  /**
   * 开始倒计时
   */
  startCountdown() {
    let countdown = 5;
    
    const timer = setInterval(() => {
      countdown--;
      
      if (countdown <= 0) {
        clearInterval(timer);
        this.navigateToPetDetail();
      } else {
        this.setData({
          countdown: countdown
        });
      }
    }, 1000);
    
    this.setData({
      timer: timer,
      countdown: countdown
    });
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    const { qrCode } = this.data;
    
    wx.redirectTo({
      url: `/pages/add-pet/add-pet?qrcode=${encodeURIComponent(qrCode)}`
    });
  },

  /**
   * 跳转到宠物详情页面
   */
  navigateToPetDetail() {
    const { petData } = this.data;
    
    if (petData && petData.id) {
      wx.redirectTo({
        url: `/pages/pet-detail/pet-detail?id=${petData.id}`
      });
    }
  },

  /**
   * 跳转到公开信息页面
   */
  navigateToPublicInfo() {
    const { petData } = this.data;
    
    if (petData && petData.id) {
      wx.redirectTo({
        url: `/pages/public-pet-info/public-pet-info?id=${petData.id}`
      });
    }
  },

  /**
   * 主按钮点击事件
   */
  onPrimaryButtonTap() {
    const { status, isLogging } = this.data;
    
    if (isLogging) return;
    
    switch (status) {
      case 'notRegistered':
        this.handleLogin();
        break;
      case 'isOwner':
        this.navigateToPetDetail();
        break;
      case 'isVisitor':
        this.navigateToPublicInfo();
        break;
      case 'error':
        this.checkQRCodeStatus();
        break;
    }
  },

  /**
   * 次按钮点击事件
   */
  onSecondaryButtonTap() {
    const { status } = this.data;
    
    switch (status) {
      case 'notRegistered':
        // 游客查看公开信息（需要先查询是否有公开信息）
        this.checkQRCodeStatusForVisitor();
        break;
      case 'isOwner':
        // 主人查看时，取消倒计时
        if (this.data.timer) {
          clearInterval(this.data.timer);
          this.setData({
            timer: null,
            countdown: 0
          });
        }
        break;
    }
  },

  /**
   * 处理登录
   */
  async handleLogin() {
    if (this.data.isLogging) return;
    
    this.setData({ isLogging: true });
    
    try {
      const app = getApp();
      
      // 调用微信登录
      const loginResult = await app.wxLogin();
      
      if (loginResult.success) {
        // 登录成功，重新检查二维码状态
        this.checkQRCodeStatus();
      } else {
        wx.showToast({
          title: '登录失败',
          icon: 'error'
        });
      }
    } catch (error) {
      console.error('登录失败:', error);
    } finally {
      this.setData({ isLogging: false });
    }
  },

  /**
   * 为游客检查二维码状态
   */
  async checkQRCodeStatusForVisitor() {
    const { qrCode } = this.data;
    
    try {
      wx.showLoading({
        title: '正在查询...',
        mask: true
      });
      
      // 模拟查询，不传递用户信息
      const result = await this.requestQRCodeStatus(qrCode);
      
      wx.hideLoading();
      
      if (result.success && result.data.isRegistered) {
        // 有注册信息，跳转到公开信息页面
        this.navigateToPublicInfo();
      } else {
        // 没有注册信息
        wx.showModal({
          title: '提示',
          content: '该二维码尚未绑定宠物信息',
          showCancel: false
        });
      }
    } catch (error) {
      wx.hideLoading();
      console.error('查询失败:', error);
    }
  },

  /**
   * 重新扫码
   */
  onRescanTap() {
    wx.navigateBack({
      delta: 1
    });
  },

  /**
   * 返回首页
   */
  onBackHomeTap() {
    wx.switchTab({
      url: '/pages/index/index'
    });
  }
});