// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});// pages/mine/mine.js
Page({
  data: {
    // 用户信息
    userInfo: {
      id: '',
      avatar: '',
      nickname: '',
      phone: '',
      memberLevel: 1, // 会员等级 1-5
      memberExp: 75, // 会员经验值百分比
      points: 1280 // 积分
    },
    
    // 统计数据
    stats: {
      petCount: 0,
      healthRecords: 0,
      reminders: 0,
      communityPosts: 0,
      favorites: 0
    },
    
    // 功能模块列表
    modules: [
      {
        id: 'pets',
        title: '我的宠物',
        icon: '🐾',
        color: '#4CAF50',
        badge: 0,
        path: '/pages/pets/pets'
      },
      {
        id: 'health',
        title: '健康管理',
        icon: '🏥',
        color: '#2196F3',
        badge: 3,
        path: '/pages/health/health'
      },
      {
        id: 'community',
        title: '社区动态',
        icon: '👥',
        color: '#FF9800',
        badge: 12,
        path: '/pages/community/community'
      },
      {
        id: 'favorites',
        title: '我的收藏',
        icon: '⭐',
        color: '#FFC107',
        badge: 0,
        path: '/pages/favorites/favorites'
      },
      {
        id: 'orders',
        title: '我的订单',
        icon: '📦',
        color: '#9C27B0',
        badge: 0,
        path: '/pages/orders/orders'
      },
      {
        id: 'wallet',
        title: '我的钱包',
        icon: '💰',
        color: '#009688',
        badge: 0,
        path: '/pages/wallet/wallet'
      }
    ],
    
    // 设置模块列表
    settings: [
      {
        id: 'profile',
        title: '个人资料',
        icon: '👤',
        path: '/pages/profile/profile'
      },
      {
        id: 'settings',
        title: '设置',
        icon: '⚙️',
        path: '/pages/settings/settings'
      },
      {
        id: 'feedback',
        title: '意见反馈',
        icon: '💬',
        path: '/pages/feedback/feedback'
      },
      {
        id: 'about',
        title: '关于我们',
        icon: 'ℹ️',
        path: '/pages/about/about'
      },
      {
        id: 'help',
        title: '帮助中心',
        icon: '❓',
        path: '/pages/help/help'
      }
    ],
    
    // 快速操作
    quickActions: [
      {
        id: 'addPet',
        title: '添加宠物',
        icon: '➕',
        action: 'navigate'
      },
      {
        id: 'scan',
        title: '扫码绑定',
        icon: '📷',
        action: 'navigate'
      },
      {
        id: 'emergency',
        title: '紧急求助',
        icon: '🆘',
        action: 'function'
      },
      {
        id: 'share',
        title: '邀请好友',
        icon: '📤',
        action: 'share'
      }
    ],
    
    // 公告信息
    announcements: [
      {
        id: 1,
        title: '新功能上线',
        content: '宠物健康管理系统已全面升级',
        time: '2小时前',
        read: false
      },
      {
        id: 2,
        title: '活动通知',
        content: '邀请好友得积分活动火热进行中',
        time: '1天前',
        read: true
      }
    ],
    
    // 页面状态
    loading: false,
    refreshing: false,
    hasNewMessage: true,
    
    // 会员信息
    memberBenefits: [
      '宠物健康咨询免费',
      '专属客服优先响应',
      '商城购物折扣',
      '活动优先参与权'
    ]
  },

  onLoad(options) {
    console.log('mine onLoad');
    this.initPage();
  },

  onShow() {
    // 每次显示页面时刷新数据
    this.refreshUserData();
    
    // 检查登录状态
    this.checkLoginStatus();
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.refreshUserData(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    // 可以加载更多内容
  },

  /**
   * 初始化页面
   */
  initPage() {
    this.loadUserInfo();
    this.loadStats();
    this.checkNotifications();
  },

  /**
   * 刷新用户数据
   */
  async refreshUserData(forceRefresh = false) {
    if (forceRefresh) {
      this.setData({ refreshing: true });
    }
    
    try {
      await Promise.all([
        this.loadUserInfo(forceRefresh),
        this.loadStats(forceRefresh),
        this.checkNotifications(forceRefresh)
      ]);
    } catch (error) {
      console.error('刷新数据失败:', error);
    } finally {
      if (forceRefresh) {
        this.setData({ refreshing: false });
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 检查登录状态
   */
  checkLoginStatus() {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    if (!isLoggedIn) {
      // 未登录，显示登录提示
      wx.showModal({
        title: '未登录',
        content: '请先登录以使用完整功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
    }
  },

  /**
   * 加载用户信息
   */
  async loadUserInfo(forceRefresh = false) {
    try {
      const app = getApp();
      let userInfo = app.globalData.userInfo;
      
      if (!userInfo || forceRefresh) {
        // 从缓存获取
        userInfo = wx.getStorageSync('userInfo') || {};
        
        if (Object.keys(userInfo).length === 0) {
          // 如果没有用户信息，使用默认数据
          userInfo = this.getDefaultUserInfo();
        }
        
        app.globalData.userInfo = userInfo;
      }
      
      // 格式化数据
      const formattedInfo = this.formatUserInfo(userInfo);
      
      this.setData({
        userInfo: formattedInfo
      });
      
    } catch (error) {
      console.error('加载用户信息失败:', error);
      this.setData({
        userInfo: this.getDefaultUserInfo()
      });
    }
  },

  /**
   * 获取默认用户信息
   */
  getDefaultUserInfo() {
    return {
      id: 'USER' + Date.now().toString().slice(-6),
      avatar: '/images/default-avatar.png',
      nickname: '点击登录',
      phone: '未绑定',
      memberLevel: 1,
      memberExp: 0,
      points: 0
    };
  },

  /**
   * 格式化用户信息
   */
  formatUserInfo(userInfo) {
    const app = getApp();
    const isLoggedIn = app.globalData.isLoggedIn;
    
    return {
      id: userInfo.id || '未登录',
      avatar: userInfo.avatar || '/images/default-avatar.png',
      nickname: isLoggedIn ? (userInfo.nickname || '用户') : '点击登录',
      phone: userInfo.phone || '未绑定手机',
      memberLevel: userInfo.memberLevel || 1,
      memberExp: userInfo.memberExp || 0,
      points: userInfo.points || 0
    };
  },

  /**
   * 加载统计数据
   */
  async loadStats(forceRefresh = false) {
    try {
      // 模拟API请求
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // 从缓存获取数据
      const pets = wx.getStorageSync('pets') || [];
      const healthRecords = wx.getStorageSync('healthRecords') || [];
      const reminders = wx.getStorageSync('reminders') || [];
      
      const stats = {
        petCount: pets.length,
        healthRecords: healthRecords.length,
        reminders: reminders.length,
        communityPosts: 12, // 模拟数据
        favorites: 8 // 模拟数据
      };
      
      // 更新模块的徽章数
      const updatedModules = this.data.modules.map(module => {
        if (module.id === 'pets') {
          return { ...module, badge: 0 };
        }
        if (module.id === 'health') {
          return { ...module, badge: reminders.length };
        }
        return module;
      });
      
      this.setData({
        stats: stats,
        modules: updatedModules
      });
      
    } catch (error) {
      console.error('加载统计数据失败:', error);
    }
  },

  /**
   * 检查通知
   */
  checkNotifications(forceRefresh = false) {
    // 模拟检查通知
    const hasNewMessage = Math.random() > 0.5;
    
    this.setData({
      hasNewMessage: hasNewMessage
    });
  },

  /**
   * 点击用户信息区域
   */
  onUserInfoTap() {
    const app = getApp();
    
    if (app.globalData.isLoggedIn) {
      // 已登录，跳转到个人资料页
      wx.navigateTo({
        url: '/pages/profile/profile'
      });
    } else {
      // 未登录，跳转到登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
  },

  /**
   * 点击功能模块
   */
  onModuleTap(e) {
    const { module } = e.currentTarget.dataset;
    
    if (!module || !module.path) return;
    
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn && module.id !== 'about' && module.id !== 'help') {
      wx.showModal({
        title: '请先登录',
        content: '需要登录后才能使用此功能',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          }
        }
      });
      return;
    }
    
    if (module.path.startsWith('/')) {
      if (module.path.includes('/pages/')) {
        wx.navigateTo({
          url: module.path
        });
      } else if (module.path.includes('/tabBar/')) {
        wx.switchTab({
          url: module.path
        });
      }
    }
  },

  /**
   * 点击设置项
   */
  onSettingTap(e) {
    const { item } = e.currentTarget.dataset;
    
    if (!item || !item.path) return;
    
    wx.navigateTo({
      url: item.path
    });
  },

  /**
   * 点击快速操作
   */
  onQuickActionTap(e) {
    const { action } = e.currentTarget.dataset;
    
    switch (action.id) {
      case 'addPet':
        this.navigateToAddPet();
        break;
      case 'scan':
        this.navigateToScan();
        break;
      case 'emergency':
        this.handleEmergency();
        break;
      case 'share':
        this.handleShare();
        break;
    }
  },

  /**
   * 跳转到添加宠物页面
   */
  navigateToAddPet() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/addPet/addPet'
    });
  },

  /**
   * 跳转到扫码页面
   */
  navigateToScan() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/scan/scan'
    });
  },

  /**
   * 处理紧急求助
   */
  handleEmergency() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['拨打宠物医院', '联系紧急联系人', '查看附近医院'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            wx.makePhoneCall({
              phoneNumber: '400-123-4567'
            });
            break;
          case 1:
            this.callEmergencyContact();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/nearby-hospitals/nearby-hospitals'
            });
            break;
        }
      }
    });
  },

  /**
   * 拨打紧急联系人
   */
  callEmergencyContact() {
    // 从缓存获取紧急联系人
    const userInfo = wx.getStorageSync('userInfo') || {};
    const emergencyPhone = userInfo.emergencyPhone;
    
    if (emergencyPhone) {
      wx.makePhoneCall({
        phoneNumber: emergencyPhone
      });
    } else {
      wx.showModal({
        title: '提示',
        content: '请先在个人资料中设置紧急联系人',
        confirmText: '去设置',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/profile/profile'
            });
          }
        }
      });
    }
  },

  /**
   * 处理分享
   */
  handleShare() {
    // 检查登录状态
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.showActionSheet({
      itemList: ['分享给好友', '分享到朋友圈', '生成邀请海报'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            // 分享给好友由button的open-type="share"处理
            break;
          case 1:
            this.shareToTimeline();
            break;
          case 2:
            wx.navigateTo({
              url: '/pages/invite-poster/invite-poster'
            });
            break;
        }
      }
    });
  },

  /**
   * 显示登录弹窗
   */
  showLoginModal() {
    wx.showModal({
      title: '请先登录',
      content: '需要登录后才能使用此功能',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login'
          });
        }
      }
    });
  },

  /**
   * 分享到朋友圈
   */
  onShareTimeline() {
    const { userInfo } = this.data;
    
    return {
      title: `${userInfo.nickname}邀请您一起加入宠物管家`,
      query: `from=${userInfo.id}`,
      imageUrl: '/images/share-poster.jpg'
    };
  },

  /**
   * 分享给好友
   */
  onShareAppMessage() {
    const { userInfo } = this.data;
    
    return {
      title: '发现一个好用的宠物管理小程序',
      path: `/pages/index/index?from=${userInfo.id}`,
      imageUrl: '/images/share-default.jpg'
    };
  },

  /**
   * 点击公告
   */
  onAnnouncementTap(e) {
    const { announcement } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/announcement-detail/announcement-detail?id=${announcement.id}`
    });
  },

  /**
   * 点击会员卡
   */
  onMemberCardTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/member/member'
    });
  },

  /**
   * 点击积分
   */
  onPointsTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/points/points'
    });
  },

  /**
   * 点击统计数据
   */
  onStatsTap(e) {
    const { stat } = e.currentTarget.dataset;
    
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    switch (stat.type) {
      case 'pets':
        wx.switchTab({
          url: '/pages/pets/pets'
        });
        break;
      case 'health':
        wx.navigateTo({
          url: '/pages/health/health'
        });
        break;
      case 'community':
        wx.switchTab({
          url: '/pages/community/community'
        });
        break;
    }
  },

  /**
   * 点击消息通知
   */
  onMessageTap() {
    const app = getApp();
    
    if (!app.globalData.isLoggedIn) {
      this.showLoginModal();
      return;
    }
    
    wx.navigateTo({
      url: '/pages/messages/messages'
    });
  }
});