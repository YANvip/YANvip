// pages/edit-profile/edit-profile.js
const app = getApp()

Page({
  data: {
    // 用户信息
    userInfo: null,
    originalUserInfo: null,
    
    // 表单数据
    formData: {
      avatar: '',
      nickname: '',
      gender: 0, // 0-未知 1-男 2-女
      birthday: '',
      phone: '',
      email: '',
      bio: '',
      address: {
        province: '',
        city: '',
        district: '',
        detail: ''
      },
      emergencyContact: {
        name: '',
        relationship: '',
        phone: ''
      }
    },
    
    // 性别选项
    genderOptions: [
      { value: 0, label: '未知', icon: '❓' },
      { value: 1, label: '男', icon: '♂️' },
      { value: 2, label: '女', icon: '♀️' }
    ],
    
    // 关系选项
    relationshipOptions: [
      '家人', '朋友', '同事', '邻居', '其他'
    ],
    
    // 表单验证
    validation: {
      nickname: { valid: true, message: '' },
      phone: { valid: true, message: '' },
      email: { valid: true, message: '' }
    },
    
    // 界面状态
    isLoading: true,
    isSaving: false,
    showDatePicker: false,
    showGenderPicker: false,
    showRelationshipPicker: false,
    showRegionPicker: false,
    showAvatarEdit: false,
    showLogoutConfirm: false,
    showResetConfirm: false,
    showSuccessToast: false,
    
    // 日期范围
    dateRange: {
      start: '1900-01-01',
      end: new Date().toISOString().split('T')[0]
    },
    
    // 原始头像（用于恢复）
    originalAvatar: '',
    
    // 安全区域
    safeAreaBottom: 0,
    
    // 是否已修改
    hasChanges: false,
    
    // 临时数据
    tempData: {},
    
    // 头像上传状态
    avatarUploading: false,
    
    // 输入聚焦状态
    focusedField: null
  },

  onLoad() {
    // 检查登录状态
    if (!app.globalData.userInfo) {
      this.redirectToLogin()
      return
    }
    
    // 获取安全区域
    this.getSafeArea()
    
    // 加载用户信息
    this.loadUserInfo()
    
    // 监听页面返回事件
    this.preventBackIfChanged()
  },

  onShow() {
    // 检查登录状态
    if (!app.globalData.userInfo) {
      wx.navigateBack()
      return
    }
    
    // 更新用户信息
    if (app.globalData.userInfo && !this.data.isLoading) {
      this.loadUserInfo()
    }
  },

  onHide() {
    // 检查是否有未保存的更改
    this.checkUnsavedChanges()
  },

  onUnload() {
    // 清理事件监听
    this.removeBackListener()
  },

  onPageScroll(e) {
    // 可以在这里处理滚动相关逻辑
  },

  getSafeArea() {
    const systemInfo = wx.getSystemInfoSync()
    this.setData({
      safeAreaBottom: systemInfo.screenHeight - systemInfo.safeArea.bottom
    })
  },

  redirectToLogin() {
    wx.showModal({
      title: '提示',
      content: '需要登录后才能编辑资料',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login?redirect=/pages/edit-profile/edit-profile'
          })
        } else {
          wx.navigateBack()
        }
      }
    })
  },

  async loadUserInfo() {
    this.setData({ isLoading: true })
    
    try {
      // 从全局数据获取用户信息
      const userInfo = app.globalData.userInfo
      
      if (!userInfo) {
        throw new Error('用户信息不存在')
      }
      
      // 复制原始数据
      const originalUserInfo = JSON.parse(JSON.stringify(userInfo))
      
      // 格式化表单数据
      const formData = {
        avatar: userInfo.avatar || '',
        nickname: userInfo.nickname || '',
        gender: userInfo.gender || 0,
        birthday: userInfo.birthday || '',
        phone: userInfo.phone || '',
        email: userInfo.email || '',
        bio: userInfo.bio || '',
        address: userInfo.address || {
          province: '',
          city: '',
          district: '',
          detail: ''
        },
        emergencyContact: userInfo.emergencyContact || {
          name: '',
          relationship: '',
          phone: ''
        }
      }
      
      this.setData({
        userInfo: userInfo,
        originalUserInfo: originalUserInfo,
        formData: formData,
        originalAvatar: userInfo.avatar || '',
        isLoading: false
      })
      
    } catch (error) {
      console.error('加载用户信息失败:', error)
      this.setData({ isLoading: false })
      wx.showToast({
        title: '加载失败',
        icon: 'error'
      })
    }
  },

  // 表单输入处理
  onInputChange(e) {
    const { field } = e.currentTarget.dataset
    let { value } = e.detail
    
    // 根据字段类型进行特殊处理
    switch (field) {
      case 'nickname':
        value = value.trim()
        this.validateNickname(value)
        break
      case 'phone':
        this.validatePhone(value)
        break
      case 'email':
        if (value) {
          this.validateEmail(value)
        }
        break
      case 'bio':
        if (value.length > 200) {
          value = value.substring(0, 200)
          wx.showToast({
            title: '最多200字',
            icon: 'none'
          })
        }
        break
    }
    
    this.setData({
      [`formData.${field}`]: value,
      hasChanges: true
    })
  },

  // 地址详细输入
  onAddressDetailInput(e) {
    const { value } = e.detail
    this.setData({
      'formData.address.detail': value,
      hasChanges: true
    })
  },

  // 紧急联系人输入
  onEmergencyContactInput(e) {
    const { field } = e.currentTarget.dataset
    const { value } = e.detail
    
    this.setData({
      [`formData.emergencyContact.${field}`]: value,
      hasChanges: true
    })
  },

  // 验证昵称
  validateNickname(nickname) {
    const validation = { valid: true, message: '' }
    
    if (!nickname.trim()) {
      validation.valid = false
      validation.message = '昵称不能为空'
    } else if (nickname.length < 2) {
      validation.valid = false
      validation.message = '昵称至少2个字符'
    } else if (nickname.length > 20) {
      validation.valid = false
      validation.message = '昵称最多20个字符'
    }
    
    this.setData({
      'validation.nickname': validation
    })
    
    return validation.valid
  },

  // 验证手机号
  validatePhone(phone) {
    const validation = { valid: true, message: '' }
    
    if (phone && !/^1[3-9]\d{9}$/.test(phone)) {
      validation.valid = false
      validation.message = '请输入有效的手机号'
    }
    
    this.setData({
      'validation.phone': validation
    })
    
    return validation.valid
  },

  // 验证邮箱
  validateEmail(email) {
    const validation = { valid: true, message: '' }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      validation.valid = false
      validation.message = '请输入有效的邮箱地址'
    }
    
    this.setData({
      'validation.email': validation
    })
    
    return validation.valid
  },

  // 选择性别
  showGenderPicker() {
    this.setData({
      showGenderPicker: true,
      tempData: {
        selectedGender: this.data.formData.gender
      }
    })
  },

  onGenderChange(e) {
    const { value } = e.detail
    this.setData({
      'tempData.selectedGender': value
    })
  },

  confirmGender() {
    const gender = this.data.tempData.selectedGender
    
    if (gender !== this.data.formData.gender) {
      this.setData({
        'formData.gender': gender,
        hasChanges: true
      })
    }
    
    this.setData({
      showGenderPicker: false,
      tempData: {}
    })
  },

  // 选择生日
  showDatePicker() {
    this.setData({
      showDatePicker: true,
      tempData: {
        selectedDate: this.data.formData.birthday || new Date().toISOString().split('T')[0]
      }
    })
  },

  onDateChange(e) {
    const { value } = e.detail
    this.setData({
      'tempData.selectedDate': value
    })
  },

  confirmDate() {
    const birthday = this.data.tempData.selectedDate
    
    if (birthday !== this.data.formData.birthday) {
      this.setData({
        'formData.birthday': birthday,
        hasChanges: true
      })
    }
    
    this.setData({
      showDatePicker: false,
      tempData: {}
    })
  },

  // 选择地区
  showRegionPicker() {
    this.setData({
      showRegionPicker: true,
      tempData: {
        selectedRegion: this.data.formData.address
      }
    })
  },

  onRegionChange(e) {
    const region = e.detail.region
    this.setData({
      'tempData.selectedRegion': region
    })
  },

  confirmRegion() {
    const region = this.data.tempData.selectedRegion
    const currentAddress = this.data.formData.address
    
    if (JSON.stringify(region) !== JSON.stringify(currentAddress)) {
      this.setData({
        'formData.address': region,
        hasChanges: true
      })
    }
    
    this.setData({
      showRegionPicker: false,
      tempData: {}
    })
  },

  // 选择关系
  showRelationshipPicker() {
    this.setData({
      showRelationshipPicker: true,
      tempData: {
        selectedRelationship: this.data.formData.emergencyContact.relationship || ''
      }
    })
  },

  selectRelationship(e) {
    const { relationship } = e.currentTarget.dataset
    
    this.setData({
      'formData.emergencyContact.relationship': relationship,
      showRelationshipPicker: false,
      hasChanges: true,
      tempData: {}
    })
  },

  // 头像编辑
  showAvatarEdit() {
    this.setData({
      showAvatarEdit: true,
      tempData: {
        selectedAvatar: this.data.formData.avatar
      }
    })
  },

  onAvatarSelect(e) {
    const { avatar } = e.detail
    this.setData({
      'tempData.selectedAvatar': avatar
    })
  },

  confirmAvatar() {
    const avatar = this.data.tempData.selectedAvatar
    
    if (avatar !== this.data.formData.avatar) {
      this.setData({
        'formData.avatar': avatar,
        hasChanges: true,
        avatarUploading: true
      })
      
      // 上传头像到服务器
      this.uploadAvatar(avatar)
    }
    
    this.setData({
      showAvatarEdit: false,
      tempData: {}
    })
  },

  // 上传头像
  async uploadAvatar(avatarUrl) {
    // 如果是网络图片，不需要上传
    if (avatarUrl.startsWith('http')) {
      this.setData({ avatarUploading: false })
      return avatarUrl
    }
    
    try {
      const response = await app.request({
        url: '/api/upload',
        method: 'POST',
        data: {
          type: 'avatar',
          base64: avatarUrl
        }
      })
      
      if (response.code === 0) {
        this.setData({
          'formData.avatar': response.data.url,
          avatarUploading: false
        })
        return response.data.url
      } else {
        throw new Error(response.msg)
      }
    } catch (error) {
      console.error('上传头像失败:', error)
      this.setData({ avatarUploading: false })
      wx.showToast({
        title: '头像上传失败',
        icon: 'error'
      })
      return avatarUrl
    }
  },

  // 使用微信头像
  useWeChatAvatar() {
    const userInfo = app.globalData.userInfo
    if (userInfo && userInfo.wxAvatar) {
      this.setData({
        'formData.avatar': userInfo.wxAvatar,
        hasChanges: true
      })
    }
  },

  // 使用微信昵称
  useWeChatNickname() {
    const userInfo = app.globalData.userInfo
    if (userInfo && userInfo.wxNickname) {
      this.setData({
        'formData.nickname': userInfo.wxNickname,
        hasChanges: true
      })
      this.validateNickname(userInfo.wxNickname)
    }
  },

  // 重置表单
  showResetConfirm() {
    this.setData({ showResetConfirm: true })
  },

  resetForm() {
    if (this.data.originalUserInfo) {
      const formData = {
        avatar: this.data.originalUserInfo.avatar || '',
        nickname: this.data.originalUserInfo.nickname || '',
        gender: this.data.originalUserInfo.gender || 0,
        birthday: this.data.originalUserInfo.birthday || '',
        phone: this.data.originalUserInfo.phone || '',
        email: this.data.originalUserInfo.email || '',
        bio: this.data.originalUserInfo.bio || '',
        address: this.data.originalUserInfo.address || {
          province: '',
          city: '',
          district: '',
          detail: ''
        },
        emergencyContact: this.data.originalUserInfo.emergencyContact || {
          name: '',
          relationship: '',
          phone: ''
        }
      }
      
      this.setData({
        formData: formData,
        hasChanges: false,
        validation: {
          nickname: { valid: true, message: '' },
          phone: { valid: true, message: '' },
          email: { valid: true, message: '' }
        }
      })
      
      wx.showToast({
        title: '已重置',
        icon: 'success'
      })
    }
    
    this.setData({ showResetConfirm: false })
  },

  // 验证表单
  validateForm() {
    const { formData } = this.data
    
    // 验证昵称
    if (!this.validateNickname(formData.nickname)) {
      wx.showToast({
        title: this.data.validation.nickname.message,
        icon: 'none'
      })
      return false
    }
    
    // 验证手机号
    if (formData.phone && !this.validatePhone(formData.phone)) {
      wx.showToast({
        title: this.data.validation.phone.message,
        icon: 'none'
      })
      return false
    }
    
    // 验证邮箱
    if (formData.email && !this.validateEmail(formData.email)) {
      wx.showToast({
        title: this.data.validation.email.message,
        icon: 'none'
      })
      return false
    }
    
    // 验证紧急联系人电话
    if (formData.emergencyContact.phone && !/^1[3-9]\d{9}$/.test(formData.emergencyContact.phone)) {
      wx.showToast({
        title: '紧急联系人电话格式错误',
        icon: 'none'
      })
      return false
    }
    
    return true
  },

  // 保存资料
  async saveProfile() {
    if (this.data.isSaving) return
    
    // 表单验证
    if (!this.validateForm()) {
      return
    }
    
    this.setData({ isSaving: true })
    wx.showLoading({ title: '保存中...', mask: true })
    
    try {
      // 准备提交数据
      const submitData = {
        ...this.data.formData
      }
      
      // 如果头像修改了且是本地图片，先上传
      if (submitData.avatar && !submitData.avatar.startsWith('http')) {
        const uploadedAvatar = await this.uploadAvatar(submitData.avatar)
        submitData.avatar = uploadedAvatar
      }
      
      // 调用API更新用户信息
      const response = await app.request({
        url: '/api/user/profile',
        method: 'PUT',
        data: submitData
      })
      
      if (response.code === 0) {
        // 更新全局用户信息
        const updatedUserInfo = {
          ...app.globalData.userInfo,
          ...submitData
        }
        app.globalData.userInfo = updatedUserInfo
        wx.setStorageSync('userInfo', updatedUserInfo)
        
        // 更新本地数据
        this.setData({
          userInfo: updatedUserInfo,
          originalUserInfo: JSON.parse(JSON.stringify(updatedUserInfo)),
          hasChanges: false,
          isSaving: false
        })
        
        wx.hideLoading()
        
        // 显示成功提示
        this.setData({ showSuccessToast: true })
        setTimeout(() => {
          this.setData({ showSuccessToast: false })
        }, 2000)
        
        // 通知其他页面更新
        app.eventBus.emit('userProfileUpdated', updatedUserInfo)
        
      } else {
        throw new Error(response.msg)
      }
      
    } catch (error) {
      console.error('保存资料失败:', error)
      wx.hideLoading()
      this.setData({ isSaving: false })
      wx.showToast({
        title: error.message || '保存失败',
        icon: 'error'
      })
    }
  },

  // 注销账户
  showLogoutConfirm() {
    this.setData({ showLogoutConfirm: true })
  },

  async logoutAccount() {
    try {
      wx.showLoading({ title: '注销中...', mask: true })
      
      const response = await app.request({
        url: '/api/user/account',
        method: 'DELETE'
      })
      
      if (response.code === 0) {
        // 清除本地数据
        wx.removeStorageSync('token')
        wx.removeStorageSync('userInfo')
        app.globalData.token = null
        app.globalData.userInfo = null
        
        // 跳转到登录页
        wx.reLaunch({
          url: '/pages/login/login'
        })
      } else {
        throw new Error(response.msg)
      }
    } catch (error) {
      console.error('注销账户失败:', error)
      wx.showToast({
        title: error.message || '注销失败',
        icon: 'error'
      })
    } finally {
      this.setData({ showLogoutConfirm: false })
    }
  },

  // 检查未保存的更改
  checkUnsavedChanges() {
    if (this.data.hasChanges) {
      wx.showModal({
        title: '提示',
        content: '您有未保存的更改，是否保存？',
        confirmText: '保存',
        cancelText: '不保存',
        success: (res) => {
          if (res.confirm) {
            this.saveProfile()
          }
        }
      })
    }
  },

  // 阻止返回如果数据已修改
  preventBackIfChanged() {
    wx.onAppHide(() => {
      this.checkUnsavedChanges()
    })
    
    // 监听返回按钮
    if (wx.onBackPress) {
      wx.onBackPress(() => {
        if (this.data.hasChanges) {
          this.checkUnsavedChanges()
          return true // 阻止默认返回
        }
        return false
      })
    }
  },

  removeBackListener() {
    // 移除事件监听
    wx.offAppHide()
  },

  // 返回上一页
  goBack() {
    if (this.data.hasChanges) {
      wx.showModal({
        title: '提示',
        content: '您有未保存的更改，是否保存？',
        confirmText: '保存',
        cancelText: '不保存',
        success: (res) => {
          if (res.confirm) {
            this.saveProfile()
          } else {
            wx.navigateBack()
          }
        }
      })
    } else {
      wx.navigateBack()
    }
  },

  // 格式化地址显示
  formatAddress(address) {
    if (!address) return '请选择地区'
    
    const { province, city, district, detail } = address
    let result = ''
    
    if (province) result += province
    if (city && city !== province) result += city
    if (district) result += district
    if (detail) result += detail
    
    return result || '请选择地区'
  },

  // 获取性别显示文本
  getGenderText(gender) {
    const option = this.data.genderOptions.find(opt => opt.value === gender)
    return option ? option.label : '未知'
  },

  // 输入框聚焦
  onInputFocus(e) {
    const { field } = e.currentTarget.dataset
    this.setData({ focusedField: field })
  },

  // 输入框失焦
  onInputBlur() {
    this.setData({ focusedField: null })
  },

  // 清除输入
  clearInput(e) {
    const { field } = e.currentTarget.dataset
    this.setData({
      [`formData.${field}`]: '',
      hasChanges: true
    })
    
    // 如果是验证字段，清除验证信息
    if (['nickname', 'phone', 'email'].includes(field)) {
      this.setData({
        [`validation.${field}`]: { valid: true, message: '' }
      })
    }
  },

  // 查看隐私政策
  viewPrivacyPolicy() {
    wx.navigateTo({
      url: '/pages/webview/webview?url=' + encodeURIComponent('https://example.com/privacy')
    })
  },

  // 查看用户协议
  viewUserAgreement() {
    wx.navigateTo({
      url: '/pages/webview/webview?url=' + encodeURIComponent('https://example.com/agreement')
    })
  }
})