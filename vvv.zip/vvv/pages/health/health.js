// pages/health/health.js
Page({
  data: {
    // 筛选条件
    filters: {
      petId: 'all', // 全部宠物
      type: 'all', // 全部类型
      status: 'all', // 全部状态
      timeRange: 'all' // 全部时间
    },
    
    // 筛选选项
    filterOptions: {
      pets: [
        { id: 'all', name: '全部宠物' },
        { id: '1', name: '豆豆（柯基）' },
        { id: '2', name: '咪咪（英短）' }
      ],
      types: [
        { id: 'all', name: '全部类型' },
        { id: 'vaccination', name: '疫苗接种', color: '#4CAF50', icon: '💉' },
        { id: 'deworming', name: '驱虫记录', color: '#FF9800', icon: '🦠' },
        { id: 'medical', name: '医疗记录', color: '#2196F3', icon: '🏥' },
        { id: 'daily', name: '日常护理', color: '#9C27B0', icon: '✨' },
        { id: 'examination', name: '体检记录', color: '#009688', icon: '📋' }
      ],
      statuses: [
        { id: 'all', name: '全部状态' },
        { id: 'upcoming', name: '待完成', color: '#FF9800' },
        { id: 'completed', name: '已完成', color: '#4CAF50' },
        { id: 'overdue', name: '已过期', color: '#f44336' }
      ],
      timeRanges: [
        { id: 'all', name: '全部时间' },
        { id: 'today', name: '今天' },
        { id: 'week', name: '本周' },
        { id: 'month', name: '本月' },
        { id: 'year', name: '今年' }
      ]
    },
    
    // 健康记录列表
    healthRecords: [],
    // 筛选后的记录
    filteredRecords: [],
    
    // 统计数据
    stats: {
      total: 0,
      upcoming: 0,
      completed: 0,
      overdue: 0
    },
    
    // 页面状态
    loading: true,
    refreshing: false,
    hasMore: true,
    page: 1,
    pageSize: 10,
    
    // 当前展开的筛选面板
    activeFilterPanel: null,
    
    // 快速添加选项
    quickAddOptions: [
      {
        id: 'vaccination',
        title: '添加疫苗记录',
        icon: '💉',
        color: '#4CAF50',
        desc: '记录疫苗接种信息'
      },
      {
        id: 'deworming',
        title: '添加驱虫记录',
        icon: '🦠',
        color: '#FF9800',
        desc: '记录驱虫情况'
      },
      {
        id: 'medical',
        title: '添加医疗记录',
        icon: '🏥',
        color: '#2196F3',
        desc: '记录就诊情况'
      },
      {
        id: 'general',
        title: '添加一般记录',
        icon: '📝',
        color: '#9C27B0',
        desc: '其他健康记录'
      }
    ],
    
    // 是否显示空状态
    showEmpty: false
  },

  onLoad(options) {
    console.log('health onLoad', options);
    this.initPage();
  },

  onShow() {
    // 刷新数据
    this.loadHealthRecords(true);
  },

  onPullDownRefresh() {
    console.log('下拉刷新');
    this.loadHealthRecords(true);
  },

  onReachBottom() {
    console.log('上拉加载更多');
    if (this.data.hasMore && !this.data.loading) {
      this.loadMoreRecords();
    }
  },

  /**
   * 初始化页面
   */
  initPage() {
    // 加载宠物列表
    this.loadPets();
    
    // 加载健康记录
    this.loadHealthRecords();
  },

  /**
   * 加载宠物列表
   */
  loadPets() {
    try {
      const pets = wx.getStorageSync('pets') || [];
      const petOptions = [
        { id: 'all', name: '全部宠物' }
      ];
      
      pets.forEach(pet => {
        petOptions.push({
          id: pet.id,
          name: `${pet.name}（${pet.breed}）`
        });
      });
      
      this.setData({
        'filterOptions.pets': petOptions
      });
      
    } catch (error) {
      console.error('加载宠物列表失败:', error);
    }
  },

  /**
   * 加载健康记录
   */
  async loadHealthRecords(refresh = false) {
    if (refresh) {
      this.setData({ refreshing: true, page: 1, hasMore: true });
    } else {
      this.setData({ loading: true });
    }
    
    try {
      // 模拟API请求延迟
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // 从缓存获取健康记录
      let allRecords = wx.getStorageSync('healthRecords') || [];
      
      // 如果是刷新，重置页码
      const currentPage = refresh ? 1 : this.data.page;
      const pageSize = this.data.pageSize;
      
      // 应用筛选条件
      const filtered = this.applyFilters(allRecords);
      
      // 分页处理
      const startIndex = (currentPage - 1) * pageSize;
      const pageRecords = filtered.slice(startIndex, startIndex + pageSize);
      
      // 更新数据
      const newRecords = refresh ? pageRecords : [...this.data.healthRecords, ...pageRecords];
      
      // 更新统计数据
      this.updateStats(allRecords);
      
      this.setData({
        healthRecords: newRecords,
        filteredRecords: filtered,
        loading: false,
        refreshing: false,
        showEmpty: newRecords.length === 0,
        hasMore: startIndex + pageSize < filtered.length,
        page: currentPage
      });
      
      if (refresh) {
        wx.stopPullDownRefresh();
      }
      
    } catch (error) {
      console.error('加载健康记录失败:', error);
      this.setData({
        loading: false,
        refreshing: false,
        showEmpty: true
      });
      
      if (refresh) {
        wx.stopPullDownRefresh();
      }
    }
  },

  /**
   * 加载更多记录
   */
  loadMoreRecords() {
    const nextPage = this.data.page + 1;
    this.setData({ page: nextPage }, () => {
      this.loadHealthRecords();
    });
  },

  /**
   * 应用筛选条件
   */
  applyFilters(records) {
    const { petId, type, status, timeRange } = this.data.filters;
    
    let filtered = [...records];
    
    // 按宠物筛选
    if (petId !== 'all') {
      filtered = filtered.filter(record => record.petId === petId);
    }
    
    // 按类型筛选
    if (type !== 'all') {
      filtered = filtered.filter(record => record.type === type);
    }
    
    // 按状态筛选
    if (status !== 'all') {
      filtered = filtered.filter(record => {
        const now = new Date();
        const recordDate = new Date(record.date);
        const nextDate = record.nextDate ? new Date(record.nextDate) : null;
        
        switch (status) {
          case 'upcoming':
            return !record.completed && nextDate && nextDate > now;
          case 'completed':
            return record.completed;
          case 'overdue':
            return !record.completed && nextDate && nextDate < now;
          default:
            return true;
        }
      });
    }
    
    // 按时间范围筛选
    if (timeRange !== 'all') {
      const now = new Date();
      let startDate;
      
      switch (timeRange) {
        case 'today':
          startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate());
          break;
        case 'week':
          startDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 7);
          break;
        case 'month':
          startDate = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
          break;
        case 'year':
          startDate = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
          break;
      }
      
      filtered = filtered.filter(record => {
        const recordDate = new Date(record.date);
        return recordDate >= startDate;
      });
    }
    
    // 按时间倒序排序
    filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    return filtered;
  },

  /**
   * 更新统计数据
   */
  updateStats(records) {
    const now = new Date();
    
    const stats = {
      total: records.length,
      upcoming: 0,
      completed: 0,
      overdue: 0
    };
    
    records.forEach(record => {
      if (record.completed) {
        stats.completed++;
      } else {
        const nextDate = record.nextDate ? new Date(record.nextDate) : null;
        if (nextDate) {
          if (nextDate > now) {
            stats.upcoming++;
          } else {
            stats.overdue++;
          }
        }
      }
    });
    
    this.setData({ stats });
  },

  /**
   * 切换筛选面板
   */
  toggleFilterPanel(e) {
    const { panel } = e.currentTarget.dataset;
    const currentPanel = this.data.activeFilterPanel;
    
    this.setData({
      activeFilterPanel: currentPanel === panel ? null : panel
    });
  },

  /**
   * 选择筛选条件
   */
  selectFilter(e) {
    const { type, value } = e.currentTarget.dataset;
    
    this.setData({
      [`filters.${type}`]: value,
      activeFilterPanel: null
    }, () => {
      // 重新加载数据
      this.loadHealthRecords(true);
    });
  },

  /**
   * 清除所有筛选条件
   */
  clearAllFilters() {
    this.setData({
      filters: {
        petId: 'all',
        type: 'all',
        status: 'all',
        timeRange: 'all'
      },
      activeFilterPanel: null
    }, () => {
      this.loadHealthRecords(true);
    });
  },

  /**
   * 获取当前筛选条件的显示文本
   */
  getFilterDisplayText() {
    const { filters, filterOptions } = this.data;
    let text = '';
    
    if (filters.petId !== 'all') {
      const pet = filterOptions.pets.find(p => p.id === filters.petId);
      text += pet ? pet.name + ' ' : '';
    }
    
    if (filters.type !== 'all') {
      const type = filterOptions.types.find(t => t.id === filters.type);
      text += type ? type.name + ' ' : '';
    }
    
    if (filters.status !== 'all') {
      const status = filterOptions.statuses.find(s => s.id === filters.status);
      text += status ? status.name + ' ' : '';
    }
    
    return text || '全部记录';
  },

  /**
   * 点击健康记录
   */
  onRecordTap(e) {
    const { record } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/health-detail/health-detail?id=${record.id}`
    });
  },

  /**
   * 快速添加健康记录
   */
  onQuickAddTap(e) {
    const { option } = e.currentTarget.dataset;
    
    wx.navigateTo({
      url: `/pages/health-add/health-add?type=${option.id}`
    });
  },

  /**
   * 添加新的健康记录
   */
  onAddRecordTap() {
    wx.navigateTo({
      url: '/pages/health-add/health-add'
    });
  },

  /**
   * 切换记录完成状态
   */
  toggleRecordStatus(e) {
    const { record } = e.currentTarget.dataset;
    e.stopPropagation();
    
    wx.showModal({
      title: '确认操作',
      content: `确认将这条记录标记为${record.completed ? '未完成' : '已完成'}吗？`,
      success: (res) => {
        if (res.confirm) {
          this.updateRecordStatus(record.id, !record.completed);
        }
      }
    });
  },

  /**
   * 更新记录状态
   */
  async updateRecordStatus(recordId, completed) {
    try {
      // 获取所有记录
      let allRecords = wx.getStorageSync('healthRecords') || [];
      
      // 更新记录
      const updatedRecords = allRecords.map(record => {
        if (record.id === recordId) {
          return { ...record, completed };
        }
        return record;
      });
      
      // 保存到缓存
      wx.setStorageSync('healthRecords', updatedRecords);
      
      // 更新UI
      this.loadHealthRecords(true);
      
      wx.showToast({
        title: completed ? '标记为已完成' : '标记为未完成',
        icon: 'success'
      });
      
    } catch (error) {
      console.error('更新记录状态失败:', error);
      wx.showToast({
        title: '操作失败',
        icon: 'error'
      });
    }
  },

  /**
   * 删除健康记录
   */
  deleteRecord(e) {
    const { record } = e.currentTarget.dataset;
    e.stopPropagation();
    
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这条健康记录吗？删除后无法恢复。',
      confirmColor: '#f44336',
      success: (res) => {
        if (res.confirm) {
          this.performDeleteRecord(record.id);
        }
      }
    });
  },

  /**
   * 执行删除记录
   */
  async performDeleteRecord(recordId) {
    try {
      // 获取所有记录
      let allRecords = wx.getStorageSync('healthRecords') || [];
      
      // 过滤掉要删除的记录
      const updatedRecords = allRecords.filter(record => record.id !== recordId);
      
      // 保存到缓存
      wx.setStorageSync('healthRecords', updatedRecords);
      
      // 更新UI
      this.loadHealthRecords(true);
      
      wx.showToast({
        title: '删除成功',
        icon: 'success'
      });
      
    } catch (error) {
      console.error('删除记录失败:', error);
      wx.showToast({
        title: '删除失败',
        icon: 'error'
      });
    }
  },

  /**
   * 设置提醒
   */
  setReminder(e) {
    const { record } = e.currentTarget.dataset;
    e.stopPropagation();
    
    if (!record.nextDate) {
      wx.showToast({
        title: '该记录没有设置下次日期',
        icon: 'none'
      });
      return;
    }
    
    wx.showActionSheet({
      itemList: ['添加到日历提醒', '设置微信提醒', '取消提醒'],
      success: (res) => {
        const index = res.tapIndex;
        switch (index) {
          case 0:
            this.addToCalendar(record);
            break;
          case 1:
            this.setWechatReminder(record);
            break;
          case 2:
            this.cancelReminder(record.id);
            break;
        }
      }
    });
  },

  /**
   * 添加到日历
   */
  addToCalendar(record) {
    const nextDate = new Date(record.nextDate);
    
    wx.addPhoneCalendar({
      title: `${record.petName} - ${record.title}`,
      startDate: nextDate,
      endDate: nextDate,
      description: record.description || '宠物健康提醒',
      success: () => {
        wx.showToast({
          title: '已添加到日历',
          icon: 'success'
        });
      },
      fail: (err) => {
        console.error('添加到日历失败:', err);
        wx.showToast({
          title: '添加失败',
          icon: 'error'
        });
      }
    });
  },

  /**
   * 设置微信提醒（模拟）
   */
  setWechatReminder(record) {
    wx.showToast({
      title: '提醒设置成功',
      icon: 'success'
    });
  },

  /**
   * 取消提醒
   */
  cancelReminder(recordId) {
    wx.showToast({
      title: '已取消提醒',
      icon: 'success'
    });
  },

  /**
   * 搜索健康记录
   */
  onSearchTap() {
    wx.navigateTo({
      url: '/pages/health-search/health-search'
    });
  },

  /**
   * 查看统计数据
   */
  viewStatistics() {
    wx.navigateTo({
      url: '/pages/health-statistics/health-statistics'
    });
  },

  /**
   * 导入健康记录
   */
  importRecords() {
    wx.showModal({
      title: '导入健康记录',
      content: '支持从相册导入宠物医疗单据照片，自动识别记录信息。',
      confirmText: '去导入',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/health-import/health-import'
          });
        }
      }
    });
  },

  /**
   * 导出健康记录
   */
  exportRecords() {
    wx.showActionSheet({
      itemList: ['导出为PDF', '导出为Excel', '分享给医生'],
      success: (res) => {
        const index = res.tapIndex;
        wx.showToast({
          title: ['PDF生成中...', 'Excel导出中...', '准备分享...'][index],
          icon: 'loading'
        });
        
        // 模拟导出过程
        setTimeout(() => {
          wx.showToast({
            title: ['导出成功', '导出成功', '分享成功'][index],
            icon: 'success'
          });
        }, 1500);
      }
    });
  }
});
// pages/health/health.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 页面状态
    loading: false,
    refreshing: false,
    show_empty: false,
    has_more: false,
    active_filter_panel: null,
    
    // 快速添加选项
    quick_add_options: [
      { id: 1, title: '疫苗接种', desc: '添加疫苗记录', icon: '💉', color: '#4CAF50' },
      { id: 2, title: '驱虫记录', desc: '添加驱虫记录', icon: '🦠', color: '#2196F3' },
      { id: 3, title: '体检记录', desc: '添加体检记录', icon: '🏥', color: '#FF9800' },
      { id: 4, title: '用药记录', desc: '添加用药记录', icon: '💊', color: '#9C27B0' },
      { id: 5, title: '就诊记录', desc: '添加就诊记录', icon: '👨‍⚕️', color: '#F44336' }
    ],
    
    // 筛选选项
    filter_options: {
      pets: [],
      types: [
        { id: 'vaccination', name: '疫苗接种', icon: '💉', color: '#4CAF50' },
        { id: 'deworming', name: '驱虫', icon: '🦠', color: '#2196F3' },
        { id: 'examination', name: '体检', icon: '🏥', color: '#FF9800' },
        { id: 'medical', name: '就诊', icon: '👨‍⚕️', color: '#F44336' },
        { id: 'medication', name: '用药', icon: '💊', color: '#9C27B0' }
      ],
      statuses: [
        { id: 'all', name: '全部', color: '#6c757d' },
        { id: 'completed', name: '已完成', color: '#4CAF50' },
        { id: 'pending', name: '待完成', color: '#FF9800' },
        { id: 'overdue', name: '已过期', color: '#F44336' }
      ],
      time_ranges: [
        { id: 'all', name: '全部时间' },
        { id: 'week', name: '最近一周' },
        { id: 'month', name: '最近一月' },
        { id: 'quarter', name: '最近三月' },
        { id: 'year', name: '最近一年' }
      ]
    },
    
    // 当前筛选条件
    filters: {
      pet_id: 'all',
      type: 'all',
      status: 'all',
      time_range: 'all'
    },
    
    // 统计数据
    stats: {
      total: 0,
      upcoming: 0,
      completed: 0,
      overdue: 0
    },
    
    // 健康记录列表
    health_records: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.loadPets();
    this.loadHealthRecords();
  },

  /**
   * 加载宠物列表
   */
  loadPets: function() {
    const app = getApp();
    const pets = app.globalData.pets || [];
    
    // 添加"全部"选项
    const petOptions = [
      { id: 'all', name: '全部宠物' },
      ...pets.map(pet => ({
        id: pet.id,
        name: pet.name
      }))
    ];
    
    this.setData({
      'filter_options.pets': petOptions
    });
  },

  /**
   * 加载健康记录
   */
  loadHealthRecords: function() {
    this.setData({ loading: true });
    
    // 这里应该是从后端API获取数据
    // 模拟数据
    const mockRecords = [
      {
        id: 1,
        title: '狂犬疫苗接种',
        type: 'vaccination',
        pet_name: '旺财',
        date: '2024-01-10',
        next_date: '2025-01-10',
        completed: true,
        description: '注射狂犬疫苗，一切正常'
      },
      {
        id: 2,
        title: '体内驱虫',
        type: 'deworming',
        pet_name: '旺财',
        date: '2024-01-15',
        next_date: '2024-02-15',
        completed: false,
        description: '拜耳驱虫药，一次一片'
      },
      {
        id: 3,
        title: '年度体检',
        type: 'examination',
        pet_name: '小白',
        date: '2024-01-05',
        next_date: '2024-01-20',
        completed: false,
        description: '血常规、生化检查、X光检查'
      }
    ];
    
    // 处理记录数据
    const processedRecords = this.processHealthRecords(mockRecords);
    
    // 更新统计数据
    this.updateStats(processedRecords);
    
    this.setData({
      health_records: processedRecords,
      loading: false,
      show_empty: processedRecords.length === 0,
      has_more: false // 这里根据实际情况判断
    });
  },

  /**
   * 处理健康记录数据
   */
  processHealthRecords: function(records) {
    if (!records || !Array.isArray(records)) {
      return [];
    }
    
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    return records.map(record => {
      // 计算是否过期
      let is_overdue = false;
      let next_days = 0;
      
      if (record.next_date && !record.completed) {
        const nextDate = new Date(record.next_date);
        const daysDiff = Math.ceil((nextDate - today) / (1000 * 60 * 60 * 24));
        next_days = daysDiff;
        is_overdue = nextDate < today;
      }
      
      // 获取类型颜色
      let type_color = '#6c757d';
      const typeObj = this.data.filter_options.types?.find(t => t.id === record.type);
      if (typeObj && typeObj.color) {
        type_color = typeObj.color;
      }
      
      // 处理描述缩略
      let description_short = '';
      if (record.description) {
        description_short = record.description.length > 40 
          ? record.description.substring(0, 40) + '...' 
          : record.description;
      }
      
      return {
        ...record,
        is_overdue,
        next_days,
        type_color,
        description_short
      };
    });
  },

  /**
   * 更新统计数据
   */
  updateStats: function(records) {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    let total = records.length;
    let completed = 0;
    let upcoming = 0;
    let overdue = 0;
    
    records.forEach(record => {
      if (record.completed) {
        completed++;
      } else {
        upcoming++;
        
        // 检查是否过期
        if (record.next_date) {
          const nextDate = new Date(record.next_date);
          if (nextDate < today) {
            overdue++;
          }
        }
      }
    });
    
    this.setData({
      stats: { total, completed, upcoming, overdue }
    });
  },

  /**
   * 切换筛选面板
   */
  toggleFilterPanel: function(e) {
    const panel = e.currentTarget.dataset.panel;
    const isActive = this.data.active_filter_panel === panel;
    
    this.setData({
      active_filter_panel: isActive ? null : panel
    });
  },

  /**
   * 选择筛选条件
   */
  selectFilter: function(e) {
    const { type, value } = e.currentTarget.dataset;
    
    this.setData({
      [`filters.${type}`]: value
    });
    
    // 应用筛选条件
    this.applyFilters();
  },

  /**
   * 应用筛选条件
   */
  applyFilters: function() {
    // 这里应该根据筛选条件重新加载数据
    this.loadHealthRecords();
  },

  /**
   * 清除所有筛选条件
   */
  clearAllFilters: function() {
    this.setData({
      filters: {
        pet_id: 'all',
        type: 'all',
        status: 'all',
        time_range: 'all'
      }
    });
    
    this.applyFilters();
  },

  /**
   * 获取筛选条件显示文本
   */
  get_filter_display_text: function() {
    const { pet_id, type, status, time_range } = this.data.filters;
    const parts = [];
    
    if (pet_id !== 'all') {
      const pet = this.data.filter_options.pets.find(p => p.id === pet_id);
      if (pet) parts.push(pet.name);
    }
    
    if (type !== 'all') {
      const typeObj = this.data.filter_options.types.find(t => t.id === type);
      if (typeObj) parts.push(typeObj.name);
    }
    
    if (status !== 'all') {
      const statusObj = this.data.filter_options.statuses.find(s => s.id === status);
      if (statusObj) parts.push(statusObj.name);
    }
    
    if (time_range !== 'all') {
      const timeObj = this.data.filter_options.time_ranges.find(t => t.id === time_range);
      if (timeObj) parts.push(timeObj.name);
    }
    
    return parts.length > 0 ? parts.join(' · ') : '全部记录';
  },

  /**
   * 点击记录
   */
  onRecordTap: function(e) {
    const record = e.currentTarget.dataset.record;
    wx.navigateTo({
      url: `/pages/health-detail/health-detail?id=${record.id}`
    });
  },

  /**
   * 添加记录
   */
  onAddRecordTap: function() {
    wx.navigateTo({
      url: '/pages/health-add/health-add'
    });
  },

  /**
   * 快速添加
   */
  onQuickAddTap: function(e) {
    const option = e.currentTarget.dataset.option;
    wx.navigateTo({
      url: `/pages/health-add/health-add?type=${option.id}&title=${option.title}`
    });
  },

  /**
   * 切换记录状态
   */
  toggleRecordStatus: function(e) {
    const record = e.currentTarget.dataset.record;
    const index = this.data.health_records.findIndex(r => r.id === record.id);
    
    if (index !== -1) {
      const newRecords = [...this.data.health_records];
      newRecords[index].completed = !newRecords[index].completed;
      
      // 重新处理记录数据
      const processedRecords = this.processHealthRecords(newRecords);
      this.updateStats(processedRecords);
      
      this.setData({
        health_records: processedRecords
      });
    }
  },

  /**
   * 删除记录
   */
  deleteRecord: function(e) {
    const record = e.currentTarget.dataset.record;
    
    wx.showModal({
      title: '确认删除',
      content: '确定要删除这条健康记录吗？',
      success: (res) => {
        if (res.confirm) {
          const index = this.data.health_records.findIndex(r => r.id === record.id);
          
          if (index !== -1) {
            const newRecords = [...this.data.health_records];
            newRecords.splice(index, 1);
            
            // 重新处理记录数据
            const processedRecords = this.processHealthRecords(newRecords);
            this.updateStats(processedRecords);
            
            this.setData({
              health_records: processedRecords,
              show_empty: processedRecords.length === 0
            });
            
            wx.showToast({
              title: '删除成功',
              icon: 'success'
            });
          }
        }
      }
    });
  },

  /**
   * 设置提醒
   */
  setReminder: function(e) {
    const record = e.currentTarget.dataset.record;
    
    wx.showModal({
      title: '设置提醒',
      content: `为"${record.title}"设置提醒`,
      success: (res) => {
        if (res.confirm) {
          wx.showToast({
            title: '提醒已设置',
            icon: 'success'
          });
        }
      }
    });
  },

  /**
   * 搜索记录
   */
  onSearchTap: function() {
    wx.showToast({
      title: '搜索功能开发中',
      icon: 'none'
    });
  },

  /**
   * 查看统计数据
   */
  viewStatistics: function() {
    wx.navigateTo({
      url: '/pages/health-stats/health-stats'
    });
  },

  /**
   * 导入记录
   */
  importRecords: function() {
    wx.showToast({
      title: '导入功能开发中',
      icon: 'none'
    });
  },

  /**
   * 导出记录
   */
  exportRecords: function() {
    wx.showToast({
      title: '导出功能开发中',
      icon: 'none'
    });
  },

  /**
   * 加载更多记录
   */
  loadMoreRecords: function() {
    wx.showToast({
      title: '没有更多记录',
      icon: 'none'
    });
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    this.setData({ refreshing: true });
    
    // 模拟刷新延迟
    setTimeout(() => {
      this.loadHealthRecords();
      this.setData({ refreshing: false });
      wx.stopPullDownRefresh();
    }, 1000);
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    if (this.data.has_more) {
      this.loadMoreRecords();
    }
  }
})