// pages/community-post/community-post.js
const app = getApp()

Page({
  data: {
    // 帖子内容
    post: {
      content: '',
      images: [],
      petIds: [],
      topicId: null,
      location: {
        address: '',
        latitude: null,
        longitude: null
      },
      isPublic: true,
      allowComments: true,
      type: 'normal' // normal, lost, found, adopt
    },
    
    // 草稿相关
    hasDraft: false,
    draftId: null,
    isDraftSaving: false,
    lastSaveTime: null,
    
    // 宠物列表
    myPets: [],
    selectedPets: [],
    
    // 话题列表
    topics: [],
    selectedTopic: null,
    
    // 位置信息
    locationName: '',
    isGettingLocation: false,
    
    // 表单验证
    contentLength: 0,
    maxContentLength: 2000,
    imageCount: 0,
    maxImageCount: 9,
    
    // 发布类型选项
    postTypes: [
      { key: 'normal', name: '日常分享', icon: '📝', color: '#4CAF50' },
      { key: 'lost', name: '寻宠启事', icon: '🔍', color: '#FF9800' },
      { key: 'found', name: '宠物招领', icon: '🏠', color: '#2196F3' },
      { key: 'adopt', name: '领养信息', icon: '❤️', color: '#E91E63' }
    ],
    
    // 界面状态
    isLoading: false,
    isSubmitting: false,
    showPetSelector: false,
    showTopicSelector: false,
    showLocationPicker: false,
    showPrivacyModal: false,
    showSuccessModal: false,
    showErrorModal: false,
    errorMessage: '',
    
    // 发布成功后的帖子ID
    createdPostId: null,
    
    // 键盘状态
    keyboardHeight: 0,
    isKeyboardShow: false,
    
    // 安全区域
    safeAreaBottom: 0,
    
    // 当前步骤（针对寻宠/招领/领养）
    currentStep: 1,
    totalSteps: 3,
    
    // 特殊类型表单（寻宠/招领/领养）
    specialForm: {
      // 寻宠信息
      lostPet: {
        name: '',
        type: 'dog',
        breed: '',
        color: '',
        age: '',
        lostDate: '',
        lostLocation: '',
        contactPhone: '',
        contactWechat: '',
        reward: '',
        description: ''
      },
      // 招领信息
      foundPet: {
        foundDate: '',
        foundLocation: '',
        petCondition: '',
        contactPhone: '',
        description: ''
      },
      // 领养信息
      adoptInfo: {
        petType: 'dog',
        breed: '',
        ageRange: '',
        gender: 'any',
        healthCondition: 'healthy',
        vaccination: 'yes',
        neutered: 'no',
        adoptionConditions: '',
        contactPhone: '',
        contactWechat: ''
      }
    }
  },

  onLoad(options) {
    // 从options获取参数
    const { 
      type, 
      petId, 
      topicId, 
      content,
      draftId 
    } = options
    
    // 获取安全区域
    this.getSafeArea()
    
    // 检查登录状态
    if (!app.globalData.userInfo) {
      this.redirectToLogin()
      return
    }
    
    // 初始化数据
    this.initData()
    
    // 如果有草稿ID，加载草稿
    if (draftId) {
      this.loadDraft(draftId)
    }
    
    // 如果有预填内容，设置
    if (type) {
      this.setData({ 'post.type': type })
    }
    
    if (petId) {
      this.setData({ 
        'post.petIds': [petId],
        selectedPets: app.globalData.myPets.filter(pet => pet.id === petId)
      })
    }
    
    if (topicId) {
      this.setData({ 
        'post.topicId': topicId,
        selectedTopic: this.data.topics.find(t => t.id === topicId)
      })
    }
    
    if (content) {
      this.setData({ 
        'post.content': content,
        contentLength: content.length
      })
    }
    
    // 监听键盘事件
    this.listenKeyboard()
  },

  onShow() {
    // 页面显示时刷新宠物列表
    if (app.globalData.myPets) {
      this.setData({ myPets: app.globalData.myPets })
    }
    
    // 自动保存草稿（如果内容有变化）
    this.autoSaveDraft()
  },

  onHide() {
    // 页面隐藏时保存草稿
    this.saveDraft()
  },

  onUnload() {
    // 页面卸载时清理
    this.removeKeyboardListeners()
  },

  getSafeArea() {
    const systemInfo = wx.getSystemInfoSync()
    this.setData({
      safeAreaBottom: systemInfo.screenHeight - systemInfo.safeArea.bottom
    })
  },

  initData() {
    // 加载话题列表
    this.loadTopics()
    
    // 加载我的宠物
    this.loadMyPets()
    
    // 加载自动保存的草稿
    this.loadAutoSaveDraft()
  },

  async loadTopics() {
    try {
      const response = await app.request({
        url: '/api/community/topics',
        method: 'GET'
      })
      
      if (response.code === 0) {
        this.setData({ topics: response.data })
      }
    } catch (error) {
      console.error('加载话题失败:', error)
    }
  },

  loadMyPets() {
    const myPets = app.globalData.myPets || []
    this.setData({ myPets })
    
    // 如果只有一个宠物，默认选中
    if (myPets.length === 1 && this.data.post.petIds.length === 0) {
      this.setData({
        'post.petIds': [myPets[0].id],
        selectedPets: [myPets[0]]
      })
    }
  },

  redirectToLogin() {
    wx.showModal({
      title: '提示',
      content: '需要登录后才能发布帖子',
      confirmText: '去登录',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/login/login?redirect=/pages/community-post/community-post'
          })
        } else {
          wx.navigateBack()
        }
      }
    })
  },

  // 键盘监听
  listenKeyboard() {
    wx.onKeyboardHeightChange((res) => {
      this.setData({
        keyboardHeight: res.height,
        isKeyboardShow: res.height > 0
      })
    })
  },

  removeKeyboardListeners() {
    wx.offKeyboardHeightChange()
  },

  // 内容输入
  onContentInput(e) {
    const content = e.detail.value
    const contentLength = content.length
    
    this.setData({
      'post.content': content,
      contentLength
    })
    
    // 内容变化时自动保存草稿
    this.autoSaveDraft()
  },

  // 选择发布类型
  selectPostType(e) {
    const { type } = e.currentTarget.dataset
    
    if (this.data.post.type === type) return
    
    // 如果当前有内容，提示切换类型可能会清空特殊表单
    if (this.data.post.content || this.data.post.images.length > 0) {
      wx.showModal({
        title: '切换类型',
        content: '切换发布类型将清空特殊表单，但保留基础内容',
        confirmText: '继续',
        cancelText: '取消',
        success: (res) => {
          if (res.confirm) {
            this.setData({
              'post.type': type,
              currentStep: 1
            })
          }
        }
      })
    } else {
      this.setData({
        'post.type': type,
        currentStep: 1
      })
    }
  },

  // 下一步（针对特殊类型）
  nextStep() {
    if (this.data.currentStep < this.data.totalSteps) {
      this.setData({ currentStep: this.data.currentStep + 1 })
    }
  },

  // 上一步
  prevStep() {
    if (this.data.currentStep > 1) {
      this.setData({ currentStep: this.data.currentStep - 1 })
    }
  },

  // 特殊表单输入
  onSpecialFormInput(e) {
    const { field, subfield } = e.currentTarget.dataset
    const { value } = e.detail
    
    this.setData({
      [`specialForm.${field}.${subfield}`]: value
    })
  },

  // 图片上传
  onImageUpload(e) {
    const images = e.detail.images
    this.setData({
      'post.images': images,
      imageCount: images.length
    })
    
    // 图片变化时自动保存草稿
    this.autoSaveDraft()
  },

  // 删除图片
  onImageDelete(e) {
    const { index } = e.detail
    const images = [...this.data.post.images]
    images.splice(index, 1)
    
    this.setData({
      'post.images': images,
      imageCount: images.length
    })
  },

  // 选择宠物
  togglePetSelector() {
    this.setData({ showPetSelector: !this.data.showPetSelector })
  },

  onPetSelect(e) {
    const { pets } = e.detail
    const petIds = pets.map(pet => pet.id)
    
    this.setData({
      'post.petIds': petIds,
      selectedPets: pets,
      showPetSelector: false
    })
    
    this.autoSaveDraft()
  },

  // 选择话题
  toggleTopicSelector() {
    this.setData({ showTopicSelector: !this.data.showTopicSelector })
  },

  onTopicSelect(e) {
    const { topic } = e.detail
    
    this.setData({
      'post.topicId': topic.id,
      selectedTopic: topic,
      showTopicSelector: false
    })
    
    this.autoSaveDraft()
  },

  // 获取位置
  async getLocation() {
    if (this.data.isGettingLocation) return
    
    this.setData({ isGettingLocation: true })
    
    try {
      // 获取位置权限
      const setting = await wx.getSetting()
      if (!setting.authSetting['scope.userLocation']) {
        await wx.authorize({ scope: 'scope.userLocation' })
      }
      
      // 获取当前位置
      const location = await new Promise((resolve, reject) => {
        wx.getLocation({
          type: 'gcj02',
          success: resolve,
          fail: reject
        })
      })
      
      // 逆地理编码获取地址
      const address = await this.reverseGeocode(location.latitude, location.longitude)
      
      this.setData({
        'post.location': {
          address,
          latitude: location.latitude,
          longitude: location.longitude
        },
        locationName: address,
        isGettingLocation: false
      })
      
      this.autoSaveDraft()
      
    } catch (error) {
      console.error('获取位置失败:', error)
      this.setData({ isGettingLocation: false })
      
      wx.showToast({
        title: '获取位置失败',
        icon: 'error'
      })
    }
  },

  async reverseGeocode(latitude, longitude) {
    try {
      // 这里可以调用地图API进行逆地理编码
      // 暂时返回坐标字符串
      return `纬度: ${latitude.toFixed(6)}, 经度: ${longitude.toFixed(6)}`
    } catch (error) {
      return '未知位置'
    }
  },

  // 清除位置
  clearLocation() {
    this.setData({
      'post.location': {
        address: '',
        latitude: null,
        longitude: null
      },
      locationName: ''
    })
    
    this.autoSaveDraft()
  },

  // 隐私设置
  togglePrivacyModal() {
    this.setData({ showPrivacyModal: !this.data.showPrivacyModal })
  },

  updatePrivacySetting(e) {
    const { field } = e.currentTarget.dataset
    const value = !this.data.post[field]
    
    this.setData({
      [`post.${field}`]: value
    })
    
    this.autoSaveDraft()
  },

  // 验证表单
  validateForm() {
    const { post, contentLength, specialForm, postType } = this.data
    
    // 检查内容
    if (!post.content.trim() && post.type === 'normal') {
      wx.showToast({
        title: '请输入内容',
        icon: 'none'
      })
      return false
    }
    
    if (contentLength > this.data.maxContentLength) {
      wx.showToast({
        title: `内容过长，最多${this.data.maxContentLength}字`,
        icon: 'none'
      })
      return false
    }
    
    // 特殊类型的额外验证
    if (post.type === 'lost') {
      const lostForm = specialForm.lostPet
      if (!lostForm.name.trim()) {
        wx.showToast({
          title: '请输入宠物名称',
          icon: 'none'
        })
        return false
      }
      
      if (!lostForm.lostDate) {
        wx.showToast({
          title: '请选择走失日期',
          icon: 'none'
        })
        return false
      }
      
      if (!lostForm.lostLocation.trim()) {
        wx.showToast({
          title: '请输入走失地点',
          icon: 'none'
        })
        return false
      }
      
      if (!lostForm.contactPhone.trim() && !lostForm.contactWechat.trim()) {
        wx.showToast({
          title: '请输入联系方式',
          icon: 'none'
        })
        return false
      }
    }
    
    if (post.type === 'found') {
      const foundForm = specialForm.foundPet
      if (!foundForm.foundLocation.trim()) {
        wx.showToast({
          title: '请输入发现地点',
          icon: 'none'
        })
        return false
      }
    }
    
    if (post.type === 'adopt') {
      const adoptForm = specialForm.adoptInfo
      if (!adoptForm.adoptionConditions.trim()) {
        wx.showToast({
          title: '请输入领养条件',
          icon: 'none'
        })
        return false
      }
    }
    
    return true
  },

  // 发布帖子
  async submitPost() {
    if (this.data.isSubmitting) return
    
    // 表单验证
    if (!this.validateForm()) {
      return
    }
    
    this.setData({ isSubmitting: true })
    wx.showLoading({ title: '发布中...', mask: true })
    
    try {
      // 准备提交数据
      const postData = await this.preparePostData()
      
      // 调用发布接口
      const response = await app.request({
        url: '/api/community/posts',
        method: 'POST',
        data: postData
      })
      
      if (response.code === 0) {
        wx.hideLoading()
        this.setData({ 
          isSubmitting: false,
          createdPostId: response.data.id,
          showSuccessModal: true 
        })
        
        // 清除本地草稿
        this.clearDraft()
        
        // 广播帖子更新事件
        app.eventBus.emit('postCreated', response.data)
        
      } else {
        throw new Error(response.msg)
      }
      
    } catch (error) {
      console.error('发布失败:', error)
      wx.hideLoading()
      this.setData({ 
        isSubmitting: false,
        errorMessage: error.message || '发布失败',
        showErrorModal: true 
      })
    }
  },

  // 准备提交数据
  async preparePostData() {
    const { post, specialForm } = this.data
    
    // 基础数据
    const postData = {
      content: post.content.trim(),
      images: post.images,
      petIds: post.petIds,
      topicId: post.topicId,
      location: post.location,
      isPublic: post.isPublic,
      allowComments: post.allowComments,
      type: post.type
    }
    
    // 根据类型添加特殊数据
    if (post.type === 'lost') {
      postData.specialData = {
        type: 'lost',
        ...specialForm.lostPet
      }
    } else if (post.type === 'found') {
      postData.specialData = {
        type: 'found',
        ...specialForm.foundPet
      }
    } else if (post.type === 'adopt') {
      postData.specialData = {
        type: 'adopt',
        ...specialForm.adoptInfo
      }
    }
    
    // 如果有图片，先上传图片
    if (post.images.length > 0) {
      const uploadPromises = post.images.map(image => this.uploadImage(image))
      postData.images = await Promise.all(uploadPromises)
    }
    
    return postData
  },

  async uploadImage(filePath) {
    return new Promise((resolve, reject) => {
      wx.uploadFile({
        url: `${app.globalData.apiBase}/api/upload`,
        filePath: filePath,
        name: 'file',
        formData: { type: 'post' },
        success: (res) => {
          const result = JSON.parse(res.data)
          if (result.code === 0) {
            resolve(result.data.url)
          } else {
            reject(new Error(result.msg))
          }
        },
        fail: reject
      })
    })
  },

  // 草稿功能
  loadAutoSaveDraft() {
    try {
      const draft = wx.getStorageSync('community_post_draft')
      if (draft) {
        this.setData({
          post: draft.post || this.data.post,
          specialForm: draft.specialForm || this.data.specialForm,
          selectedPets: draft.selectedPets || [],
          selectedTopic: draft.selectedTopic || null,
          locationName: draft.locationName || '',
          contentLength: draft.contentLength || 0,
          imageCount: draft.imageCount || 0,
          hasDraft: true,
          draftId: draft.id || Date.now().toString()
        })
        
        this.data.lastSaveTime = draft.timestamp || null
      }
    } catch (error) {
      console.error('加载草稿失败:', error)
    }
  },

  loadDraft(draftId) {
    // 这里可以调用接口加载服务器保存的草稿
    console.log('加载草稿:', draftId)
  },

  autoSaveDraft() {
    // 防抖处理，避免频繁保存
    clearTimeout(this.saveTimer)
    this.saveTimer = setTimeout(() => {
      this.saveDraft()
    }, 3000)
  },

  saveDraft() {
    if (this.data.isDraftSaving) return
    
    const { post, specialForm, selectedPets, selectedTopic, locationName, contentLength, imageCount } = this.data
    
    // 如果没有内容，不保存
    if (!post.content.trim() && post.images.length === 0) {
      return
    }
    
    this.setData({ isDraftSaving: true })
    
    const draft = {
      id: this.data.draftId || Date.now().toString(),
      post,
      specialForm,
      selectedPets,
      selectedTopic,
      locationName,
      contentLength,
      imageCount,
      timestamp: Date.now()
    }
    
    try {
      wx.setStorageSync('community_post_draft', draft)
      this.setData({ 
        hasDraft: true,
        draftId: draft.id,
        lastSaveTime: new Date().toLocaleTimeString(),
        isDraftSaving: false 
      })
      
      console.log('草稿已保存:', draft.id)
    } catch (error) {
      console.error('保存草稿失败:', error)
      this.setData({ isDraftSaving: false })
    }
  },

  clearDraft() {
    try {
      wx.removeStorageSync('community_post_draft')
      this.setData({ 
        hasDraft: false,
        draftId: null,
        lastSaveTime: null 
      })
    } catch (error) {
      console.error('清除草稿失败:', error)
    }
  },

  // 继续编辑草稿
  continueEditDraft() {
    this.setData({ showSuccessModal: false })
  },

  // 查看发布的帖子
  viewPostedPost() {
    if (!this.data.createdPostId) return
    
    wx.redirectTo({
      url: `/pages/community-post-detail/community-post-detail?id=${this.data.createdPostId}`,
      success: () => {
        this.setData({ showSuccessModal: false })
      }
    })
  },

  // 返回社区
  backToCommunity() {
    wx.switchTab({
      url: '/pages/community/community'
    })
  },

  // 发布更多
  postMore() {
    this.setData({
      showSuccessModal: false,
      post: {
        content: '',
        images: [],
        petIds: [],
        topicId: null,
        location: {
          address: '',
          latitude: null,
          longitude: null
        },
        isPublic: true,
        allowComments: true,
        type: 'normal'
      },
      specialForm: {
        lostPet: {
          name: '',
          type: 'dog',
          breed: '',
          color: '',
          age: '',
          lostDate: '',
          lostLocation: '',
          contactPhone: '',
          contactWechat: '',
          reward: '',
          description: ''
        },
        foundPet: {
          foundDate: '',
          foundLocation: '',
          petCondition: '',
          contactPhone: '',
          description: ''
        },
        adoptInfo: {
          petType: 'dog',
          breed: '',
          ageRange: '',
          gender: 'any',
          healthCondition: 'healthy',
          vaccination: 'yes',
          neutered: 'no',
          adoptionConditions: '',
          contactPhone: '',
          contactWechat: ''
        }
      },
      selectedPets: [],
      selectedTopic: null,
      locationName: '',
      contentLength: 0,
      imageCount: 0,
      currentStep: 1,
      createdPostId: null
    })
    
    // 自动选中第一个宠物
    if (this.data.myPets.length === 1) {
      this.setData({
        'post.petIds': [this.data.myPets[0].id],
        selectedPets: [this.data.myPets[0]]
      })
    }
  },

  // 关闭错误模态框
  closeErrorModal() {
    this.setData({ showErrorModal: false })
  },

  // 取消发布
  cancelPost() {
    const { post, specialForm } = this.data
    
    // 检查是否有内容
    const hasContent = post.content.trim() || post.images.length > 0 || 
                       (post.type !== 'normal' && 
                        Object.values(specialForm[`${post.type}Pet`] || {}).some(v => v))
    
    if (hasContent) {
      wx.showModal({
        title: '确认离开',
        content: '离开后内容将自动保存为草稿',
        confirmText: '保存草稿',
        cancelText: '直接离开',
        success: (res) => {
          if (res.confirm) {
            this.saveDraft()
            wx.navigateBack()
          } else {
            this.clearDraft()
            wx.navigateBack()
          }
        }
      })
    } else {
      wx.navigateBack()
    }
  }
})