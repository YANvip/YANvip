// pages/scan/scan.js
const app = getApp()

Page({
  data: {
    // 相机状态
    cameraActive: false,
    cameraDirection: 'back',
    flashMode: 'off',
    cameraContext: null,
    cameraFrame: null,
    
    // 扫描状态
    isScanning: false,
    scanResult: null,
    scanCount: 0,
    maxScanCount: 5,
    
    // 界面状态
    showManualInput: false,
    showResultModal: false,
    showErrorModal: false,
    showPermissionGuide: false,
    showFlashOptions: false,
    
    // 手动输入
    manualInputValue: '',
    inputFocus: false,
    
    // 错误信息
    errorMsg: '',
    errorCode: '',
    
    // 扫描结果
    scanResultData: null,
    resultType: '', // 'pet' | 'unknown' | 'error'
    
    // 权限状态
    cameraAuth: false,
    userAuth: false,
    
    // UI 状态
    scanningAnimation: true,
    showTips: true,
    tips: [
      '将二维码放入框内，自动扫描',
      '保持手机稳定，避免抖动',
      '确保光线充足，避免反光',
      '支持手动输入二维码编号'
    ],
    currentTipIndex: 0,
    
    // 设备信息
    windowWidth: 375,
    windowHeight: 667,
    safeArea: { top: 0, bottom: 0 },
    
    // 扫描框位置
    scanBox: {
      left: 50,
      top: 200,
      width: 275,
      height: 275
    }
  },

  onLoad() {
    // 获取设备信息
    this.getDeviceInfo()
    
    // 检查权限
    this.checkCameraPermission()
    
    // 初始化相机
    this.initCamera()
    
    // 启动提示轮播
    this.startTipsCarousel()
  },

  onShow() {
    // 页面显示时重新激活相机
    if (!this.data.cameraActive) {
      this.setData({ cameraActive: true })
    }
    
    // 重置扫描状态
    if (this.data.isScanning) {
      this.setData({ isScanning: false })
    }
  },

  onHide() {
    // 页面隐藏时停止相机
    this.setData({ cameraActive: false })
    
    // 停止提示轮播
    this.stopTipsCarousel()
  },

  onUnload() {
    // 页面卸载时清理资源
    this.cleanupCamera()
    this.stopTipsCarousel()
  },

  onReady() {
    // 页面渲染完成后初始化相机帧
    this.initCameraFrame()
  },

  getDeviceInfo() {
    const systemInfo = wx.getSystemInfoSync()
    const windowWidth = systemInfo.windowWidth
    const windowHeight = systemInfo.windowHeight
    
    // 计算扫描框位置（居中）
    const scanBoxSize = Math.min(windowWidth, windowHeight) * 0.7
    const scanBoxLeft = (windowWidth - scanBoxSize) / 2
    const scanBoxTop = (windowHeight - scanBoxSize) / 2 - 50
    
    this.setData({
      windowWidth,
      windowHeight,
      safeArea: systemInfo.safeArea,
      scanBox: {
        left: scanBoxLeft,
        top: scanBoxTop,
        width: scanBoxSize,
        height: scanBoxSize
      }
    })
  },

  // 检查相机权限
  async checkCameraPermission() {
    try {
      const setting = await wx.getSetting()
      
      if (setting.authSetting['scope.camera'] === false) {
        // 用户已拒绝过权限
        this.setData({ 
          cameraAuth: false,
          showPermissionGuide: true 
        })
      } else if (setting.authSetting['scope.camera'] === true) {
        // 用户已授权
        this.setData({ cameraAuth: true })
      } else {
        // 从未询问过权限
        this.requestCameraPermission()
      }
    } catch (error) {
      console.error('检查权限失败:', error)
      this.setData({ cameraAuth: false })
    }
  },

  // 请求相机权限
  async requestCameraPermission() {
    try {
      const res = await wx.authorize({
        scope: 'scope.camera'
      })
      
      if (res.errMsg === 'authorize:ok') {
        this.setData({ cameraAuth: true })
        this.initCamera()
      }
    } catch (error) {
      console.error('请求权限失败:', error)
      this.setData({ 
        cameraAuth: false,
        showPermissionGuide: true 
      })
    }
  },

  // 跳转到设置页面
  goToSettings() {
    wx.openSetting({
      success: (res) => {
        if (res.authSetting['scope.camera']) {
          this.setData({ 
            cameraAuth: true,
            showPermissionGuide: false 
          })
          this.initCamera()
        }
      }
    })
  },

  initCamera() {
    if (!this.data.cameraAuth) return
    
    try {
      // 创建相机上下文
      const cameraContext = wx.createCameraContext()
      
      this.setData({ 
        cameraActive: true,
        cameraContext 
      })
      
      // 开始监听扫码事件
      this.startScanListener()
      
    } catch (error) {
      console.error('初始化相机失败:', error)
      this.setData({
        errorMsg: '相机初始化失败',
        errorCode: 'CAMERA_INIT_ERROR',
        showErrorModal: true
      })
    }
  },

  initCameraFrame() {
    // 创建选择器查询，获取相机组件位置
    const query = wx.createSelectorQuery()
    query.select('#camera').boundingClientRect()
    query.exec((res) => {
      if (res[0]) {
        this.setData({ cameraFrame: res[0] })
      }
    })
  },

  startScanListener() {
    if (!this.data.cameraContext || this.data.isScanning) return
    
    // 监听相机扫码事件
    this.data.cameraContext.onCameraScan((res) => {
      if (res.result && !this.data.isScanning) {
        this.handleScanResult(res.result)
      }
    })
    
    // 开始监听
    this.data.cameraContext.startRecord({
      success: () => {
        console.log('开始监听扫码')
      },
      fail: (err) => {
        console.error('开始监听失败:', err)
      }
    })
  },

  stopScanListener() {
    if (this.data.cameraContext) {
      this.data.cameraContext.stopRecord()
      this.data.cameraContext.offCameraScan()
    }
  },

  // 处理扫描结果
  async handleScanResult(result) {
    if (this.data.isScanning) return
    
    this.setData({ isScanning: true })
    
    // 播放扫描成功音效（如果需要）
    this.playScanSound()
    
    // 显示扫描成功动画
    this.showScanSuccess()
    
    // 解析二维码内容
    const parsedResult = this.parseQRCode(result)
    
    if (!parsedResult.valid) {
      this.handleInvalidQRCode(parsedResult)
      return
    }
    
    // 根据二维码类型处理
    switch (parsedResult.type) {
      case 'pet':
        await this.handlePetQRCode(parsedResult)
        break
      case 'url':
        await this.handleUrlQRCode(parsedResult)
        break
      case 'text':
        await this.handleTextQRCode(parsedResult)
        break
      default:
        this.handleUnknownQRCode(parsedResult)
    }
  },

  // 解析二维码
  parseQRCode(code) {
    // 去除空格
    const cleanCode = code.trim()
    
    // 检查是否为空
    if (!cleanCode) {
      return {
        valid: false,
        type: 'empty',
        original: code,
        error: '二维码内容为空'
      }
    }
    
    // 检查是否为宠物二维码（项目特定的格式）
    if (cleanCode.startsWith('PET_')) {
      return {
        valid: true,
        type: 'pet',
        code: cleanCode,
        petId: cleanCode.replace('PET_', '')
      }
    }
    
    // 检查是否为URL
    try {
      new URL(cleanCode)
      return {
        valid: true,
        type: 'url',
        code: cleanCode,
        url: cleanCode
      }
    } catch (e) {
      // 不是有效的URL
    }
    
    // 默认为文本
    return {
      valid: true,
      type: 'text',
      code: cleanCode,
      text: cleanCode
    }
  },

  // 处理宠物二维码
  async handlePetQRCode(parsedResult) {
    try {
      // 显示加载中
      wx.showLoading({
        title: '查询宠物信息中...',
        mask: true
      })
      
      // 调用后端接口查询宠物信息
      const response = await app.request({
        url: `/api/pets/qr-code/${encodeURIComponent(parsedResult.code)}`,
        method: 'GET'
      })
      
      wx.hideLoading()
      
      if (response.code === 0 && response.data) {
        const petInfo = response.data
        
        // 保存扫描结果
        this.setData({
          scanResultData: petInfo,
          resultType: 'pet'
        })
        
        // 根据用户身份决定跳转页面
        await this.navigateBasedOnUserRole(petInfo)
        
      } else {
        this.handleNoPetFound(parsedResult)
      }
      
    } catch (error) {
      console.error('查询宠物信息失败:', error)
      wx.hideLoading()
      
      this.setData({
        errorMsg: '网络错误，请重试',
        errorCode: 'NETWORK_ERROR',
        showErrorModal: true,
        isScanning: false
      })
    }
  },

  // 根据用户身份导航
  async navigateBasedOnUserRole(petInfo) {
    // 检查用户是否登录
    const isLoggedIn = app.globalData.userInfo && app.globalData.userInfo.id
    
    if (!isLoggedIn) {
      // 未登录用户，跳转到公开信息页
      this.navigateToPublicPetInfo(petInfo)
      return
    }
    
    // 已登录用户，检查是否是宠物主人
    const userId = app.globalData.userInfo.id
    const isOwner = petInfo.ownerId === userId
    
    if (isOwner) {
      // 主人，跳转到宠物详情页
      this.navigateToPetDetail(petInfo)
    } else {
      // 非主人，跳转到公开信息页
      this.navigateToPublicPetInfo(petInfo)
    }
  },

  // 跳转到宠物详情页
  navigateToPetDetail(petInfo) {
    wx.redirectTo({
      url: `/pages/pet-detail/pet-detail?id=${petInfo.id}`,
      success: () => {
        // 重置扫描状态
        this.resetScanState()
      }
    })
  },

  // 跳转到公开信息页
  navigateToPublicPetInfo(petInfo) {
    wx.redirectTo({
      url: `/pages/public-pet-info/public-pet-info?id=${petInfo.id}`,
      success: () => {
        // 重置扫描状态
        this.resetScanState()
      }
    })
  },

  // 处理未找到宠物的情况
  handleNoPetFound(parsedResult) {
    // 显示绑定引导
    this.setData({
      scanResultData: {
        qrCode: parsedResult.code,
        type: 'unregistered_pet'
      },
      resultType: 'unregistered',
      showResultModal: true,
      isScanning: false
    })
  },

  // 处理无效二维码
  handleInvalidQRCode(parsedResult) {
    this.setData({
      errorMsg: parsedResult.error || '无效的二维码',
      errorCode: 'INVALID_QR_CODE',
      showErrorModal: true,
      isScanning: false
    })
  },

  // 处理URL二维码
  async handleUrlQRCode(parsedResult) {
    // 显示确认模态框
    wx.showModal({
      title: '检测到链接',
      content: `是否打开链接：${parsedResult.url}`,
      confirmText: '打开',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          wx.setClipboardData({
            data: parsedResult.url,
            success: () => {
              wx.showToast({
                title: '链接已复制',
                icon: 'success'
              })
            }
          })
        }
        this.setData({ isScanning: false })
      }
    })
  },

  // 处理文本二维码
  async handleTextQRCode(parsedResult) {
    // 显示文本内容
    this.setData({
      scanResultData: {
        text: parsedResult.text,
        type: 'text'
      },
      resultType: 'text',
      showResultModal: true,
      isScanning: false
    })
  },

  // 处理未知二维码
  handleUnknownQRCode(parsedResult) {
    this.setData({
      scanResultData: {
        code: parsedResult.code,
        type: 'unknown'
      },
      resultType: 'unknown',
      showResultModal: true,
      isScanning: false
    })
  },

  // 重置扫描状态
  resetScanState() {
    setTimeout(() => {
      this.setData({
        isScanning: false,
        scanResult: null,
        scanResultData: null,
        resultType: ''
      })
    }, 1000)
  },

  // 播放扫描成功音效
  playScanSound() {
    // 可以在这里添加音效播放逻辑
    // 例如：wx.createInnerAudioContext().play()
  },

  // 显示扫描成功动画
  showScanSuccess() {
    // 可以在这里添加扫描成功动画效果
  },

  // 手动输入二维码
  toggleManualInput() {
    this.setData({ 
      showManualInput: !this.data.showManualInput,
      inputFocus: !this.data.showManualInput
    })
  },

  // 手动输入确认
  confirmManualInput() {
    const value = this.data.manualInputValue.trim()
    
    if (!value) {
      wx.showToast({
        title: '请输入二维码',
        icon: 'none'
      })
      return
    }
    
    // 处理手动输入的二维码
    this.handleScanResult(value)
    
    // 关闭输入框
    this.setData({
      showManualInput: false,
      manualInputValue: ''
    })
  },

  // 输入框值变化
  onManualInputChange(e) {
    this.setData({
      manualInputValue: e.detail.value
    })
  },

  // 切换摄像头
  switchCamera() {
    const newDirection = this.data.cameraDirection === 'back' ? 'front' : 'back'
    this.setData({ cameraDirection: newDirection })
  },

  // 切换闪光灯
  toggleFlash() {
    this.setData({ showFlashOptions: true })
  },

  // 选择闪光灯模式
  selectFlashMode(e) {
    const { mode } = e.currentTarget.dataset
    this.setData({
      flashMode: mode,
      showFlashOptions: false
    })
  },

  // 打开相册选择二维码
  openAlbum() {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album'],
      success: (res) => {
        const tempFilePath = res.tempFiles[0].tempFilePath
        
        // 识别图片中的二维码
        wx.scanCode({
          path: tempFilePath,
          onlyFromCamera: false,
          success: (scanRes) => {
            this.handleScanResult(scanRes.result)
          },
          fail: (err) => {
            console.error('识别二维码失败:', err)
            wx.showToast({
              title: '未识别到二维码',
              icon: 'error'
            })
          }
        })
      },
      fail: (err) => {
        console.error('选择图片失败:', err)
      }
    })
  },

  // 处理结果模态框操作
  handleResultAction(e) {
    const { action } = e.currentTarget.dataset
    
    switch (action) {
      case 'bind':
        this.navigateToBindProcess()
        break
      case 'cancel':
        this.closeResultModal()
        break
      case 'copy':
        this.copyResult()
        break
      case 'close':
        this.closeResultModal()
        break
    }
  },

  // 导航到绑定处理页面
  navigateToBindProcess() {
    if (!this.data.scanResultData) return
    
    wx.redirectTo({
      url: `/pages/bind-process/bind-process?qrcode=${encodeURIComponent(this.data.scanResultData.qrCode)}`,
      success: () => {
        this.closeResultModal()
      }
    })
  },

  // 复制结果
  copyResult() {
    const text = this.data.scanResultData?.text || this.data.scanResultData?.code || ''
    
    if (text) {
      wx.setClipboardData({
        data: text,
        success: () => {
          wx.showToast({
            title: '已复制',
            icon: 'success'
          })
        }
      })
    }
  },

  // 关闭结果模态框
  closeResultModal() {
    this.setData({
      showResultModal: false,
      showErrorModal: false,
      isScanning: false
    })
  },

  // 关闭错误模态框
  closeErrorModal() {
    this.setData({
      showErrorModal: false,
      isScanning: false
    })
  },

  // 关闭权限引导
  closePermissionGuide() {
    this.setData({ showPermissionGuide: false })
    wx.navigateBack()
  },

  // 启动提示轮播
  startTipsCarousel() {
    this.tipsInterval = setInterval(() => {
      const nextIndex = (this.data.currentTipIndex + 1) % this.data.tips.length
      this.setData({ currentTipIndex: nextIndex })
    }, 3000)
  },

  // 停止提示轮播
  stopTipsCarousel() {
    if (this.tipsInterval) {
      clearInterval(this.tipsInterval)
      this.tipsInterval = null
    }
  },

  // 切换提示显示
  toggleTips() {
    this.setData({ showTips: !this.data.showTips })
  },

  // 清理相机资源
  cleanupCamera() {
    this.stopScanListener()
    this.setData({ cameraActive: false })
  },

  // 相机错误处理
  onCameraError(e) {
    console.error('相机错误:', e.detail)
    
    this.setData({
      errorMsg: '相机出错，请重试',
      errorCode: 'CAMERA_ERROR',
      showErrorModal: true,
      cameraActive: false
    })
  },

  // 返回首页
  goBack() {
    wx.navigateBack()
  },

  // 手动触发扫码（用于测试）
  manualTriggerScan() {
    if (this.data.isScanning) return
    
    // 模拟扫描到宠物二维码
    const testQRCode = 'PET_' + Date.now().toString().slice(-8)
    this.handleScanResult(testQRCode)
  }
})
// pages/scan/scan.js 关键部分需要更新
Page({
  data: {
    // 使用下划线命名
    camera_auth: false,
    camera_active: true,
    flash_mode: 'off',
    camera_direction: 'back',
    show_manual_input: false,
    scan_result_data: null,
    result_type: null,
    show_result_modal: false,
    is_scanning: false,
    error_msg: '',
    error_code: '',
    show_error_modal: false
  },

  // 事件处理函数使用下划线命名
  on_camera_error(e) {
    console.log('摄像头错误:', e.detail)
  },

  go_to_settings() {
    wx.openSetting({
      success(res) {
        console.log('设置页面打开成功:', res)
      }
    })
  },

  toggle_manual_input() {
    this.setData({
      show_manual_input: !this.data.show_manual_input,
      input_focus: true
    })
  },

  handle_result_action(e) {
    const action = e.currentTarget.dataset.action
    console.log('处理结果操作:', action)
    // ...处理逻辑
  },

  // 其他函数也都要改为下划线命名
})