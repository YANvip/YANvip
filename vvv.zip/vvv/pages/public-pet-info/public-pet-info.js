// pages/public-pet-info/public-pet-info.js
Page({
  data: {
    petId: null,
    petInfo: null,
    loading: true,
    isOwner: false,
    showOwnerInfo: false,
    contactAllowed: false,
    error: false,
    errorMsg: '',
    showContactModal: false,
    showReportModal: false,
    reportReason: '',
    safeAreaBottom: 0
  },

  onLoad(options) {
    const { id, qrcode } = options
    
    // 获取安全区域
    const systemInfo = wx.getSystemInfoSync()
    this.setData({
      safeAreaBottom: systemInfo.screenHeight - systemInfo.safeArea.bottom,
      petId: id || null
    })

    // 如果有二维码，先解析
    if (qrcode) {
      this.processQRCode(qrcode)
    } else if (id) {
      this.loadPetInfo(id)
    } else {
      this.setData({
        error: true,
        errorMsg: '未找到宠物信息',
        loading: false
      })
    }
  },

  async processQRCode(qrCode) {
    try {
      // 调用后端接口根据二维码查询宠物
      const response = await wx.request({
        url: `${getApp().globalData.apiBase}/api/pets/qr-code/${encodeURIComponent(qrCode)}`,
        method: 'GET'
      })

      if (response.statusCode === 200 && response.data.code === 0) {
        const petInfo = response.data.data
        this.setData({
          petId: petInfo.id,
          petInfo: petInfo,
          showOwnerInfo: petInfo.showOwnerInfo,
          contactAllowed: petInfo.allowContact
        })
        this.checkOwnership()
      } else {
        throw new Error(response.data.msg || '宠物不存在')
      }
    } catch (error) {
      console.error('处理二维码失败:', error)
      this.setData({
        error: true,
        errorMsg: error.message || '二维码无效',
        loading: false
      })
    }
  },

  async loadPetInfo(petId) {
    this.setData({ loading: true })
    
    try {
      const response = await wx.request({
        url: `${getApp().globalData.apiBase}/api/pets/${petId}/public`,
        method: 'GET'
      })

      if (response.statusCode === 200 && response.data.code === 0) {
        const petInfo = response.data.data
        this.setData({
          petInfo: petInfo,
          showOwnerInfo: petInfo.showOwnerInfo,
          contactAllowed: petInfo.allowContact,
          loading: false
        })
        this.checkOwnership()
      } else {
        throw new Error(response.data.msg || '获取信息失败')
      }
    } catch (error) {
      console.error('加载宠物信息失败:', error)
      this.setData({
        error: true,
        errorMsg: error.message || '网络错误',
        loading: false
      })
    }
  },

  checkOwnership() {
    const userInfo = getApp().globalData.userInfo
    if (userInfo && this.data.petInfo && userInfo.id === this.data.petInfo.ownerId) {
      this.setData({ isOwner: true })
    }
  },

  // 联系主人
  onContactOwner() {
    if (!this.data.contactAllowed) {
      wx.showToast({
        title: '主人未开启联系方式',
        icon: 'none'
      })
      return
    }

    this.setData({ showContactModal: true })
  },

  // 拨打电话
  makePhoneCall() {
    if (!this.data.petInfo.ownerPhone) {
      wx.showToast({
        title: '暂无联系方式',
        icon: 'none'
      })
      return
    }

    wx.showActionSheet({
      itemList: [`拨打电话: ${this.data.petInfo.ownerPhone}`, '复制号码'],
      success: (res) => {
        if (res.tapIndex === 0) {
          wx.makePhoneCall({
            phoneNumber: this.data.petInfo.ownerPhone
          })
        } else if (res.tapIndex === 1) {
          wx.setClipboardData({
            data: this.data.petInfo.ownerPhone,
            success: () => {
              wx.showToast({
                title: '号码已复制',
                icon: 'success'
              })
            }
          })
        }
      }
    })
    this.setData({ showContactModal: false })
  },

  // 发送消息
  sendMessage() {
    wx.showToast({
      title: '请通过电话联系主人',
      icon: 'none'
    })
    this.setData({ showContactModal: false })
  },

  // 上报信息
  onReport() {
    this.setData({ 
      showReportModal: true,
      reportReason: ''
    })
  },

  // 提交上报
  submitReport() {
    if (!this.data.reportReason.trim()) {
      wx.showToast({
        title: '请填写上报原因',
        icon: 'none'
      })
      return
    }

    const reportData = {
      petId: this.data.petId,
      reason: this.data.reportReason,
      reporterInfo: '游客上报',
      timestamp: new Date().toISOString()
    }

    // 这里可以调用上报接口
    console.log('上报信息:', reportData)
    
    wx.showToast({
      title: '感谢您的反馈',
      icon: 'success'
    })

    this.setData({ 
      showReportModal: false,
      reportReason: ''
    })
  },

  // 回到首页
  goToHome() {
    wx.switchTab({
      url: '/pages/index/index'
    })
  },

  // 查看走失详情
  viewLostDetail() {
    if (this.data.petInfo.status === 'lost') {
      wx.showModal({
        title: '走失详情',
        content: this.data.petInfo.lostDetail || '主人正在寻找，如有见到请联系主人',
        showCancel: false
      })
    }
  },

  // 分享功能
  onShareAppMessage() {
    const petInfo = this.data.petInfo
    if (!petInfo) return {}

    return {
      title: `看看这只${petInfo.type}：${petInfo.name}`,
      path: `/pages/public-pet-info/public-pet-info?id=${petInfo.id}`,
      imageUrl: petInfo.avatar || '/assets/default-pet.png'
    }
  },

  // 图片预览
  previewImage(e) {
    const { index } = e.currentTarget.dataset
    const images = this.data.petInfo.images || []
    
    if (images.length > 0) {
      wx.previewImage({
        current: images[index],
        urls: images
      })
    }
  }
})