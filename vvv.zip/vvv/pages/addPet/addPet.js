// pages/addPet/addPet.js
const app = getApp()
const { showToast } = require('../../utils/wxapi')

Page({
  data: {
    addMethods: [
      {
        id: 'manual',
        icon: '✏️',
        title: '手动添加',
        desc: '直接填写宠物信息',
        color: '#4CAF50'
      },
      {
        id: 'chip',
        icon: '📱',
        title: '芯片扫描',
        desc: '扫描宠物芯片或二维码',
        color: '#2196F3'
      },
      {
        id: 'nfc',
        icon: '📲',
        title: 'NFC感应',
        desc: '使用手机NFC功能感应',
        color: '#FF9800'
      }
    ],
    userInfo: null,
    hasPets: false
  },

  onLoad() {
    // 检查登录状态
    if (!app.globalData.isLogged) {
      wx.redirectTo({
        url: '/pages/login/login'
      })
      return
    }

    this.setData({
      userInfo: app.globalData.userInfo,
      hasPets: app.globalData.pets && app.globalData.pets.length > 0
    })
  },

  // 选择添加方式
  onSelectMethod(e) {
    const { method } = e.currentTarget.dataset

    switch (method) {
      case 'manual':
        this.goToAddPetForm()
        break
      case 'chip':
        this.scanChip()
        break
      case 'nfc':
        this.nfcBind()
        break
    }
  },

  // 跳转到添加宠物表单页面（手动）
  goToAddPetForm() {
    wx.navigateTo({
      url: '/pages/add-pet/add-pet'
    })
  },

  // 扫描芯片
  scanChip() {
    wx.scanCode({
      onlyFromCamera: true,
      scanType: ['qrCode', 'barCode'],
      success: (res) => {
        const result = res.result
        // 跳转到添加宠物页面，并传递扫描到的芯片号
        wx.navigateTo({
          url: `/pages/add-pet/add-pet?chipId=${result}`
        })
      },
      fail: (err) => {
        console.error('扫码失败:', err)
        showToast('扫码失败，请重试', 'none')
      }
    })
  },

  // NFC绑定
  nfcBind() {
    // 检查是否支持NFC
    if (wx.startHCE) {
      wx.startHCE({
        aid_list: ['F222222222'],
        success: (res) => {
          showToast('NFC功能已开启，请将手机靠近宠物芯片', 'success')
          // 监听NFC标签
          wx.onHCEMessage((res) => {
            console.log('NFC消息:', res)
            // 解析数据并跳转
            const chipId = this.parseNFCMessage(res.data)
            wx.navigateTo({
              url: `/pages/add-pet/add-pet?chipId=${chipId}`
            })
          })
        },
        fail: (err) => {
          console.error('NFC启动失败:', err)
          showToast('NFC功能不可用，请检查手机设置', 'none')
        }
      })
    } else {
      showToast('当前设备不支持NFC功能', 'none')
    }
  },

  // 解析NFC消息（示例）
  parseNFCMessage(data) {
    // 这里根据实际NFC数据格式解析
    // 示例：假设data是16进制字符串，我们转换为字符串
    let chipId = ''
    for (let i = 0; i < data.length; i++) {
      chipId += String.fromCharCode(data[i])
    }
    return chipId.trim()
  },

  // 查看已有宠物
  onViewPets() {
    wx.switchTab({
      url: '/pages/pets/pets'
    })
  },

  // 返回首页
  onBackHome() {
    wx.switchTab({
      url: '/pages/index/index'
    })
  }
})