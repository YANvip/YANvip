// pages/profile/profile.js
const app = getApp();
const { request, showLoading, hideLoading, showToast, showModal, formatTime } = require('../../utils/util');

Page({
  data: {
    // 用户信息
    userInfo: {
      avatarUrl: '',
      nickName: '',
      userId: '',
      phone: '',
      wechatId: '',
      email: '',
      createdAt: '',
      lastLoginAt: ''
    },
    
    // 宠物统计
    petCount: 0,
    petStats: {
      dogs: 0,
      cats: 0,
      other: 0,
      active: 0,
      health: 0
    },
    
    // 安全评分 (1-5)
    securityScore: 3,
    
    // 模态框状态
    showPhoneModal: false,
    showWechatModal: false,
    showDeleteModal: false,
    
    // 注销确认输入
    deleteConfirmText: ''
  },

  onLoad() {
    // 检查登录状态
    this.checkLogin();
  },

  onShow() {
    // 页面显示时重新加载数据
    this.loadUserData();
    this.loadPetStats();
  },

  // 检查登录状态
  checkLogin() {
    const userInfo = app.globalData.userInfo;
    if (!userInfo) {
      wx.showModal({
        title: '需要登录',
        content: '请先登录以查看个人资料',
        confirmText: '去登录',
        success: (res) => {
          if (res.confirm) {
            wx.navigateTo({
              url: '/pages/login/login'
            });
          } else {
            wx.navigateBack();
          }
        }
      });
      return false;
    }
    
    this.setData({
      userInfo: {
        ...this.data.userInfo,
        ...userInfo
      }
    });
    
    return true;
  },

  // 加载用户数据
  async loadUserData() {
    if (!this.checkLogin()) return;
    
    try {
      showLoading('加载中...');
      
      // 从服务器获取用户信息
      const res = await request({
        url: '/api/user/profile',
        method: 'GET'
      });
      
      if (res.code === 0 && res.data) {
        this.setData({
          userInfo: {
            ...this.data.userInfo,
            ...res.data
          }
        });
        
        // 计算安全评分
        this.calculateSecurityScore();
      } else {
        // 服务器失败时使用全局数据
        this.setData({
          userInfo: {
            ...this.data.userInfo,
            ...app.globalData.userInfo
          }
        });
      }
    } catch (error) {
      console.error('加载用户数据失败:', error);
      // 使用本地缓存
      this.loadFromLocalStorage();
    } finally {
      hideLoading();
    }
  },

  // 从本地缓存加载
  loadFromLocalStorage() {
    try {
      const userInfo = wx.getStorageSync('userInfo') || app.globalData.userInfo;
      if (userInfo) {
        this.setData({
          userInfo: {
            ...this.data.userInfo,
            ...userInfo
          }
        });
      }
    } catch (error) {
      console.error('从本地加载用户数据失败:', error);
    }
  },

  // 加载宠物统计
  async loadPetStats() {
    try {
      // 从全局数据获取宠物列表
      const petList = app.globalData.petList || wx.getStorageSync('petList') || [];
      
      // 计算统计
      const stats = {
        dogs: 0,
        cats: 0,
        other: 0,
        active: 0,
        health: 0
      };
      
      petList.forEach(pet => {
        if (pet.type === 'dog') stats.dogs++;
        else if (pet.type === 'cat') stats.cats++;
        else stats.other++;
        
        if (pet.status === 'active') stats.active++;
        if (pet.healthStatus === 'normal') stats.health++;
      });
      
      this.setData({
        petCount: petList.length,
        petStats: stats
      });
    } catch (error) {
      console.error('加载宠物统计失败:', error);
    }
  },

  // 计算安全评分
  calculateSecurityScore() {
    const { userInfo } = this.data;
    let score = 1; // 基础分
    
    // 手机绑定 +2分
    if (userInfo.phone) score += 2;
    
    // 邮箱绑定 +1分
    if (userInfo.email) score += 1;
    
    // 微信绑定 +1分
    if (userInfo.wechatId) score += 1;
    
    // 最近登录时间（30天内）+1分
    if (userInfo.lastLoginAt) {
      const lastLogin = new Date(userInfo.lastLoginAt);
      const now = new Date();
      const daysDiff = Math.floor((now - lastLogin) / (1000 * 60 * 60 * 24));
      if (daysDiff <= 30) score += 1;
    }
    
    // 限制在1-5分之间
    score = Math.max(1, Math.min(5, score));
    
    this.setData({ securityScore: score });
  },

  // 获取安全等级
  getSecurityLevel() {
    const score = this.data.securityScore;
    if (score >= 4) return 'high';
    if (score >= 3) return 'medium';
    return 'low';
  },

  // 获取安全等级文本
  getSecurityLevelText() {
    const level = this.getSecurityLevel();
    const map = {
      high: '高',
      medium: '中',
      low: '低'
    };
    return map[level] || '低';
  },

  // 格式化日期
  formatDate(date) {
    if (!date) return '--';
    return formatTime(date, 'YYYY年MM月DD日');
  },

  // 更换头像
  changeAvatar() {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: async (res) => {
        showLoading('上传中...');
        
        try {
          const tempFilePath = res.tempFilePaths[0];
          
          // 上传头像
          const uploadRes = await request({
            url: '/api/user/avatar',
            method: 'POST',
            data: {
              avatar: tempFilePath
            }
          });
          
          if (uploadRes.code === 0 && uploadRes.data) {
            // 更新本地数据
            const newUserInfo = {
              ...this.data.userInfo,
              avatarUrl: uploadRes.data.url
            };
            
            this.setData({ userInfo: newUserInfo });
            
            // 更新全局数据
            app.globalData.userInfo = newUserInfo;
            wx.setStorageSync('userInfo', newUserInfo);
            
            showToast('头像更新成功');
          }
        } catch (error) {
          console.error('更换头像失败:', error);
          showToast('更换头像失败');
        } finally {
          hideLoading();
        }
      }
    });
  },

  // 跳转到编辑资料
  goToEditProfile() {
    wx.navigateTo({
      url: '/pages/edit-profile/edit-profile'
    });
  },

  // 显示手机信息
  showPhoneInfo() {
    this.setData({ showPhoneModal: true });
  },

  // 隐藏手机信息
  hidePhoneInfo() {
    this.setData({ showPhoneModal: false });
  },

  // 绑定手机号
  bindPhoneNumber() {
    wx.showModal({
      title: '绑定手机号',
      content: '该功能需要授权手机号，请确认操作',
      success: (res) => {
        if (res.confirm) {
          wx.navigateTo({
            url: '/pages/bind-phone/bind-phone'
          });
        }
      }
    });
  },

  // 更换手机号
  changePhoneNumber() {
    wx.navigateTo({
      url: '/pages/bind-phone/bind-phone?action=change'
    });
  },

  // 解绑手机号
  unbindPhoneNumber() {
    showModal({
      title: '解绑手机号',
      content: '解绑后可能影响账号安全和找回功能，确定要解绑吗？',
      confirmText: '解绑',
      confirmColor: '#f44336',
      success: async (res) => {
        if (res.confirm) {
          try {
            showLoading('处理中...');
            
            await request({
              url: '/api/user/unbind-phone',
              method: 'POST'
            });
            
            // 更新本地数据
            const newUserInfo = {
              ...this.data.userInfo,
              phone: ''
            };
            
            this.setData({ 
              userInfo: newUserInfo,
              showPhoneModal: false
            });
            
            // 更新全局数据
            app.globalData.userInfo = newUserInfo;
            wx.setStorageSync('userInfo', newUserInfo);
            
            // 重新计算安全评分
            this.calculateSecurityScore();
            
            showToast('解绑成功');
          } catch (error) {
            console.error('解绑手机号失败:', error);
            showToast('解绑失败');
          } finally {
            hideLoading();
          }
        }
      }
    });
  },

  // 显示微信信息
  showWechatInfo() {
    this.setData({ showWechatModal: true });
  },

  // 隐藏微信信息
  hideWechatInfo() {
    this.setData({ showWechatModal: false });
  },

  // 跳转到账号安全
  goToAccountSecurity() {
    wx.navigateTo({
      url: '/pages/account-security/account-security'
    });
  },

  // 跳转到宠物列表
  goToPetList(e) {
    const filter = e.currentTarget.dataset.filter;
    wx.navigateTo({
      url: `/pages/pets/pets?filter=${filter}`
    });
  },

  // 跳转到健康记录
  goToHealth() {
    wx.navigateTo({
      url: '/pages/health/health'
    });
  },

  // 跳转到二维码管理
  goToQRCodeManage() {
    wx.navigateTo({
      url: '/pages/qrcode-manage/qrcode-manage'
    });
  },

  // 跳转到数据导出
  goToDataExport() {
    showToast('数据导出功能即将上线');
    // wx.navigateTo({
    //   url: '/pages/data-export/data-export'
    // });
  },

  // 跳转到数据备份
  goToBackup() {
    showToast('数据备份功能即将上线');
    // wx.navigateTo({
    //   url: '/pages/backup/backup'
    // });
  },

  // 跳转到隐私设置
  goToPrivacySettings() {
    wx.navigateTo({
      url: '/pages/settings/settings?tab=privacy'
    });
  },

  // 跳转到消息通知设置
  goToNotificationSettings() {
    wx.navigateTo({
      url: '/pages/settings/settings?tab=notification'
    });
  },

  // 跳转到帮助中心
  goToHelpCenter() {
    wx.navigateTo({
      url: '/pages/help/help'
    });
  },

  // 跳转到关于我们
  goToAbout() {
    wx.navigateTo({
      url: '/pages/about/about'
    });
  },

  // 退出登录
  logout() {
    showModal({
      title: '退出登录',
      content: '确定要退出当前账号吗？',
      success: async (res) => {
        if (res.confirm) {
          try {
            showLoading('退出中...');
            
            // 调用退出登录接口
            await request({
              url: '/api/auth/logout',
              method: 'POST'
            });
            
            // 清除本地数据
            wx.removeStorageSync('userInfo');
            wx.removeStorageSync('token');
            wx.removeStorageSync('petList');
            
            // 清除全局数据
            app.globalData.userInfo = null;
            app.globalData.token = null;
            app.globalData.petList = [];
            
            showToast('退出成功');
            
            // 返回首页
            setTimeout(() => {
              wx.reLaunch({
                url: '/pages/index/index'
              });
            }, 1500);
          } catch (error) {
            console.error('退出登录失败:', error);
            
            // 即使API失败也清除本地数据
            wx.removeStorageSync('userInfo');
            wx.removeStorageSync('token');
            wx.removeStorageSync('petList');
            
            app.globalData.userInfo = null;
            app.globalData.token = null;
            app.globalData.petList = [];
            
            showToast('已退出登录');
            
            setTimeout(() => {
              wx.reLaunch({
                url: '/pages/index/index'
              });
            }, 1500);
          } finally {
            hideLoading();
          }
        }
      }
    });
  },

  // 显示注销账号确认
  showDeleteAccountModal() {
    this.setData({ 
      showDeleteModal: true,
      deleteConfirmText: ''
    });
  },

  // 隐藏注销账号确认
  hideDeleteAccountModal() {
    this.setData({ 
      showDeleteModal: false,
      deleteConfirmText: ''
    });
  },

  // 注销确认输入
  onDeleteConfirmInput(e) {
    this.setData({
      deleteConfirmText: e.detail.value.trim()
    });
  },

  // 注销账号
  async deleteAccount() {
    if (this.data.deleteConfirmText !== 'DELETE') {
      showToast('请输入DELETE确认');
      return;
    }
    
    showModal({
      title: '最后确认',
      content: '账号注销后所有数据将永久删除且无法恢复，确定要继续吗？',
      confirmText: '确认注销',
      confirmColor: '#f44336',
      success: async (res) => {
        if (res.confirm) {
          try {
            showLoading('注销中...');
            
            // 调用注销接口
            await request({
              url: '/api/user/delete',
              method: 'DELETE'
            });
            
            // 清除本地数据
            wx.removeStorageSync('userInfo');
            wx.removeStorageSync('token');
            wx.removeStorageSync('petList');
            
            // 清除全局数据
            app.globalData.userInfo = null;
            app.globalData.token = null;
            app.globalData.petList = [];
            
            showToast('账号已注销');
            
            // 返回首页
            setTimeout(() => {
              wx.reLaunch({
                url: '/pages/index/index'
              });
            }, 1500);
          } catch (error) {
            console.error('注销账号失败:', error);
            showToast('注销失败');
          } finally {
            hideLoading();
          }
        }
      }
    });
  },

  // 用户点击右上角分享
  onShareAppMessage() {
    return {
      title: '智能宠物管家 - 个人中心',
      path: '/pages/profile/profile',
      imageUrl: '/images/share-profile.jpg'
    };
  }
});
// pages/profile/profile.js 关键部分更新
Page({
  data: {
    user_info: {
      avatar_url: '',
      nick_name: '',
      user_id: '',
      phone: '',
      wechat_id: '',
      created_at: '',
      // 其他字段...
    },
    pet_count: 0,
    pet_stats: {
      dogs: 0,
      cats: 0,
      health: 0
    },
    security_score: 0,
    security_level: 'low',
    security_level_text: '较低',
    show_phone_modal: false,
    show_wechat_modal: false,
    show_delete_modal: false,
    delete_confirm_text: '',
    loading: false
  },

  onLoad: function() {
    this.load_user_info();
    this.load_pet_stats();
    this.calculate_security_level();
  },

  // 计算安全等级（在JS中预处理）
  calculate_security_level: function() {
    const score = this.data.security_score;
    let level = 'low';
    let level_text = '较低';
    
    if (score >= 4) {
      level = 'high';
      level_text = '较高';
    } else if (score >= 2) {
      level = 'medium';
      level_text = '中等';
    }
    
    this.setData({
      security_level: level,
      security_level_text: level_text
    });
  },

  // 格式化日期（在JS中预处理）
  format_date: function(date_string) {
    if (!date_string) return '--';
    const date = new Date(date_string);
    return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
  },

  // 事件处理函数使用下划线命名
  change_avatar: function() {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        this.setData({
          'user_info.avatar_url': res.tempFilePaths[0]
        });
        this.upload_avatar(res.tempFilePaths[0]);
      }
    });
  },

  go_to_edit_profile: function() {
    wx.navigateTo({
      url: '/pages/profile-edit/profile-edit'
    });
  },

  show_phone_info: function() {
    this.setData({
      show_phone_modal: true
    });
  },

  hide_phone_info: function() {
    this.setData({
      show_phone_modal: false
    });
  },

  show_delete_account_modal: function() {
    this.setData({
      show_delete_modal: true,
      delete_confirm_text: ''
    });
  },

  hide_delete_account_modal: function() {
    this.setData({
      show_delete_modal: false,
      delete_confirm_text: ''
    });
  },

  on_delete_confirm_input: function(e) {
    this.setData({
      delete_confirm_text: e.detail.value
    });
  },

  delete_account: function() {
    if (this.data.delete_confirm_text !== 'DELETE') {
      wx.showToast({
        title: '请输入DELETE确认',
        icon: 'none'
      });
      return;
    }

    // 确认注销账号
    wx.showModal({
      title: '最后确认',
      content: '确定要永久注销账号吗？此操作不可撤销！',
      confirmText: '确定注销',
      confirmColor: '#fa5151',
      success: (res) => {
        if (res.confirm) {
          this.perform_delete_account();
        }
      }
    });
  },

  perform_delete_account: function() {
    // 执行注销账号的逻辑
    wx.showLoading({
      title: '注销中...'
    });

    // 调用API删除账号
    // ...

    setTimeout(() => {
      wx.hideLoading();
      wx.showToast({
        title: '账号已注销',
        icon: 'success'
      });
      
      // 退出登录并返回首页
      setTimeout(() => {
        wx.clearStorageSync();
        wx.reLaunch({
          url: '/pages/index/index'
        });
      }, 1500);
    }, 2000);
  },

  // 其他导航函数
  go_to_pet_list: function(e) {
    const filter = e.currentTarget.dataset.filter;
    wx.navigateTo({
      url: `/pages/pet-list/pet-list?filter=${filter}`
    });
  },

  go_to_health: function() {
    wx.navigateTo({
      url: '/pages/health/health'
    });
  },

  go_to_qr_code_manage: function() {
    wx.navigateTo({
      url: '/pages/qrcode-manage/qrcode-manage'
    });
  },

  // 其他函数...
});
// pages/profile/profile.js 中需要更新的部分
Page({
  data: {
    // ... 其他数据
    
    // 手机号相关状态
    show_phone_modal: false,
    
    // 其他函数...
  },
  
  // 手机号相关函数
  show_phone_info: function() {
    this.setData({
      show_phone_modal: true
    });
  },
  
  hide_phone_info: function() {
    this.setData({
      show_phone_modal: false
    });
  },
  
  bind_phone_number: function() {
    // 绑定手机号的逻辑
    wx.navigateTo({
      url: '/pages/bind-phone/bind-phone'
    });
  },
  
  change_phone_number: function() {
    // 更换手机号的逻辑
    wx.navigateTo({
      url: '/pages/change-phone/change-phone'
    });
  },
  
  unbind_phone_number: function() {
    wx.showModal({
      title: '确认解绑',
      content: '确定要解绑手机号吗？解绑后可能影响账号安全',
      success: (res) => {
        if (res.confirm) {
          // 执行解绑逻辑
          this.perform_unbind_phone();
        }
      }
    });
  },
  
  perform_unbind_phone: function() {
    // 调用API解绑手机号
    wx.showLoading({ title: '处理中...' });
    
    // API调用...
    // 成功后：
    this.setData({
      'user_info.phone': ''
    });
    wx.hideLoading();
    wx.showToast({
      title: '解绑成功',
      icon: 'success'
    });
  }
  
  // ... 其他函数
});