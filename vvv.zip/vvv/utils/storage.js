// utils/storage.js
class Storage {
  // 设置缓存
  set(key, value, expire = 0) {
    const data = {
      value,
      expire: expire ? Date.now() + expire * 1000 : 0
    }
    wx.setStorageSync(key, data)
  }

  // 获取缓存
  get(key) {
    const data = wx.getStorageSync(key)
    if (!data) return null
    
    if (data.expire && data.expire < Date.now()) {
      this.remove(key)
      return null
    }
    
    return data.value
  }

  // 移除缓存
  remove(key) {
    wx.removeStorageSync(key)
  }

  // 清空所有缓存
  clear() {
    wx.clearStorageSync()
  }

  // 获取所有key
  keys() {
    const info = wx.getStorageInfoSync()
    return info.keys
  }

  // 检查是否有缓存
  has(key) {
    return this.get(key) !== null
  }

  // 设置用户信息
  setUserInfo(userInfo) {
    this.set('userInfo', userInfo, 7 * 24 * 60 * 60) // 7天
  }

  // 获取用户信息
  getUserInfo() {
    return this.get('userInfo')
  }

  // 设置token
  setToken(token) {
    this.set('token', token, 7 * 24 * 60 * 60) // 7天
  }

  // 获取token
  getToken() {
    return this.get('token')
  }

  // 清除登录信息
  clearLoginInfo() {
    this.remove('userInfo')
    this.remove('token')
  }

  // 设置宠物列表
  setPets(pets) {
    this.set('pets', pets, 24 * 60 * 60) // 24小时
  }

  // 获取宠物列表
  getPets() {
    return this.get('pets') || []
  }

  // 添加宠物
  addPet(pet) {
    const pets = this.getPets()
    pets.unshift(pet)
    this.setPets(pets)
  }

  // 更新宠物
  updatePet(petId, updates) {
    const pets = this.getPets()
    const index = pets.findIndex(p => p.id === petId)
    if (index !== -1) {
      pets[index] = { ...pets[index], ...updates }
      this.setPets(pets)
    }
  }

  // 删除宠物
  removePet(petId) {
    const pets = this.getPets()
    const filtered = pets.filter(p => p.id !== petId)
    this.setPets(filtered)
  }

  // 获取宠物
  getPet(petId) {
    const pets = this.getPets()
    return pets.find(p => p.id === petId)
  }

  // 根据二维码获取宠物
  getPetByQRCode(qrCode) {
    const pets = this.getPets()
    return pets.find(p => p.qrCode === qrCode)
  }
}

const storage = new Storage()
module.exports = storage
