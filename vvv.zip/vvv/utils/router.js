// utils/router.js
const routes = {
  // 首页相关
  index: '/pages/index/index',
  addPet: '/pages/addPet/addPet',
  addPetManual: '/pages/addPet/addPet?method=manual',
  addPetChip: '/pages/addPet/addPet?method=chip',
  
  // 扫码相关
  scan: '/pages/scan/scan',
  addPetWithQR: (qrCode) => `/pages/add-pet/add-pet?qrCode=${qrCode}`,
  bindProcess: (qrCode) => `/pages/bind-process/bind-process?qrCode=${qrCode}`,
  
  // 宠物相关
  pets: '/pages/pets/pets',
  petDetail: (petId) => `/pages/pet-detail/pet-detail?petId=${petId}`,
  editPet: (petId) => `/pages/addPet/addPet?petId=${petId}`,
  
  // 健康相关
  health: '/pages/health/health',
  healthAdd: (petId) => `/pages/health-add/health-add?petId=${petId}`,
  
  // 个人相关
  profile: '/pages/profile/profile',
  editProfile: '/pages/editProfile/editProfile',
  login: '/pages/login/login'
}
// 在页面中引入
import routes from '../../utils/router'

// 使用路由
wx.navigateTo({
  url: routes.addPet
})

// 带参数的路由
wx.navigateTo({
  url: routes.petDetail(petId)
})
export default routes
