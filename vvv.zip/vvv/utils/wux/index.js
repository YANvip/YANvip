// utils/wux/index.js - 简单模拟 Wux UI，避免引用错误
module.exports = {
  // Dialog 组件模拟
  Dialog: {
    alert: (options) => {
      return wx.showModal({
        title: options.title || '提示',
        content: options.content || '',
        showCancel: false
      });
    },
    confirm: (options) => {
      return wx.showModal({
        title: options.title || '确认',
        content: options.content || '',
        confirmText: options.confirmText || '确定',
        cancelText: options.cancelText || '取消'
      });
    }
  },
  
  // Toast 组件模拟
  Toast: {
    success: (title, options = {}) => {
      wx.showToast({
        title,
        icon: 'success',
        duration: options.duration || 2000
      });
    },
    error: (title, options = {}) => {
      wx.showToast({
        title,
        icon: 'error',
        duration: options.duration || 2000
      });
    },
    loading: (title = '加载中...') => {
      wx.showLoading({ title });
    },
    hide: () => {
      wx.hideLoading();
      wx.hideToast();
    }
  },
  
  // 其他组件占位
  Button: null,
  Cell: null,
  Icon: null,
  Loading: null
};