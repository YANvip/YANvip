// utils/request.js - 简化版本
const request = (options) => {
  const app = getApp();
  
  // 显示加载提示
  if (options.show_loading !== false) {
    wx.showLoading({
      title: options.loading_title || '加载中...',
      mask: true
    });
  }
  
  // 修改base_url为云托管域名
  if (!options.url.startsWith('http')) {
    const base_url = app.globalData.base_url || 'https://你的云托管域名/api';
    options.url = base_url + options.url;
  }
  
  // 添加token
  if (!options.header) {
    options.header = {};
  }
  if (app.globalData.token) {
    options.header['Authorization'] = `Bearer ${app.globalData.token}`;
  }
  
  return new Promise((resolve, reject) => {
    wx.request({
      url: options.url,
      method: options.method || 'GET',
      data: options.data || {},
      header: options.header,
      success: (res) => {
        wx.hideLoading();
        
        if (res.statusCode === 200) {
          resolve(res.data);
        } else if (res.statusCode === 401) {
          // token过期
          wx.showModal({
            title: '提示',
            content: '登录已过期，请重新登录',
            showCancel: false,
            success: () => {
              app.logout();
              wx.reLaunch({ url: '/pages/login/login' });
            }
          });
          reject(new Error('登录已过期'));
        } else {
          reject(new Error(`请求失败: ${res.statusCode}`));
        }
      },
      fail: (error) => {
        wx.hideLoading();
        wx.showToast({
          title: '网络连接失败',
          icon: 'none'
        });
        reject(error);
      }
    });
  });
};

// 快捷方法
const get = (url, data = {}, options = {}) => {
  return request({ ...options, url, data, method: 'GET' });
};

const post = (url, data = {}, options = {}) => {
  return request({ ...options, url, data, method: 'POST' });
};

const put = (url, data = {}, options = {}) => {
  return request({ ...options, url, data, method: 'PUT' });
};

const del = (url, data = {}, options = {}) => {
  return request({ ...options, url, data, method: 'DELETE' });
};

module.exports = {
  request,
  get,
  post,
  put,
  delete: del
};