// utils/wxapi.js - 简化版本（删除重复定义）

// 显示操作菜单
export const showActionSheet = (itemList) => {
  return new Promise((resolve, reject) => {
    wx.showActionSheet({
      itemList,
      success: (res) => resolve(res.tapIndex),
      fail: reject
    });
  });
};

// 设置剪贴板
export const setClipboardData = (data) => {
  return new Promise((resolve, reject) => {
    wx.setClipboardData({
      data,
      success: resolve,
      fail: reject
    });
  });
};

// 获取剪贴板数据
export const getClipboardData = () => {
  return new Promise((resolve, reject) => {
    wx.getClipboardData({
      success: (res) => resolve(res.data),
      fail: reject
    });
  });
};

// 振动
export const vibrateShort = () => {
  wx.vibrateShort();
};

export const vibrateLong = () => {
  wx.vibrateLong();
};

// 检查网络状态
export const getNetworkType = () => {
  return new Promise((resolve, reject) => {
    wx.getNetworkType({
      success: resolve,
      fail: reject
    });
  });
};

// 监听网络状态变化
export const onNetworkStatusChange = (callback) => {
  wx.onNetworkStatusChange(callback);
};

// 显示模态框
export const showModal = (title, content, options = {}) => {
  return new Promise((resolve) => {
    wx.showModal({
      title,
      content,
      showCancel: options.showCancel !== false,
      cancelText: options.cancelText || '取消',
      confirmText: options.confirmText || '确定',
      success: (res) => resolve(res.confirm)
    });
  });
};

// 显示提示框
export const showToast = (title, icon = 'success', duration = 2000) => {
  wx.showToast({
    title,
    icon,
    duration
  });
};

// 显示加载框
export const showLoading = (title = '加载中...') => {
  wx.showLoading({
    title,
    mask: true
  });
};

// 隐藏加载框
export const hideLoading = () => {
  wx.hideLoading();
};

// 检查更新
export const checkForUpdate = () => {
  if (wx.canIUse('getUpdateManager')) {
    const updateManager = wx.getUpdateManager();
    
    updateManager.onCheckForUpdate((res) => {
      console.log('检查到更新:', res.hasUpdate);
    });
    
    updateManager.onUpdateReady(() => {
      showModal('更新提示', '新版本已经准备好，是否重启应用？').then((confirm) => {
        if (confirm) {
          updateManager.applyUpdate();
        }
      });
    });
    
    updateManager.onUpdateFailed(() => {
      showToast('新版本下载失败', 'none');
    });
  }
};