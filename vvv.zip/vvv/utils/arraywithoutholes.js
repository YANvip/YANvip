// 补全该工具类，避免模块引用报错
module.exports = function arrayWithoutholes(arr) {
  return arr.filter(item => item !== undefined && item !== null);
};