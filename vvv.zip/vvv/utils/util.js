// utils/util.js
const formatTime = (date, format = 'YYYY-MM-DD HH:mm:ss') => {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  const hour = String(date.getHours()).padStart(2, '0')
  const minute = String(date.getMinutes()).padStart(2, '0')
  const second = String(date.getSeconds()).padStart(2, '0')
  
  return format
    .replace('YYYY', year)
    .replace('MM', month)
    .replace('DD', day)
    .replace('HH', hour)
    .replace('mm', minute)
    .replace('ss', second)
}

const formatDate = (dateStr, format = 'YYYY-MM-DD') => {
  const date = new Date(dateStr)
  return formatTime(date, format)
}

// 计算年龄
const calculateAge = (birthDate) => {
  if (!birthDate) return '未知'
  
  const birth = new Date(birthDate)
  const today = new Date()
  let years = today.getFullYear() - birth.getFullYear()
  let months = today.getMonth() - birth.getMonth()
  
  if (months < 0) {
    years--
    months += 12
  }
  
  if (years > 0) {
    return `${years}岁${months > 0 ? months + '个月' : ''}`
  } else {
    return `${months}个月`
  }
}

// 防抖
const debounce = (func, wait = 300) => {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

// 节流
const throttle = (func, limit = 300) => {
  let inThrottle
  return function(...args) {
    if (!inThrottle) {
      func.apply(this, args)
      inThrottle = true
      setTimeout(() => inThrottle = false, limit)
    }
  }
}

// 验证手机号
const validatePhone = (phone) => {
  return /^1[3-9]\d{9}$/.test(phone)
}

// 验证邮箱
const validateEmail = (email) => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

// 深拷贝
const deepClone = (obj) => {
  if (obj === null || typeof obj !== 'object') return obj
  if (obj instanceof Date) return new Date(obj)
  if (obj instanceof Array) return obj.map(item => deepClone(item))
  if (typeof obj === 'object') {
    const cloned = {}
    for (const key in obj) {
      cloned[key] = deepClone(obj[key])
    }
    return cloned
  }
}

// 获取随机ID
const generateId = () => {
  return 'ID' + Date.now() + Math.random().toString(36).substr(2, 9)
}

// 获取宠物类型图标
const getPetTypeIcon = (type) => {
  const icons = {
    dog: '🐕',
    cat: '🐈',
    rabbit: '🐇',
    bird: '🐦',
    fish: '🐠',
    other: '🐾'
  }
  return icons[type] || icons.other
}

// 获取宠物类型名称
const getPetTypeName = (type) => {
  const names = {
    dog: '狗狗',
    cat: '猫咪',
    rabbit: '兔子',
    bird: '鸟类',
    fish: '鱼类',
    other: '其他'
  }
  return names[type] || names.other
}

// 获取性别名称
const getGenderName = (gender) => {
  const names = {
    male: '男孩',
    female: '女孩',
    unknown: '未知'
  }
  return names[gender] || names.unknown
}

// 获取健康状态名称
const getHealthStatusName = (status) => {
  const names = {
    healthy: '健康',
    sick: '生病',
    injured: '受伤',
    recovering: '恢复中',
    unknown: '未知'
  }
  return names[status] || names.unknown
}

// 格式化文件大小
const formatFileSize = (bytes) => {
  if (bytes === 0) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
}

// 生成二维码数据
const generateQRData = (type, data) => {
  return JSON.stringify({ type, data, timestamp: Date.now() })
}

module.exports = {
  formatTime,
  formatDate,
  calculateAge,
  debounce,
  throttle,
  validatePhone,
  validateEmail,
  deepClone,
  generateId,
  getPetTypeIcon,
  getPetTypeName,
  getGenderName,
  getHealthStatusName,
  formatFileSize,
  generateQRData
}